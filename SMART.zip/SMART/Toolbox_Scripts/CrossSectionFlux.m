function [ Output_CS_d, Output_sub_d, Output_sub_m,  Output_sub_y ] = CrossSectionFlux( CS_Del_Type,Model_Out_Path, CS_ID )
%% ========================================================================
%%    This Matlab script computes Cross sectional and sub-basin level fluxes depending on the delineation approach at daily,
%%    monthly and annual scales using U3M-2D output files.
%%
%%   INPUTS:
%%   1) User defines one of the delineation types and the code reads respective .mat file from  '...\Toolbox_Output\
%%     1 = DISTRIBUTED Pixel based delineation                    (6a)
%%     2 = DISTRIBUTED LANDFORM based delineation                 (6b)
%%     3 = ECS Left bank/right bank/headwater delineation         (6c)
%%     4 = ECS Soil type delineation                              (6d)
%%   2) Model output Path
%%   3) CS_ID from OutputPixelIndex.m
%%
%%
%%   OUTPUTS (...\Model_Output\DelType):
%%   Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%   Time scales:    Daily, Monthly, Annual
%%   Spatial scales: Cross section and sub-basin
%%   CS_Daily               Horizontal Flow; Deep drainage; Overstorey and understorey transpiration; Soil Evaporation
%%   Sub_Basin_Daily        Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%   Sub_Basin_Monthly      Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%   Sub_Basin_Yearly       Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%
%%   It calls the following functions:
%%    UserRunInfo.m
%%
%%   Copyright 2017 Hoori Ajami, University of California Riverside
%%   Version 1.0 -Update 8/18/2017
%% ========================================================================

RunInfo  = UserRunInfo;
st_date = RunInfo.StartDate;
end_date = RunInfo.EndDate;
Date_Num = (datenum(st_date, 'dd/mm/yyyy'):datenum(end_date, 'dd/mm/yyyy'));
[year, month, day] = datevec(datestr(Date_Num,'dd/mm/yyyy'),'dd/mm/yyyy' );
SimPeriod = size(year,1);

%% DAILY CROSS SECTION
% Horizontal flow and deep drainage
Qh_CS = zeros(size(CS_ID,1), SimPeriod + 3);
Qb_CS = zeros(size(CS_ID,1), SimPeriod + 3);

% Overstorey, understorey and soil evaporation
Trans_o_CS = zeros(size(CS_ID,1), SimPeriod + 3);
Trans_u_CS = zeros(size(CS_ID,1), SimPeriod + 3);
Evap_CS    = zeros(size(CS_ID,1), SimPeriod + 3);
P_CS       = zeros(size(CS_ID,1), SimPeriod + 3);

if   CS_Del_Type <= 3 || CS_Del_Type == 5 ;
    format_Pixel   = '%5d%8.2f%2s%2d%8.2f%8.2f%8.2f%8.2f%4d%4d%4d%4d%8.4f%8.4f%8.4f%8.4f%2s%2s%7.3f%2d%6d%6d%6d%6d%6d%6d%6d%6d';
    for i = 1 :  size(CS_ID, 1)  %for every CS
        %       i
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        PixelFileName   = [Output_Files_Path,'PixelFile.txt'];
        
        %          T = readtable(PixelFileName, 'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 4,'Format', format_Pixel  );
        T = readtable(PixelFileName, 'Delimiter','\t', 'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 4,'Format', format_Pixel  ); 
        
        % From Pixel File
        NumPixels   =  size(T.Var1,1);
        clear T
        
        %         Qh_mean = zeros(NumPixels, SimPeriod);
        Qh_mean = zeros(1, SimPeriod);
        Qb_mean = zeros(NumPixels-1, SimPeriod);
        To_mean = zeros(NumPixels-1, SimPeriod);
        Tu_mean = zeros(NumPixels-1, SimPeriod);
        Ev_mean = zeros(NumPixels-1, SimPeriod);
        P_mean  = zeros(NumPixels-1, SimPeriod);
        
        for j = 1  : NumPixels - 1 %read all pixels - 1
            %          j
            if j == NumPixels - 1
                Qh_FileName = [Output_Files_Path,'OutputHorizontalDistribution_', num2str(j),'.txt'];
                T = readtable(Qh_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
                Qh_mean(1, :) = (T.Var15 + T.Var16+T.Var17+ T.Var18)';  %WRR 2014
                clear T Qh_FileName
            end
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            P_mean(j, :) =  (Tb.Var2)';
            Qb_mean(j, :) = (Tb.Var9)';
            To_mean(j, :) = (Tb.Var6)';
            Tu_mean(j, :) = (Tb.Var7)';
            Ev_mean(j, :) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        Qh_CS(i,1) = record(1);  %CS_id
        Qh_CS(i,2) = record(2);  %Subbasin Num
        Qh_CS(i,3) = record(3);  %CS contributing area
        %         Qh_CS(i,4:end) = (Qh_mean(1,:)./ (NumPixels - 1)).* repmat(record(3), 1,SimPeriod);
        Qh_CS(i,4:end) = (Qh_mean(1,:)./ (NumPixels - 1)).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);  % 8/18/2017 m3/day
        %         Qh_CS(i,4:end) = mean(Qh_mean,1).* repmat(record(3), 1,SimPeriod);
        
        
        Qb_CS(i,1) = record(1);  %CS_id
        Qb_CS(i,2) = record(2);  %Subbasin Num
        Qb_CS(i,3) = record(3);  %CS contributing area
        Qb_CS(i,4:end) = mean(Qb_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        P_CS(i,1) = record(1);  %CS_id
        P_CS(i,2) = record(2);  %Subbasin Num
        P_CS(i,3) = record(3);  %CS contributing area
        P_CS(i,4:end) = mean(P_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        Trans_o_CS(i,1) = record(1);  %CS_id
        Trans_o_CS(i,2) = record(2);  %Subbasin Num
        Trans_o_CS(i,3) = record(3);  %CS contributing area
        Trans_o_CS(i,4:end) = mean(To_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        Trans_u_CS(i,1) = record(1);  %CS_id
        Trans_u_CS(i,2) = record(2);  %Subbasin Num
        Trans_u_CS(i,3) = record(3);  %CS contributing area
        Trans_u_CS(i,4:end) = mean(Tu_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        Evap_CS(i,1) = record(1);  %CS_id
        Evap_CS(i,2) = record(2);  %Subbasin Num
        Evap_CS(i,3) = record(3);  %CS contributing area
        Evap_CS(i,4:end) = mean(Ev_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);  %m3
        
        clear Qb_mean Qh_mean To_mean Tu_mean Ev_mean
        
    end
    Output_CS_d = struct('P_CS', P_CS,'Qh_CS',Qh_CS,'Qb_CS',Qb_CS, 'Trans_o_CS', Trans_o_CS, 'Trans_u_CS',  Trans_u_CS, 'Evap_CS',  Evap_CS);
    
    [uniq_sub_id,ia ,ib] = unique(CS_ID(:,2), 'stable');
    area_sub_basin = accumarray(ib,CS_ID(:,3),[],@sum);
    area_sub_basin = area_sub_basin .* RunInfo.DEMRes.^2;
    
    area_sub_basin = repmat(area_sub_basin, 1,SimPeriod);
    
    
elseif CS_Del_Type == 4 || CS_Del_Type == 6 ;
    
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        %         Qh_mean = zeros(record(1,4), SimPeriod);
        Qh_mean = zeros(1, SimPeriod);
        Qb_mean = zeros(record(1,4), SimPeriod);
        To_mean = zeros(record(1,4), SimPeriod);
        Tu_mean = zeros(record(1,4), SimPeriod);
        Ev_mean = zeros(record(1,4), SimPeriod);
        P_mean  = zeros(record(1,4), SimPeriod);
        
        for j = 1  : record(1,4)  %read all pixels (already minus 1)
            
            if j ==  record(1,4)
                Qh_FileName = [Output_Files_Path,'OutputHorizontalDistribution_', num2str(j),'.txt'];
                T = readtable(Qh_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
                Qh_mean(1, :) = (T.Var15 + T.Var16+T.Var17+ T.Var18)';
                clear T Qh_FileName
            end
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            P_mean(j, :) =  (Tb.Var2)';
            Qb_mean(j, :) = (Tb.Var9)';
            To_mean(j, :) = (Tb.Var6)';
            Tu_mean(j, :) = (Tb.Var7)';
            Ev_mean(j, :) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        Qh_CS(i,1) = record(1);  %CS_id
        Qh_CS(i,2) = record(2);  %Subbasin Num
        Qh_CS(i,3) = record(3);  %CS contributing area
%         Qh_CS(i,4:end) = (Qh_mean(1,:)./record(1,4)).* repmat(record(3), 1,SimPeriod);
         Qh_CS(i,4:end) = (Qh_mean(1,:)./record(1,4)).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod); %8/18/2017
        %         Qh_CS(i,4:end) = mean(Qh_mean,1).* repmat(record(3), 1,SimPeriod);
        
        Qb_CS(i,1) = record(1);  %CS_id
        Qb_CS(i,2) = record(2);  %Subbasin Num
        Qb_CS(i,3) = record(3);  %CS contributing area
        Qb_CS(i,4:end) = mean(Qb_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        P_CS(i,1) = record(1);  %CS_id
        P_CS(i,2) = record(2);  %Subbasin Num
        P_CS(i,3) = record(3);  %CS contributing area
        P_CS(i,4:end) = mean(P_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        Trans_o_CS(i,1) = record(1);  %CS_id
        Trans_o_CS(i,2) = record(2);  %Subbasin Num
        Trans_o_CS(i,3) = record(3);  %CS contributing area
        Trans_o_CS(i,4:end) = mean(To_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        Trans_u_CS(i,1) = record(1);  %CS_id
        Trans_u_CS(i,2) = record(2);  %Subbasin Num
        Trans_u_CS(i,3) = record(3);  %CS contributing area
        Trans_u_CS(i,4:end) = mean(Tu_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);
        
        Evap_CS(i,1) = record(1);  %CS_id
        Evap_CS(i,2) = record(2);  %Subbasin Num
        Evap_CS(i,3) = record(3);  %CS contributing area
        Evap_CS(i,4:end) = mean(Ev_mean,1).* repmat(record(3).* RunInfo.DEMRes.^2, 1,SimPeriod);  %m3
        
        clear Qb_mean Qh_mean To_mean Tu_mean Ev_mean
        
    end
    
    Output_CS_d = struct('P_CS', P_CS,'Qh_CS',Qh_CS,'Qb_CS',Qb_CS, 'Trans_o_CS', Trans_o_CS, 'Trans_u_CS',  Trans_u_CS, 'Evap_CS',  Evap_CS);
    
    [uniq_sub_id,ia ,ib] = unique(CS_ID(:,2), 'stable');
    
    area_sub_basin = accumarray(ib,CS_ID(:,3),[],@sum);
    area_sub_basin = area_sub_basin .* RunInfo.DEMRes.^2;
    area_sub_basin = repmat(area_sub_basin, 1,SimPeriod);
    
    
end



%% Daily sub-basin
% %     tic
% %     for i = 1 : SimPeriod
% %         Evap_sub(:,i)   = accumarray(ib,Evap_CS(:,i+3),[],@mean);
% %         Trans_o_sub(:,i)= accumarray(ib,Trans_o_CS(:,i+3),[],@mean);
% %         Trans_u_sub(:,i)= accumarray(ib,Trans_u_CS(:,i+3),[],@mean);
% %         Qb_sub(:,i)     = accumarray(ib,Qb_CS(:,i+3),[],@mean);
% %         Qh_sub(:,i)     = accumarray(ib,Qh_CS(:,i+3),[],@mean);
% %     end
% %     toc

Evap_sub    = zeros(size(uniq_sub_id,1), SimPeriod);
Trans_o_sub = zeros(size(uniq_sub_id,1), SimPeriod);
Trans_u_sub = zeros(size(uniq_sub_id,1), SimPeriod);
Qb_sub      = zeros(size(uniq_sub_id,1), SimPeriod);
Qh_sub      = zeros(size(uniq_sub_id,1), SimPeriod);
P_sub       = zeros(size(uniq_sub_id,1), SimPeriod);

tic
for i = 1 : SimPeriod
    %     Evap_sub(:,i)   = accumarray(ib,Evap_CS(:,i+3))./accumarray(ib,1);
    %     Trans_o_sub(:,i)= accumarray(ib,Trans_o_CS(:,i+3))./accumarray(ib,1);
    %     Trans_u_sub(:,i)= accumarray(ib,Trans_u_CS(:,i+3))./accumarray(ib,1);
    %     Qb_sub(:,i)     = accumarray(ib,Qb_CS(:,i+3))./accumarray(ib,1);
    %     Qh_sub(:,i)     = accumarray(ib,Qh_CS(:,i+3))./accumarray(ib,1);
    Evap_sub(:,i)   = accumarray(ib,Evap_CS(:,i+3));
    Trans_o_sub(:,i)= accumarray(ib,Trans_o_CS(:,i+3));
    Trans_u_sub(:,i)= accumarray(ib,Trans_u_CS(:,i+3));
    Qb_sub(:,i)     = accumarray(ib,Qb_CS(:,i+3));
    Qh_sub(:,i)     = accumarray(ib,Qh_CS(:,i+3));
    P_sub(:,i)      = accumarray(ib,P_CS(:,i+3));
end
toc

clear Evap_CS Trans_o_CS Trans_u_CS Qb_CS Qh_CS



% Get diff and save
Evap_sub_d    = [uniq_sub_id, Evap_sub(:,1).*1000, diff(Evap_sub, [],2).*1000];
Trans_o_sub_d = [uniq_sub_id, Trans_o_sub(:,1).*1000, diff(Trans_o_sub, [],2).*1000];
Trans_u_sub_d = [uniq_sub_id, Trans_u_sub(:,1).*1000, diff(Trans_u_sub, [],2).*1000];
Qb_sub_d      = [uniq_sub_id, Qb_sub(:,1).*1000, diff(Qb_sub, [],2).*1000];
Qh_sub_d      = [uniq_sub_id, Qh_sub(:,1).*1000, diff(Qh_sub, [],2).*1000];  
P_sub_d        = [uniq_sub_id, P_sub.*1000];

Evap_sub_d(:, 2:end) = Evap_sub_d(:, 2:end)./area_sub_basin; %mm/d
Trans_o_sub_d(:, 2:end) = Trans_o_sub_d(:, 2:end)./area_sub_basin;
Trans_u_sub_d(:, 2:end) = Trans_u_sub_d(:, 2:end)./area_sub_basin;
Qb_sub_d(:, 2:end) = Qb_sub_d(:, 2:end)./area_sub_basin;
Qh_sub_d(:, 2:end) = Qh_sub_d(:, 2:end)./area_sub_basin;
Qtot_sub_d    = [uniq_sub_id, (Qh_sub_d(:,2:end) + (Qb_sub_d(:,2:end).*-1))];
P_sub_d(:, 2:end) = P_sub_d(:, 2:end)./area_sub_basin;

Output_sub_d = struct('P_sub',P_sub_d,'Qh_sub',Qh_sub_d,'Qb_sub',Qb_sub_d, 'Qtot_sub', Qtot_sub_d, 'Trans_o_sub', Trans_o_sub_d, 'Trans_u_sub',  Trans_u_sub_d, 'Evap_sub',  Evap_sub_d);

%% Monthly and Annual Sub-Basin

day_d = ones(size(day,1),1);
date_num_ind = datenum(year, month, day_d);
[uni, idx1, idx2] = unique(date_num_ind);

Evap_sub_1    =  Evap_sub_d(:, 2:end)';
Trans_o_sub_1 =  Trans_o_sub_d(:, 2:end)';
Trans_u_sub_1 =  Trans_u_sub_d(:, 2:end)';
Qb_sub_1      =  Qb_sub_d(:, 2:end)';
Qh_sub_1      =  Qh_sub_d(:, 2:end)';
Qtot_sub_1    =  Qtot_sub_d(:, 2:end)';
P_sub_1    =  P_sub_d(:, 2:end)';

% Save Monthly
Num_years = unique(year);
Evap_sub_m    = zeros(size(uniq_sub_id,1), numel(Num_years).*12);
Trans_o_sub_m = zeros(size(uniq_sub_id,1), numel(Num_years).*12);
Trans_u_sub_m = zeros(size(uniq_sub_id,1), numel(Num_years).*12);
Qb_sub_m      = zeros(size(uniq_sub_id,1), numel(Num_years).*12);
Qh_sub_m      = zeros(size(uniq_sub_id,1), numel(Num_years).*12);
Qtot_sub_m    = zeros(size(uniq_sub_id,1), numel(Num_years).*12);
P_sub_m    = zeros(size(uniq_sub_id,1), numel(Num_years).*12);
for i = 1 : size(uniq_sub_id,1);
    
    Evap_sub_m(i,:)    = accumarray(idx2,Evap_sub_1(:,i))';
    Trans_o_sub_m(i,:) = accumarray(idx2, Trans_o_sub_1(:,i))';
    Trans_u_sub_m(i,:) = accumarray(idx2, Trans_u_sub_1(:,i))';
    Qb_sub_m(i,:)      = accumarray(idx2,Qb_sub_1(:,i))';
    Qh_sub_m(i,:)      = accumarray(idx2,Qh_sub_1(:,i))';
    Qtot_sub_m(i,:)    = accumarray(idx2,Qtot_sub_1(:,i))';
    P_sub_m(i,:)    = accumarray(idx2,P_sub_1(:,i))';
end

Output_sub_m = struct('P_sub',[uniq_sub_id, P_sub_m],'Qh_sub',[uniq_sub_id, Qh_sub_m],'Qb_sub',[uniq_sub_id, Qb_sub_m], 'Qtot_sub', [uniq_sub_id,Qtot_sub_m], 'Trans_o_sub', [uniq_sub_id,Trans_o_sub_m], 'Trans_u_sub',  [uniq_sub_id,Trans_u_sub_m], 'Evap_sub',  [uniq_sub_id,Evap_sub_m]);

% Save Annual
date_num_ind2 = datenum(year, ones(size(day,1),1), day_d);
[uni, idx1, idx_yr] = unique(date_num_ind2);

Num_years = unique(year);
Evap_sub_y    = zeros(size(uniq_sub_id,1), numel(Num_years));
Trans_o_sub_y = zeros(size(uniq_sub_id,1), numel(Num_years));
Trans_u_sub_y = zeros(size(uniq_sub_id,1), numel(Num_years));
Qb_sub_y      = zeros(size(uniq_sub_id,1), numel(Num_years));
Qh_sub_y      = zeros(size(uniq_sub_id,1), numel(Num_years));
Qtot_sub_y    = zeros(size(uniq_sub_id,1), numel(Num_years));
P_sub_y    = zeros(size(uniq_sub_id,1), numel(Num_years));
for i = 1 : size(uniq_sub_id,1);
    
    Evap_sub_y(i,:)    = accumarray(idx_yr,Evap_sub_1(:,i))';
    Trans_o_sub_y(i,:) = accumarray(idx_yr, Trans_o_sub_1(:,i))';
    Trans_u_sub_y(i,:) = accumarray(idx_yr, Trans_u_sub_1(:,i))';
    Qb_sub_y(i,:)      = accumarray(idx_yr,Qb_sub_1(:,i))';
    Qh_sub_y(i,:)      = accumarray(idx_yr,Qh_sub_1(:,i))';
    Qtot_sub_y(i,:)    = accumarray(idx_yr,Qtot_sub_1(:,i))';
    P_sub_y(i,:)       = accumarray(idx_yr,P_sub_1(:,i))';
end

Output_sub_y = struct('P_sub',[uniq_sub_id,P_sub_y],'Qh_sub',[uniq_sub_id,Qh_sub_y],'Qb_sub',[uniq_sub_id,Qb_sub_y], 'Qtot_sub', [uniq_sub_id,Qtot_sub_y], 'Trans_o_sub', [uniq_sub_id,Trans_o_sub_y], 'Trans_u_sub',  [uniq_sub_id,Trans_u_sub_y], 'Evap_sub',  [uniq_sub_id,Evap_sub_y]);
end

