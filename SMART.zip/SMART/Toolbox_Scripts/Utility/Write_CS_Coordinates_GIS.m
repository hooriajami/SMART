RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;

% addpath(genpath(usr_Path))
addpath([usr_Path, '\Toolbox_Scripts'])
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');

if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
else
    error('This delineation does not exist!!!');
end

SubBasinFileName  = strcat(Output_Path, 'SubBasinGrid.txt');
if   exist(SubBasinFileName, 'file'); load(SubBasinFileName);
else error('Error: file does not exist:\n%s', [SubBasinFileName, ' does not exist in ', Output_Path]);
end

if CS_Del_Type == 1

FileName = [Output_Path, 'CS_coordinates.txt' ];
M = dlmread(FileName,'t'); 
CS_num = zeros(39,1);
M_grid = ones(size(SubBasinGrid));
M_grid = M_grid .* -9999;

for i = 1 : size(M,1)
   
   CS_num(i,1) = i;
   index = M(i,:);
   ind = find(index ~= 0);
   index = index(ind);
   index = fliplr(index);
   M_grid(index) = i; 
end

OutputFileName =[Output_Path,'Cross_Section_GIS_stanley.asc'];
WriteASCIIGrid(OutputFileName, Output_Path, M_grid)


elseif CS_Del_Type == 2
    WORK ON THESE
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Landform\');
    
    FileName = [Output_Path,'data_CS_Landform_Subbasin_203.mat'];
    load(FileName)
   
     [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);

FileName = [Output_Path, 'CS_coordinates_LF_T2.txt' ];
M = dlmread(FileName,'t'); 
CS_num = zeros(11436,1);
M_grid = ones(size(SubBasinGrid));
M_grid = M_grid .* -9999;

for i = 1 : size(CS_ID_LF,1)
   
   CS_num(i,1) = i;
   index = M(i,:);
   ind = find(index ~= 0);
   index = index(ind);
   M_grid(index) = CS_ID_LF(i, 13); 
end   

OutputFileName =[Output_Path,'Cross_Section_GIS_K5.asc'];
WriteASCIIGrid(OutputFileName, Output_Path, M_grid)
% dlmwrite('CS_LF10.txt', M_grid,'delimiter',' ');
% 
% 
% save('test_lf.txt', 'M_grid', '-ASCII')

end