%% ========================================================================
%%   This Matlab script generates SMART folder structure in a user defined directory.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
usr_Path = 'D:\Torrens\SMART';    %% Change this directory to your desired folder.

%%
Path1  = strcat(usr_Path);
mkdir(Path1 , '\Toolbox_Input\')
mkdir(Path1 , '\Toolbox_Output\')
mkdir(Path1 , '\Model_Input\')
mkdir(Path1 , '\Model_Input\Pixel_Distributed')
mkdir(Path1 , '\Model_Input\Pixel_Landform')
mkdir(Path1 , '\Model_Input\ECS_LB_RB_H_CS')
mkdir(Path1 , '\Model_Input\ECS_Soil_Type_CS')

mkdir(Path1 , '\Model_Output\')
mkdir(Path1 , '\Model_Output\Pixel_Distributed')
mkdir(Path1 , '\Model_Output\Pixel_Landform')
mkdir(Path1 , '\Model_Output\ECS_LB_RB_H_CS')
mkdir(Path1 , '\Model_Output\ECS_Soil_Type_CS')
