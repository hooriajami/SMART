function WriteGageShapeFile(latitude, longitude, FileName)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
S = geopoint(latitude, longitude, 'id', 0);
shapewrite(S,FileName)
end

