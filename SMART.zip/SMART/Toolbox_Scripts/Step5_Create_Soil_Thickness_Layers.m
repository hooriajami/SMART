clear all;clc; close all;
%% ========================================================================
%% This script generates 4 soil tickness layers based on data from CSIRO Australian Soil Grid.
%% Maximum soil depth is 2 m and four layers are:
%% 0 - 0.3 , 0.3 -0.6 , 0.6 - 1, 1 - 2 mm
%% 
%% INPUTS:
%%  1) Soil depth layer from CSIRO(.tif)
%%
%% OUTPUTS:
%%   1) soil_depth1.tif (...\Toolbox_Output\)
%%   2) soil_depth2.tif (...\Toolbox_Output\)
%%   3) soil_depth3.tif (...\Toolbox_Output\)
%%   4) soil_depth4.tif (...\Toolbox_Output\)
%%   5) soil_depth1_gis.asc (...\Toolbox_Output\) An ASCIIGRID file for ArcGIS or QGIS
%%   6) soil_depth2_gis.asc (...\Toolbox_Output\) An ASCIIGRID file for ArcGIS or QGIS
%%   7) soil_depth3_gis.asc (...\Toolbox_Output\) An ASCIIGRID file for ArcGIS or QGIS
%%   8) soil_depth4_gis.asc (...\Toolbox_Output\) An ASCIIGRID file for ArcGIS or QGIS
%%
%%   It calls the following function:
%%   UserRunInfo.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
tic;
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Input_Path  = strcat(usr_Path, '\Toolbox_Input\');
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

SoilDepthFile  = input('Enter the name of a soil depth file (.tif) : ', 's');
if     isempty(SoilDepthFile);                          error('Enter the name of soil depth .tif file');
elseif exist([Input_Path, SoilDepthFile], 'file') == 0; error('Warning: file does not exist:\n%s', [SoilDepthFile ,' does not exist in ', Input_Path]);
else   depth = double(imread(strcat(Input_Path, SoilDepthFile)));
end;

% Remove Nan
nodata_index = find(depth < 0);
depth(nodata_index) = NaN;

depthv = reshape(depth, [],1);
depth1m = depthv ./ 0.3;
depth1 = zeros(size(depthv));
depth2 = zeros(size(depthv));
depth3 = zeros(size(depthv));

ind1 = find(depth1m <= 1);
depth1(ind1) = depthv(ind1);

ind2 = find(depth1m > 1 & depth1m <= 2);
depth1(ind2) = 0.3;
depth2(ind2) = depthv(ind2)-0.3;

ind3 = find(depth1m > 2 & depth1m <= 3.33);
depth1(ind3) = 0.3;
depth2(ind3) = 0.3;
depth3(ind3) = depthv(ind3) - 0.6;

depth4 = 2 - (depth1 + depth2 + depth3) ;

figure(1)
subplot(2,2,1)
imagesc(reshape(depth1,size(depth,1), [] ))
title('top layer')
subplot(2,2,2)
imagesc(reshape(depth2,size(depth,1), [] ))
title('2nd layer')
subplot(2,2,3)
imagesc(reshape(depth3,size(depth,1), [] ))
title('3rd layer')
subplot(2,2,4)
imagesc(reshape(depth4,size(depth,1), [] ))
title('4th layer')

d1 = reshape(depth1,size(depth,1),[]);
d2 = reshape(depth2,size(depth,1),[]);
d3 = reshape(depth3,size(depth,1),[]);
d4 = reshape(depth4,size(depth,1),[]);

t = Tiff([Output_Path,'soil_depth1.tif'],'w');
tagstruct.ImageLength = size(d1,1);
tagstruct.ImageWidth = size(d1,2);
tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
tagstruct.BitsPerSample = 64;
tagstruct.SamplesPerPixel =1;
tagstruct.RowsPerStrip = 16;
tagstruct.SampleFormat  = Tiff.SampleFormat.IEEEFP;
tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
tagstruct.Software = 'MATLAB';
t.setTag(tagstruct);
t.write(d1);
t.close();
clear t

% Write thickness files
im2 = d2;
t = Tiff([Output_Path,'soil_depth2.tif'],'w');
t.setTag(tagstruct);
t.write(im2);
t.close();
clear t

im3 = d3;
t = Tiff([Output_Path,'soil_depth3.tif'],'w');
t.setTag(tagstruct);
t.write(im3);
t.close();
clear t

im4 = d4;
t = Tiff([Output_Path,'soil_depth4.tif'],'w');
t.setTag(tagstruct);
t.write(im4);
t.close();
clear t

%Write ASCIIGRID for ArcGIS
OutputFileName =[Output_Path,'soil_depth1_gis', '.asc'];
WriteASCIIGrid(OutputFileName, Output_Path, d1)

OutputFileName =[Output_Path,'soil_depth2_gis', '.asc'];
WriteASCIIGrid(OutputFileName, Output_Path, d2)

OutputFileName =[Output_Path,'soil_depth3_gis', '.asc'];
WriteASCIIGrid(OutputFileName, Output_Path, d3)

OutputFileName =[Output_Path,'soil_depth4_gis', '.asc'];
WriteASCIIGrid(OutputFileName, Output_Path, d4)

toc;