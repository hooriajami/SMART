function [ data_f ] = CS_LF_Diagonal_NW_Leftbank_Rightbank(sub_basin_id, r_LF1, r_ex, c_ex, type_hor, temp, k, Elev, LF, slp, LandCover1d, ClimateZone1d, SoilType1d,SoilType2d, SoilType3d, SoilType4d, SoilLyr1d, SoilLyr2d, SoilLyr3d, SoilLyr4d, data_f, sub_info)
%% ========================================================================
%%   This Matlab function generates right and left banks cross sections for diagonal (NW and SE) streams.
%%   It works for Two stream dirtections:   1) Type I: South East to Northwest(outlet)
%%                                          2) Type II: Northwest to SouthEast (outlet)
%%   It also obtains cross section properties from the topographic and land cover variables on a "LANDFORM BASIS".
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

%% Define number of cross sections for the right bank
r_LF1s = sort(r_LF1);                                                  % sort the row index for the stream cells

row_cs_index = r_LF1s(2) : 3: r_LF1s(end)-1;                            % Delineate the right and left bank cross sections using the index of first and last row (3) can change!

areaH  = sub_info(1,3);
areaR  = sub_info(1,4);
areaL  = sub_info(1,5);

str_direction= sub_info(1,2);

for j = 1 : numel(row_cs_index )
    
    row  =  row_cs_index(j);
    
    str_row = temp(row,:);                                            % From the landform 2d grid, select all the columns for a particular river row
    ind_river = find(str_row == 1);                                   % Select the stream cell
    
    if numel(ind_river) > 1
        
        ind_riverR = ind_river(1);
        ind_riverL = ind_river(2);
    else
        ind_riverR    = ind_river;
        ind_riverL    = ind_river;
    end
    
    [max_c_ex, I] =max(c_ex);
    test = temp(min(r_ex):row , ind_riverR: max_c_ex +1);
    
    col_IndexR = min(ind_riverR + (1:size(test,2))-1, size(temp,2));
    row_IndexR = row - (1:numel(col_IndexR))+1;
    
    CS_Type = 1;                                       % Right bank cross section code
    
    
    
    % Map the cells back to the linear index in the original grid to extract properties
    %     ind3 = sub2ind(size(temp),row_IndexR, repmat(col, numel(row_IndexR), 1));
    ind4 = sub2ind(size(temp),row_IndexR, col_IndexR);
    
    %check for non-zero cells
    ind= find(temp(ind4) ~= 0);
    if numel(ind) >= 1
        ind4 = ind4(ind)';
        
        uniq_LF = unique(LF(ind4));                  % Get unique landforms
        LF_sub_basin = zeros(size(temp));
        LF_sub_basin(ind4) = LF(ind4);
        for m = 1 : numel(uniq_LF)
            
            
            
            ind3 = find(LF_sub_basin == uniq_LF(m));%+ ind4(1)-1;        % Select right bank cells for a particular landform and adjust the index
            %ind3 = sub2ind(size(temp),t_ind, repmat(col, numel(t_ind), 1));     % Map the cells back to the linear index in the original grid to extract properties
            
            
            max_Elv  =  max(Elev(ind3));
            mean_slp =  mean(slp(ind3));
            m_LF     =  mode(LF(ind3));
            m_LC     =  mode(LandCover1d(ind3));
            m_climate =  mode(ClimateZone1d(ind3));
            m_soil   =  mode(SoilType1d(ind3));
            m_soil2     = mode(SoilType2d(ind3));
            m_soil3     = mode(SoilType3d(ind3));
            m_soil4     = mode(SoilType4d(ind3));
            mean_soild1 = nanmean(SoilLyr1d(ind3));
            mean_soild2 = nanmean(SoilLyr2d(ind3));
            mean_soild3 = nanmean(SoilLyr3d(ind3));
            mean_soild4 = nanmean(SoilLyr4d(ind3));
            
           
            data_f(k, 1)  = sub_basin_id;
            data_f(k, 2)  = 2;                                                 % Delineation type = pixel landform
            data_f(k, 3)  = type_hor;                                           % Stream orientation  horizontal
            data_f(k, 4)  = str_direction ;                                    % Get stream direction from the headwater
            data_f(k, 5)  = CS_Type;
            data_f(k, 6)  = j;
            data_f(k, 7)  = numel(ind3);                                       % cross section length in pixel
            data_f(k, 8)  = areaH+areaL+areaR;
            data_f(k, 9)  = areaH;
            data_f(k, 10) = areaR;
            data_f(k, 11) = areaL;
            data_f(k, 12) = m_LF;
            % data_f(k, 13) is zero for this type
            data_f(k, 14) = max_Elv;
            data_f(k, 15) = mean_slp;
            data_f(k, 16) = m_climate;
            data_f(k, 17) = m_LC;
            data_f(k, 18) = m_soil;
            %19 to 25 zero
            data_f(k, 26) = mean_soild1;
            data_f(k, 27) = mean_soild2;
            data_f(k, 28) = mean_soild3;
            data_f(k, 29) = mean_soild4;
            
            [I,J]=ind2sub(size(temp), ind3(end));
            data_f(k, 30) = I;
            data_f(k, 31) = J;
            % 32 to 35 zero
            
            data_f(k, 36) = m_soil2;
            data_f(k, 37) = m_soil3;
            data_f(k, 38) = m_soil4;
            
            k = k+1;
            dlmwrite([Output_Path, 'CS_coordinates_LF.txt' ],ind3','precision','%10d','-append', 'delimiter','\t','newline','pc');
            
        end
        
        
        
    end
    %% Now delineate the Left bank cross section for the selected column
    
    %    row_IndexL = find(str_col(ind_riverL: end) ~= 0)+ ind_riverL - 1;
    [min_c_ex, I] =min(c_ex);
    %      test = temp(row: r_ex(I)+1, min_c_ex: ind_riverL);
    test = temp(row: max(r_ex), min_c_ex: ind_riverL);
    
    
    col_IndexL = min(ind_riverL - (1 : size(test,2))+1, size(temp,2));
    row_IndexL = row + (1 : numel(col_IndexL))-1;
    
    CS_Type = 2;                                                      % Left bank cross section code
    
    ind4 = sub2ind(size(temp),row_IndexL, col_IndexL);
    
    %check for non-zero cells
    ind= find(temp(ind4) ~= 0);
    if numel(ind) >= 1
        ind4 = ind4(ind)';
        %      disp(ind4)
        
        
        uniq_LF = unique(LF(ind4));                  % Get unique landforms
        LF_sub_basin = zeros(size(temp));
        LF_sub_basin(ind4) = LF(ind4);
        
        for i = 1 : numel(uniq_LF)
            
            ind3 = find(LF_sub_basin == uniq_LF(i)); %+ ind4(1)-1;
            
            max_Elv  =  max(Elev(ind3));
            mean_slp =  mean(slp(ind3));
            m_LF     =  mode(LF(ind3));
            m_LC     =  mode(LandCover1d(ind3));
            m_climate =  mode(ClimateZone1d(ind3));
            m_soil   =  mode(SoilType1d(ind3));
            m_soil2     = mode(SoilType2d(ind3));
            m_soil3     = mode(SoilType3d(ind3));
            m_soil4     = mode(SoilType4d(ind3));
            mean_soild1 = nanmean(SoilLyr1d(ind3));
            mean_soild2 = nanmean(SoilLyr2d(ind3));
            mean_soild3 = nanmean(SoilLyr3d(ind3));
            mean_soild4 = nanmean(SoilLyr4d(ind3));
            
          
            
            data_f(k, 1)  = sub_basin_id;
            data_f(k, 2)  = 2;                                                 % Delineation type = pixel landform
            data_f(k, 3)  = type_hor;                                           % Stream orientation  horizontal
            data_f(k, 4)  = str_direction ;                                    % Get stream direction from the headwater
            data_f(k, 5)  = CS_Type;
            data_f(k, 6)  = j;
            data_f(k, 7)  = numel(ind3);                                       % cross section length in pixel
            data_f(k, 8)  = areaH+areaL+areaR;
            data_f(k, 9)  = areaH;
            data_f(k, 10) = areaR;
            data_f(k, 11) = areaL;
            data_f(k, 12) = m_LF;
            % data_f(k, 13) is zero for this type
            data_f(k, 14) = max_Elv;
            data_f(k, 15) = mean_slp;
            data_f(k, 16) = m_climate;
            data_f(k, 17) = m_LC;
            data_f(k, 18) = m_soil;
            %19 to 25 zero
            data_f(k, 26) = mean_soild1;
            data_f(k, 27) = mean_soild2;
            data_f(k, 28) = mean_soild3;
            data_f(k, 29) = mean_soild4;
            %         data_f(k, 30) = t_ind(end);
            [I,J]=ind2sub(size(temp), ind3(end));
            data_f(k, 30) = I;
            data_f(k, 31) = J;
            % 32 to 35 zero
            data_f(k, 36) = m_soil2;
            data_f(k, 37) = m_soil3;
            data_f(k, 38) = m_soil4;
            
            k = k+1;
            dlmwrite([Output_Path, 'CS_coordinates_LF.txt' ],ind3','precision','%10d','-append', 'delimiter','\t','newline','pc');
        end
        
        
    end
    
end

end  % End function CS_Pixel_Horizontal_Leftbank_rightbank.m


