clear all;clc; close all;
%% ========================================================================
%% This script generates soil texture class file based on the USDA soil texture
%% classification for each soil material. Total number of soil material is 4.  
%%
%% INPUTS:
%%  1) percent sand grid file (.tif) for each soil material 
%%  2) percent clay grid file (.tif) for each soil material
%%
%% OUTPUTS:
%%  1) soiltype_usda1.txt
%%  2) soiltype_usda2.txt
%%  3) soiltype_usda3.txt
%%  4) soiltype_usda4.txt
%%  5) soiltype_usda1_gis.asc  An ASCIIGRID file for ArcGIS or QGIS
%%  6) soiltype_usda2_gis.asc  An ASCIIGRID filefor ArcGIS or QGIS 
%%  7) soiltype_usda3_gis.asc  An ASCIIGRID filefor ArcGIS or QGIS
%%  8) soiltype_usda4_gis.asc  An ASCIIGRID filefor ArcGIS or QGIS
%%
%%   It calls the following function:
%%   UserRunInfo.m
%%   Soil_Classification.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
tic;
RunInfo  = UserRunInfo; 
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Input_Path  = strcat(usr_Path, '\Toolbox_Input\');
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

 for i = 1 : 4

n1 = ['Enter the name of %Sand file for',' ','Layer--' num2str(i), '(.tif) :']; 
pSandFile  = input(n1, 's');

if     isempty(pSandFile);                          error('Enter the name of %Sand .tif file');
elseif exist([Input_Path, pSandFile], 'file') == 0; error('Warning: file does not exist:\n%s', [pSandFile ,' does not exist in ', Input_Path]);  
else   p_Sand = double(imread(strcat(Input_Path, pSandFile))); 
end;

n2 = ['Enter the name of %Clay file for',' ','Layer--' num2str(i), '(.tif) :']; 
pClayFile  = input(n2, 's');
if     isempty(pClayFile);                         error('Enter the name of %Clay .tif file');
elseif exist([Input_Path,pClayFile], 'file') == 0; error('Warning: file does not exist:\n%s', [pClayFile,' does not exist in ', Input_Path]);  
else   p_Clay = double(imread(strcat(Input_Path, pClayFile)));  
end;

ind_NaN = find(p_Clay < 0);
p_Sand(ind_NaN) = NaN;
p_Clay(ind_NaN) = NaN;

ind_NaN = find(p_Sand < 0);
p_Sand(ind_NaN) = NaN;
p_Clay(ind_NaN) = NaN;

var1            = [reshape(p_Sand, [], 1), reshape(p_Clay, [], 1)];
nan_var         = ~isnan(var1);
texture_class   = nan(size(nan_var, 1), 1);

var1(any(isnan(var1),2),:)=[];
var1 = var1./ 100;
test = var1(:,1)+ var1(:,2);

[SC, SC_Num, silt] = Soil_Classification(var1(:,1), var1(:,2), 'usda');

ind = find(nan_var(:,1) == 1);
texture_class(ind,1) = SC_Num;

soilClassGrid = reshape(texture_class, size(p_Sand,1), []);

figure(i)
imagesc(soilClassGrid)
title(['USDA Soil Texture Class', ' ', 'Layer', num2str(i)])

if   exist(strcat(Output_Path,'soiltype_usda', num2str(i),'.txt'), 'file'); error('Warning:\n%s', [strcat('soiltype_usda', num2str(i),'.txt'), ' already exists in ', Output_Path] ); 
else dlmwrite(strcat(Output_Path,'soiltype_usda', num2str(i),'.txt'),soilClassGrid,'delimiter','\t');
disp([strcat(Output_Path,'soiltype_usda', num2str(i),'.txt'), '  is written.' ])
end


% Write ASCIIGRID for ArcGIS
OutputFileName =[Output_Path,'soiltype_usda', num2str(i),'_gis.asc'];

if   exist(OutputFileName, 'file') ; error('Warning:\n%s', [strcat('soiltype_usda', num2str(i),'_gis.asc'), ' already exists in ', Output_Path] );      
else WriteASCIIGrid(OutputFileName, Output_Path, soilClassGrid)
    disp([strcat(Output_Path,'soiltype_usda', num2str(i),'.asc'), '  is written.' ])
    
end

clear soilClassGrid

 end

toc;