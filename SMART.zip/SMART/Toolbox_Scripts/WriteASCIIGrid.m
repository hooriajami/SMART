function WriteASCIIGrid( OutputFileName, Output_Path, data )
%% ========================================================================
%%   This Matlab function writes ArcGIS ASCII grid files.
%%   
%%   INPUTS:
%%   1) ArcGIS_Header.asc
%%   2) User defines : data, outputfile name and path.
%%
%%   OUTPUTS:
%%   *.asc file 
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

HeaderFileName =[Output_Path,'ArcGIS_Header.asc'];
fileID = fopen(HeaderFileName);
C = textscan(fileID,'%s %s %s %s %s %s');
fclose(fileID);
a = char(C{1});
b = char(C{2});
fid = fopen(OutputFileName,'w');
fprintf (fid, '%s%s\n', a(1,:), b(1,:));
fprintf (fid, '%s%s\n', a(2,:), b(2,:));
fprintf (fid, '%s%s\n', a(3,:), b(3,:));
fprintf (fid, '%s%s\n', a(4,:), b(4,:));
fprintf (fid, '%s%s\n', a(5,:), b(5,:));
fprintf (fid, '%s%s%s\n', a(6,:),' ', b(6,:));
fclose(fid);
clear a b C

dlmwrite(OutputFileName,data,'-append','delimiter','\t');
end

