clear all;clc; close all;
%% ========================================================================
%%   This Matlab script writes the climatezone.txt file for every climate zone in a catchment depending on the delineation approach.
%%
%%   INPUTS:
%%   1) User defines ones of the delineation types and the code reads respective .mat database file from  '...\Toolbox_Output\
%%     1 = DISTRIBUTED Pixel based delineation                    (6a)
%%     2 = DISTRIBUTED LANDFORM based delineation                 (6b)
%%     3 = ECS Left bank/right bank/headwater delineation         (6c)
%%     4 = ECS Soil type delineation                              (6d)
%%  2) Climate time series for each climate zone in the domain with the following information in the header (1)ClimateZone	(2)Date	(3)T.Max	(4)T.Min	(5)Rain	(6)Evap	(7)Radn
%%  3) Monthly LAI climatology data or the default parameters provided in the toolkit.
%%
%%   OUTPUTS:
%%   For every cross section ClimayZone_Cl_*.txt' in (...\Model_Input\DEL TYPE)
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%   WriteClimateZoneFile.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
Kpan =  RunInfo.Kpan;

addpath([usr_Path, '\Toolbox_Scripts'])
Input_Path  = strcat(usr_Path, '\Toolbox_Input\');
Output_Path = strcat(usr_Path, '\Toolbox_Output\');
Param_Path  = strcat(usr_Path, '\Toolbox_Parameter_Files\');
Model_Path  = strcat(usr_Path, '\Model_Input\');

%% Get user input
CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');

if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
else
    error('This delineation does not exist!!!');
end

InputLAIMonth  = input('Input Monthly LAI climatology file (.csv) : ', 's');
if     isempty(InputLAIMonth);                           error('Enter the name of LAI file');
elseif exist([Param_Path, InputLAIMonth], 'file') == 0; error('Warning: file does not exist:\n%s', InputLAIMonth);
    
end;

%%
if CS_Del_Type == 1
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');
    FileName = [Output_Path,'data_CS_Distributed_Pixel.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Distributed_Pixel.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Get unique cliamte types for the catchment
    climate_id  = data(:, 16) ;
    uniq_climate = unique(climate_id );
    clear climate_id data
    
    for j = 1 : numel(uniq_climate)
        
        % Input File Name which has all the information
        n1 = ['Input climate input file (.csv)', ' ', 'for zone', ' ', num2str(uniq_climate(j)), ': ' ];
        InputClimateFile = input(n1, 's');
        
        %Read the climate file
        %Header Line 1: (1)ClimateZone	(2)Date	(3)T.Max	(4)T.Min	(5)Rain	(6)Evap	(7)Radn
        %Header Line 2: (A/B/C/D)	(dd/mm/yyyy)	(oC)	(oC)	(mm)	(mm)	(MJ/m2)
        fid = fopen([Input_Path,InputClimateFile], 'rt');
        data = textscan(fid, '%s %s %f %f %f %f %f ','Delimiter',',', 'CollectOutput',1, 'HeaderLines', 2);
        fclose(fid);
        
        WriteClimateZoneFile(uniq_climate(j),data, Param_Path , Model_Path, InputLAIMonth, Kpan)
        
    end
    
    %%
elseif CS_Del_Type == 2
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    
    FileName = [Output_Path,'data_CS_Landform.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Landform.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Get unique cliamte types for the catchment
    climate_id  = data(:, 16) ;
    uniq_climate = unique(climate_id );
    clear climate_id data
    
    for j = 1 : numel(uniq_climate)
        
        %Input File Name which has all the information
        n1 = ['Input climate input file (.csv)', ' ', 'for zone', ' ', num2str(uniq_climate(j)), ': ' ];
        InputClimateFile = input(n1, 's');
        
        %Read the climate file
        %Header Line 1: (1)ClimateZone	(2)Date	(3)T.Max	(4)T.Min	(5)Rain	(6)Evap	(7)Radn
        %Header Line 2: (A/B/C/D)	(dd/mm/yyyy)	(oC)	(oC)	(mm)	(mm)	(MJ/m2)
        fid = fopen([Input_Path,InputClimateFile], 'rt');
        data = textscan(fid, '%s %s %f %f %f %f %f ','Delimiter',',', 'CollectOutput',1, 'HeaderLines', 2);
        fclose(fid);
        
        WriteClimateZoneFile(uniq_climate(j),data, Param_Path , Model_Path, InputLAIMonth, Kpan)
        
    end
    
    
    %%
elseif CS_Del_Type == 3
        
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');
    
    FileName = [Output_Path,'data_ECS_LB_RB_H_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_LB_RB_H_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Get unique cliamte types for the catchment
    climate_id  = data(:, 16) ;
    uniq_climate = unique(climate_id );
    clear climate_id data
    
    for j = 1 : numel(uniq_climate)
        
        %Input File Name which has all the information
        n1 = ['Input climate input file (.csv)', ' ', 'for zone', ' ', num2str(uniq_climate(j)), ': ' ];
        InputClimateFile = input(n1, 's');
        
        %Read the climate file
        %Header Line 1: (1)ClimateZone	(2)Date	(3)T.Max	(4)T.Min	(5)Rain	(6)Evap	(7)Radn
        %Header Line 2: (A/B/C/D)	(dd/mm/yyyy)	(oC)	(oC)	(mm)	(mm)	(MJ/m2)
        fid = fopen([Input_Path,InputClimateFile], 'rt');
        data = textscan(fid, '%s %s %f %f %f %f %f ','Delimiter',',', 'CollectOutput',1, 'HeaderLines', 2);
        fclose(fid);
        
        WriteClimateZoneFile(uniq_climate(j),data, Param_Path , Model_Path, InputLAIMonth, Kpan)
        
    end
    
    
    %%
elseif CS_Del_Type == 4
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_Soil_Type_CS\');
    
    FileName = [Output_Path,'data_ECS_SoilType_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_SoilType_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Get unique cliamte types for the catchment
    climate_id  = data(:, 16) ;
    uniq_climate = unique(climate_id );
    clear climate_id data
    
    for j = 1 : numel(uniq_climate)
        
        %Input File Name which has all the information
        n1 = ['Input climate input file (.csv)', ' ', 'for zone', ' ', num2str(uniq_climate(j)), ': ' ];
        InputClimateFile = input(n1, 's');
        
        %Read the climate file
        %Header Line 1: (1)ClimateZone	(2)Date	(3)T.Max	(4)T.Min	(5)Rain	(6)Evap	(7)Radn
        %Header Line 2: (A/B/C/D)	(dd/mm/yyyy)	(oC)	(oC)	(mm)	(mm)	(MJ/m2)
        fid = fopen([Input_Path,InputClimateFile], 'rt');
        data = textscan(fid, '%s %s %f %f %f %f %f ','Delimiter',',', 'CollectOutput',1, 'HeaderLines', 2);
        fclose(fid);
        
        WriteClimateZoneFile(uniq_climate(j),data, Param_Path , Model_Path, InputLAIMonth, Kpan)
        
    end
    %%
    
end














