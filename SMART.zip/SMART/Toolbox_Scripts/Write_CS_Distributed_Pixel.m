function [data_f] = Write_CS_Distributed_Pixel(var1, data_f)
%% ========================================================================
%%   This Matlab function writes pixel files for distributed cross section delineation approach based on U3M-2D format.
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%
%%   This function is called by:
%%   CS_Pixel_*.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');

demRes  =  RunInfo.DEMRes;
LyrTickness = RunInfo.LyrThickness;              %thickness of soil layers [m]
Nodata = -9999;

% Outputfile Header
line1 = 'Seq Elev Landuse Soils Md0   Md1    Md2     Md3   ML1 ML2 ML3 ML4 Salinity1 Salinity2 Salinity3 Salinity4 ClimateZone Recharge/Discharge/Stream D-infinity_angle GFS Neighbours0-7';
line2 = '(long)(M)(T/P/C/O)(int)(M)   (M)    (M)     (M)                    (dS/m)   (dS/m)    (dS/m)     (dS/m)    (A/B/C/D)       (R/D/S)               (degrees)      (int)  (long)';
line3 = '0         1         2         3         4         5         6         7         8         9         10        11        12        13        14        15';
line4 = '0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789';


if var1.m_LF(1) < var1.m_LF(end)
    count = (1:size(var1,1))';
    t = table(count);
    t = [t var1];
    [d, index] = sortrows(t, 1,'descend' );
    var1 = d(:,2:end);
end
% Add additional dummy record for discharge cell
var_basin_soil = [var1; var1(end,:)];

% Derive input variables from VAR
Elev_SoilType = var_basin_soil.max_Elv;
Slp_SoilType  = var_basin_soil.mean_slp ;
Seq = linspace(1, numel(Elev_SoilType), numel(Elev_SoilType));
Seq = Seq';

% Adjust elevation based on slope of landform
for x = 2 : numel(Elev_SoilType)
    Elev_SoilType(x) = Elev_SoilType(x-1) - (Slp_SoilType(x-1) .* demRes );
end

clear  Slp_SoilType
Soil_SoilType1 = var_basin_soil.m_soil;
Soil_SoilType = Soil_SoilType1;

k = size(data_f,1) ;
[uniq_m_soil, ia, ic] = unique(Soil_SoilType1, 'stable');
for c = 1  : numel(uniq_m_soil);
    data_f(k, 21+c) = c;
    Soil_Pixel_ind = find(Soil_SoilType1 == uniq_m_soil(c));
    Soil_SoilType(Soil_Pixel_ind) = c;
    
end


% Compute Horizon elevation
Md3 = Elev_SoilType - var_basin_soil.mean_soild1;
Md2 = Md3 - var_basin_soil.mean_soild2;
Md1 = Md2 - var_basin_soil.mean_soild3;
Md0 = Md1 - var_basin_soil.mean_soild4;

% Get MLs
numLyr = [round(var_basin_soil.mean_soild4 ./LyrTickness), round(var_basin_soil.mean_soild3 ./LyrTickness),round(var_basin_soil.mean_soild2 ./LyrTickness),round(var_basin_soil.mean_soild1 ./LyrTickness)];
cumNumLyr = cumsum(numLyr,2);

Salinity = ones(numel(Seq),4).* 0.3;
RDS = zeros(numel(Seq),1);     %zero recharge cell, D discharge cell = 1
RDS(numel(RDS)) = 1;           %One discharge cell
Dinf =  zeros(numel(Seq),1);
GFS = 4;
GFS = repmat(GFS, numel(Seq),1);
dum = repmat(Nodata, numel(Seq), 3);
Neighbor1 = [Seq(2:numel(Seq)); Nodata];
Neighbor2 = [Nodata; Seq(1:(numel(Seq)-1))];


% Map back the character field, landuse, climate, Recharge/Discharge cells
LandIDs = char(numel(Seq), 1);
index1 = find(var_basin_soil.m_LC == 1);
LandIDs(index1) = 'T';
index2 = find(var_basin_soil.m_LC == 2);
LandIDs(index2) = 'P';
index3 = find(var_basin_soil.m_LC == 3);
LandIDs(index3) = 'C';

climateZones = char(numel(Seq), 1);
index1 = find(var_basin_soil.Var7 == 1 );
climateZones(index1) = 'A';
index1 = find(var_basin_soil.Var7 == 2 );
climateZones(index1) = 'A';
index1 = find(var_basin_soil.Var7 == 3 );
climateZones(index1) = 'A';
index1 = find(var_basin_soil.Var7 == 4 );
climateZones(index1) = 'A';

RDSs = char(numel(Seq), 1);
index1 = find(RDS == 1);
RDSs(index1) = 'D';
index2 = find(RDS == 0);
RDSs(index2) = 'R';

% climateName = unique(climateZones)  %% CHANGE

% OutputFileName = [Model_Path, 'SB_', num2str(var_basin_soil.Var1(1)),'_CS_', num2str(data_f(end, 5)), '_Or_', num2str(data_f(end, 3)), '_Dir_', num2str(data_f(end,4)), '_id_', num2str(data_f(end,6)),'_Cl_',climateName,'_PixelFile.txt'];   %should change Name
OutputFileName = [Model_Path, 'SB_', num2str(var_basin_soil.Var1(1)),'_CS_', num2str(data_f(end, 5)), '_Or_', num2str(data_f(end, 3)), '_Dir_', num2str(data_f(end,4)), '_id_', num2str(data_f(end,6)),'_PixelFile.txt'];   %should change Name
% disp(OutputFileName)
fid = fopen(OutputFileName,'w');
fprintf (fid, '%s\n%s\n%s\n%s\n', line1, line2, line3, line4);

for n = 1 : Seq(end)
    
    fprintf(fid,'%5d%8.2f%2s%2d%8.2f%8.2f%8.2f%8.2f%4d%4d%4d%4d%8.4f%8.4f%8.4f%8.4f%2s%2s%7.3f%2d%6d%6d%6d%6d%6d%6d%6d%6d\t\n',Seq(n,:), Elev_SoilType(n,:), LandIDs(n,:), Soil_SoilType(n,:), Md0(n,:),Md1(n,:), Md2(n,:),Md3(n,:), cumNumLyr(n,:), Salinity(n,:),climateZones(n,:), RDSs(n,:), Dinf(n,:), GFS(n,:) , dum(n,:), Neighbor1(n,:), dum(n,:), Neighbor2(n,:));
end
fclose(fid) ;
disp(OutputFileName)
clear var_basin_soil

end

