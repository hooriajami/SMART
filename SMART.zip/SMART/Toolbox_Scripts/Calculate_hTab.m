function [ hTab ] = Calculate_hTab(NTab, hTabN, hTab1 )

%% ========================================================================
%%   This Matlab function calculates entries in the pressure head table.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================


temp  = log10(-hTabN);
temp1 = log10(-hTab1);
temp  = temp - temp1;
dlh   = temp/(NTab - 1); %(m)
hTab  = zeros(NTab , 1);

for count = 1 : NTab
    temp          = log10(-hTab1) + (count-1)*dlh;
    hTab(count,1) = -power(10.0,temp);
    
end

end

