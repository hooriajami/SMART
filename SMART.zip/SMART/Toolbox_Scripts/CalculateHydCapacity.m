function [ hydCapacity ] = CalculateHydCapacity(pressureHead, Model, alpha , alphaInv, nn, nnInv, mm, mmInv, Qs, Qa, Qm)

%% ========================================================================
%%   This Matlab function calculates hydraulic capacity or d(theta)/dh for a given pressure head
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
temp = 0.0; temp1 = 0.0;
C1 = 0.0; C2 = 0.0;
% 			double Qees;
% 			double HMin,Hs,HH;
% 			double hydCapacity;

switch Model
    
    case 1
        %van Genuchten soil hydraulic Model with Mualem's pore distribution
        %Vogel and Cislerova soil hydraulic Model with Mualem's pore distribution
        temp  = max(alpha,1.0);
        temp1 = -power(1.0e300,nnInv);
        HMin  = temp1/temp;
        
        HH = max(pressureHead,HMin);
        
        temp = (Qs-Qa)/(Qm-Qa);
        Qees = min(temp,.9999999999999999999);
        
        temp = power(Qees,-mmInv);
        temp = temp - 1.0;
        temp = power(temp,nnInv);
        Hs   = -alphaInv*temp;
        
        if(pressureHead < Hs)
            
            temp  = - alpha * HH;
            temp  = power(temp,nn);
            temp  = 1.0 + temp;
            temp1 = -mm - 1.0;
            C1    = power(temp,temp1);
            
            temp  = (Qm - Qa)*mm*nn;
            temp1 = power(alpha,nn);
            temp  = temp*temp1;
            temp1 = nn-1.0;
            temp1 = power(-HH,temp1);
            C2    = temp*temp1*C1;
            
            hydCapacity = max(C2,1.0e-37);
            
            
        else
            
            hydCapacity = 0.0;
        end
        
        
    case 2
        %Model = 2 Brooks and Corey model
        Hs = -alphaInv;
        
        if (pressureHead < Hs)
            
            temp  = Qs - Qr;
            temp  = temp*nn;
            temp1 = power(alpha,-nn);
            temp  = temp*temp1;
            temp1 = -nn - 1.0;
            temp1 = power(-pressureHead,temp1);
            C2    = temp * temp1;
            
            hydCapacity = max(C2,1.0e-37);
            
        else
            
            hydCapacity = 0.0;
        end
        
end

end

