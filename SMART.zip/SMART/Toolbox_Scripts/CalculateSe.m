function [ specificSaturation ] = CalculateSe(pressureHead, Model, Qs, Qa, Qm, mm, mmInv, nn, nnInv, alpha, alphaInv)

%% ========================================================================
%%   This Matlab function calculates specific saturation (Se) for a given pressure head.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

temp = 0.0; temp1 = 0.0;
% 			double Qe,Qee,Qees;
% 			double HMin,Hs,HH;
% 			double specificSaturation;

switch Model
    
    case 1
        %van Genuchten soil hydraulic Model with Mualem's pore distribution
        %Vogel and Cislerova soil hydraulic Model with Mualem's pore distribution
        
        temp = (Qs-Qa)/(Qm-Qa);
        Qees = min(temp,.9999999999999999999);
        
        temp = power(Qees,-mmInv);
        temp = temp - 1.0;
        temp = power(temp,nnInv);
        Hs   = -alphaInv*temp;
        
        if(pressureHead < Hs)
            
            temp  = max(alpha,1.0);
            temp1 = -power(1.0e300,nnInv);
            HMin  = temp1/temp;
            
            HH = max(pressureHead,HMin);
            
            temp = - alpha * HH;
            temp = power(temp,nn);
            temp = 1.0 + temp;
            Qee  = power(temp,-mm);
            
            temp  = Qm - Qa;
            temp  = temp*Qee;
            temp1 = Qs - Qa;
            Qe    = temp/temp1;
            specificSaturation = max(Qe,1.0e-37);
            
        else
            
            specificSaturation = 1.0;
        end
        
        
    case 2
        % Model = 2 Brooks and Corey model
        
        Hs = -alphaInv;
        
        if (pressureHead < Hs)
            
            temp = -alpha*pressureHead;
            Qe = power(temp,-nn);
            
            specificSaturation = max(Qe,1.0e-37);
            
        else
            
            specificSaturation = 1.0;
            
        end
        
        
end


end

