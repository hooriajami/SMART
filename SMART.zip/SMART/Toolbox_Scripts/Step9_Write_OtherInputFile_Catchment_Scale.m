clear all;clc
%% ========================================================================
%%   This Matlab script writes the OtherInputFile.txt file for every cross section in a sub-basin depending on the delineation approach.
%%
%%   INPUTS:
%%   1) User defines ones of the delineation types and the code reads respective .mat database file from  '...\Toolbox_Output\
%%   1 = DISTRIBUTED Pixel File delineation          (6a)
%%   2 = DISTRIBUTED LANDFORM Pixel File delineation (6b)
%%   3 = ECS Left bank/right bank/head water         (6c)
%%   4 = ECS Soil type                               (6d)
%%  2) User defines the initial condition, rain band and deltaRband.
%%  3) root_distribution.xlsx parameters will be read from the default provided in the code.
%%
%%   OUTPUTS:
%%   For every cross section InputOtherData_S_*_SB_*.txt' in (...\Model_Input\DEL TYPE)
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%   OutputPixelIndex.m
%%   GetOtherParameters.m
%%   WriteOtherInputFile.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo     = UserRunInfo;
usr_Path    = RunInfo.UserPath;
addpath([usr_Path, '\Toolbox_Scripts'])

Output_Path = strcat(usr_Path, '\Toolbox_Output\');
Model_Path  = strcat(usr_Path, '\Model_Input\');

%% Get user defined parameters from the user
% Get initial condition from the user
InitCondMat = nan(4,1);
for i =  1 : 4
    n1 = ['Parameter for initial soil moisture content of material', ' ', num2str(i), ' ', '(0-1):'];
    txt = input(n1) ;  %theta_initial = thetaR + p (thetaS � thetaR)
    if isempty(txt);
        InitCondMat(i,1) = 1;
    else InitCondMat(i,1) = txt;
    end;
end

rainBand  = zeros(5,1);
for i =  1 : 5
    n1 =  [ 'Input Rainfall band', ' ', num2str(i), ' ', '(mm/day):'];
    txt = input(n1) ;
    if isempty(txt); rainBand(i,1) = 0;
    else rainBand(i,1) = txt;
    end;
end

if any(rainBand)== 0; rainBand = [5;10;20;40;1000]; end;
disp(['Rain Bands are : ' num2str(rainBand(1)),',',num2str(rainBand(2)),',',num2str(rainBand(3)),',',num2str(rainBand(4)), ',', num2str(rainBand(5)) ]);

deltaRBand  = zeros(5,1);
for i =  1 : 5
    n1 = [ 'Input Time step band', ' ', num2str(i), ' ', '(sec):'];
    txt = input(n1);
    if isempty(txt); deltaRBand(i,1) = 0;
    else deltaRBand(i,1) = txt;
    end;
end
if any(deltaRBand)== 0; deltaRBand = [3600;2400;1560;600;300]; end;
disp(['Time step bands are (sec): ' num2str(deltaRBand(1)),',',num2str(deltaRBand(2)),',',num2str(deltaRBand(3)),',',num2str(deltaRBand(4)), ',', num2str(deltaRBand(5)) ]);


CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');

if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
    
else
    error('This delineation does not exist!!!');
end


%% User defined parameters read from User RunInfo
pixelSize                     = RunInfo.DEMRes;
gamRecharge                   = RunInfo.gamRecharge;
Transp_sigmaO                 = RunInfo.Transp_sigmaO;
Transp_sigmaU                 = RunInfo.Transp_sigmaU;
timeStepMultiplier            = RunInfo.TimeStepMultiplier;

horFactor                     = RunInfo.horFactor;
preferentialFlowFactor        = RunInfo.PreferentialFlowFactor;
ArithmeticGeometricMeanCutoff = RunInfo.ArithmeticGeometricMeanCutoff;
HorizontalTransferEquation    = RunInfo.HorizontalTransferEquation;

% Fixed parameters
numberOfGFS                  = RunInfo.numberOfGFS;               %equal to 1 in U3M-2D
numberOfFlagLF               = RunInfo.numberOfFlagLF;            %lanform flag, dummy here
FlowDirectionModel           = RunInfo.FlowDirectionModel;        %For cross section modeling
DELTAT                       = RunInfo.DELTAT;                    %number of seconds in a day for daily model run
numberOfStressParameters     = RunInfo.numberOfStressParameters;  %plant water stress parameters % thFC[m] thWT[m] thWP[m] thWC[m]
InitCondLF                   = RunInfo.InitCondLF;
numberOfVerticalDeltatBands  = RunInfo.numberOfVerticalDeltatBands;
FluxFactor                   = RunInfo.FluxFactor ;

% pixelSize          = input('Enter resolution of the DEM : ');
% if isempty(pixelSize );  error('Enter a valid number'); end;
%
% gamRecharge        = input('Moisture stress threshold multiplier(default=0.5) : ');           %See U3M1D %multiplier used in thetaRechOverstory & thetaRechUnderstory  calculation  thetaRechUnderstory = thWP[soilMaterial] + gamRecharge * (thFC[soilMaterial] - thWP[soilMaterial]);
% if isempty(gamRecharge); gamRecharge = 0.5; end;
%
% Transp_sigmaO      = input('Overstory Transpiration compensation parameter (default=0): ');	  %multiplier used in overstory transpiration calculation (-)(from GUI to Model manager)
% if isempty(Transp_sigmaO); Transp_sigmaO = 0.0; end;
%
% Transp_sigmaU      = input('Understory Transpiration compensation parameter (default=0) : '); %multiplier used in understory transpiration calculation (-)(from GUI to Model manager)
% if isempty(Transp_sigmaU); Transp_sigmaU = 0.0; end;
%
% timeStepMultiplier =  input('Time step multiplier (default=1.3): ');                          %See U3M1D
% if isempty(timeStepMultiplier); timeStepMultiplier = 1.3; end;

% horFactor                   =  input('Horizontal flow factor (0.5-1) Fast flow (0.5) slow flow(1): ');    %Kbar = horFactor*K_p + (1-horFactor)*K_k; horFactor range (0.5-1) equals 1 for faster horizontal flow and 0.5 for slow horizontal flow
% if        isempty(horFactor);                    error('Enter a number!');
% elseif    horFactor < 0 || horFactor > 1;        error('Enter a valid number');
% end;
%
% preferentialFlowFactor        =  input('Enter preferential flow factor 0-1 : ');                %proportion of excess soil moisture that is passed downslope as preferential flow; preferentialFlowFactor range (0-1) equals 1 for all excess water transfer as preferntial flow and 0 for no preferential flow
% if        isempty(preferentialFlowFactor);                            error('Enter a number!');
% elseif    preferentialFlowFactor < 0 || preferentialFlowFactor > 1;   error('Enter a valid number between 0 and 1');
% end;
%
% ArithmeticGeometricMeanCutoff  =  input('Arithmetic Geometric Mean Cutoff (set >= 1 for this parameter to be ineffective): ');
% if   isempty(ArithmeticGeometricMeanCutoff);    error('Enter a number'); end
%
%
% HorizontalTransferEquation     =  input('Horizontal transfer equation (Unsat = 1 sat = 2): ');
% if        isempty(HorizontalTransferEquation);                                  error('Enter 1 or 2');
% elseif    HorizontalTransferEquation ~= 1 && HorizontalTransferEquation ~= 2;   error('Enter 1 or 2');
% end;
%%
if CS_Del_Type == 1
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');
    FileName = [Output_Path,'data_CS_Distributed_Pixel.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Distributed_Pixel.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Cross section unique number
    CS_id = (1:size(data,1))';
    data_CS = [CS_id, data(:, 1:17)];
    clear data
    
    % filename = 'root_distribution.xlsx';
    filename = RunInfo.RootDistributionFileParameter;
    rootDist = xlsread([usr_Path, '\Toolbox_Parameter_Files\',filename]);
    
    % Read from parameter folder
    bo_tree_from_top    = rootDist(:,1);       %overstory root distribution (-)
    bu_tree_from_top    = rootDist(:,2);       %understory root distribution (-)
    bu_crop_from_top    = rootDist(:,3);       %understory root distribution (-)
    bu_pasture_from_top = rootDist(:,4);       %understory root distribution (-)
    aSoil_from_top      = rootDist(:,5);       %soil evap distribution (-)
    
    tic;
    for i = 1 :  size(data_CS,1)
        record = data_CS(i,:);
        
        PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_CS_', num2str(record(6)), '_Or_', num2str(record(4)), '_Dir_', num2str(record(5)), '_id_', num2str(record(7)),'_PixelFile.txt'];
        
        ClimateFileName = strcat(Model_Path, 'ClimateZone', '_Cl_', num2str(record(17)), '.txt') ;
        
        ShpFileName = strcat(Model_Path,'InputSHPTable_S_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        SoilParName = strcat(Model_Path, 'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        [NumPixels, numberOfSoils, numberOfClimateZones, numberOfPixelFiles, outputPixelSequence, simPeriod, numberOfLayersMax, K_GFS, NumSoilMaterial] = GetOtherParameters( PixelFileName, ClimateFileName, ShpFileName, SoilParName);
        
        clear ClimateFileName PixelFileName ShpFileName SoilParName
        
        %         % filename = 'root_distribution.xlsx';
        %         filename = RunInfo.RootDistributionFileParameter;
        %         rootDist = xlsread([usr_Path, '\Toolbox_Parameter_Files\',filename]);
        %
        %         % Read from parameter folder
        %         bo_tree_from_top    = rootDist(:,1);       %overstory root distribution (-)
        %         bu_tree_from_top    = rootDist(:,2);       %understory root distribution (-)
        %         bu_crop_from_top    = rootDist(:,3);       %understory root distribution (-)
        %         bu_pasture_from_top = rootDist(:,4);       %understory root distribution (-)
        %         aSoil_from_top      = rootDist(:,5);       %soil evap distribution (-)
        
        % Write OtherInputFile
        
        [ OutputFileName ] = WriteOtherInputFile(Model_Path, record, NumPixels,NumSoilMaterial, numberOfSoils,numberOfGFS, numberOfFlagLF,simPeriod,numberOfClimateZones,...,
            numberOfLayersMax,FlowDirectionModel,numberOfVerticalDeltatBands,DELTAT, numberOfStressParameters, gamRecharge, Transp_sigmaO ,Transp_sigmaU,...,
            K_GFS, bo_tree_from_top ,bu_tree_from_top,bu_crop_from_top,bu_pasture_from_top, aSoil_from_top, InitCondMat, InitCondLF, rainBand, deltaRBand,...,
            timeStepMultiplier,pixelSize,numberOfPixelFiles, outputPixelSequence, horFactor, preferentialFlowFactor, ArithmeticGeometricMeanCutoff,...,
            FluxFactor, HorizontalTransferEquation);
        
        clear record NumPixels NumSoilMaterial numberOfSoils simPeriod numberOfClimateZones numberOfLayersMax
        clear K_GFS  numberOfPixelFiles outputPixelSequence
        
        
    end
    
    toc;
    clear data_CS
    
    
    %%
elseif CS_Del_Type == 2
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    
    FileName = [Output_Path,'data_CS_Landform.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Landform.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    
    % filename = 'root_distribution.xlsx';
    filename = RunInfo.RootDistributionFileParameter;
    rootDist = xlsread([usr_Path, '\Toolbox_Parameter_Files\',filename]);
    
    % Read from parameter folder
    bo_tree_from_top    = rootDist(:,1);       %overstory root distribution (-)
    bu_tree_from_top    = rootDist(:,2);       %understory root distribution (-)
    bu_crop_from_top    = rootDist(:,3);       %understory root distribution (-)
    bu_pasture_from_top = rootDist(:,4);       %understory root distribution (-)
    aSoil_from_top      = rootDist(:,5);       %soil evap distribution (-)
    
    tic;
    for i = 1 :  size(CS_ID,1)
        record = CS_ID(i,:);
        
        PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_CS_', num2str(record(5)), '_Or_', num2str(record(3)), '_Dir_', num2str(record(4)), '_id_', num2str(record(6)),'_PixelFile.txt'];
        %          PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_CS_', num2str(record(6)), '_Or_', num2str(record(4)), '_Dir_', num2str(record(5)), '_id_', num2str(record(7)),'_PixelFile.txt'];
        
        ClimateFileName = strcat(Model_Path, 'ClimateZone', '_Cl_', num2str(record(9)), '.txt') ;
        
        ShpFileName = strcat(Model_Path, 'InputSHPTable_S_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        SoilParName = strcat(Model_Path, 'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        [NumPixels, numberOfSoils, numberOfClimateZones, numberOfPixelFiles, outputPixelSequence, simPeriod, numberOfLayersMax, K_GFS, NumSoilMaterial] = GetOtherParameters( PixelFileName, ClimateFileName, ShpFileName, SoilParName);
        
        clear ClimateFileName PixelFileName ShpFileName SoilParName
        
        %         % filename = 'root_distribution.xlsx';
        %         filename = RunInfo.RootDistributionFileParameter;
        %         rootDist = xlsread([usr_Path, '\Toolbox_Parameter_Files\',filename]);
        %
        %         % Read from parameter folder
        %         bo_tree_from_top    = rootDist(:,1);       %overstory root distribution (-)
        %         bu_tree_from_top    = rootDist(:,2);       %understory root distribution (-)
        %         bu_crop_from_top    = rootDist(:,3);       %understory root distribution (-)
        %         bu_pasture_from_top = rootDist(:,4);       %understory root distribution (-)
        %         aSoil_from_top      = rootDist(:,5);       %soil evap distribution (-)
        
        % Write OtherInputFile
        
        [ OutputFileName ] = WriteOtherInputFile(Model_Path, record, NumPixels,NumSoilMaterial, numberOfSoils,numberOfGFS, numberOfFlagLF,simPeriod,numberOfClimateZones,...,
            numberOfLayersMax,FlowDirectionModel,numberOfVerticalDeltatBands,DELTAT, numberOfStressParameters, gamRecharge, Transp_sigmaO ,Transp_sigmaU,...,
            K_GFS, bo_tree_from_top ,bu_tree_from_top,bu_crop_from_top,bu_pasture_from_top, aSoil_from_top, InitCondMat, InitCondLF, rainBand, deltaRBand,...,
            timeStepMultiplier,pixelSize,numberOfPixelFiles, outputPixelSequence, horFactor, preferentialFlowFactor, ArithmeticGeometricMeanCutoff,...,
            FluxFactor, HorizontalTransferEquation);
        
        clear record NumPixels NumSoilMaterial numberOfSoils simPeriod numberOfClimateZones numberOfLayersMax
        clear K_GFS  numberOfPixelFiles outputPixelSequence
        
    end
    
    toc;
    clear CS_IDm
    
    %%
elseif CS_Del_Type == 3
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');
    
    FileName = [Output_Path,'data_ECS_LB_RB_H_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_LB_RB_H_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    
    %     %This needs to be fixed in step 5???????
    %     ind_zero = find(data(:,12) == 0);
    %     data(ind_zero,:) = NaN;
    %     data(any(isnan(data),2),:)=[];
    %
    %     % Find unique landform subbasin and cross section combination
    %     sub_basin_CS_LF = [data(:,1), data(:,5), data(:,12)];
    %     [uniq_sub_CS idx1 idx2] = unique(sub_basin_CS_LF, 'stable', 'rows');
    %     CS_id = (1: size(uniq_sub_CS,1))';
    %     CS_id = CS_id(idx2);
    %     CS_ID = [CS_id, data];
    %     clear idx1 idx2 CS_id data
    %
    %     % Find the dominent soil properties among landforms
    %     uniq_CS = unique(CS_ID(:,1));
    %     new_data = zeros(numel(uniq_CS), 4);
    %     for j = 1 : numel(uniq_CS)
    %         ind = find(CS_ID(:,1) == uniq_CS(j));
    %         tmp_data =  [CS_ID(ind,1),CS_ID(ind,2),CS_ID(ind,6), CS_ID(ind,17)] ;
    %         new_data(j,:) = mode(tmp_data,1);
    %
    %     end
    %
    %     [uniq_CS i3 j4] = unique([new_data(:,2), new_data(:,3)],'stable', 'rows');
    %     CS_id = (1: size(uniq_CS,1))';
    %     CS_id = CS_id(j4);
    %     CS_ID = [CS_id, new_data];
    %     [uniq_CS2 ia]= unique(CS_ID(:,1));
    %     CS_IDm = CS_ID(ia,:);
    %     clear i3 j4 new_data CS_ID ia
    %
    filename = RunInfo.RootDistributionFileParameter;
    rootDist = xlsread([usr_Path, '\Toolbox_Parameter_Files\',filename]);
    
    % Read from parameter folder
    bo_tree_from_top    = rootDist(:,1);       %overstory root distribution (-)
    bu_tree_from_top    = rootDist(:,2);       %understory root distribution (-)
    bu_crop_from_top    = rootDist(:,3);       %understory root distribution (-)
    bu_pasture_from_top = rootDist(:,4);       %understory root distribution (-)
    aSoil_from_top      = rootDist(:,5);       %soil evap distribution (-)
    tic;
    for i = 1 : size(CS_ID,1)
        
        record = CS_ID(i,:);
        
        PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_CS_', num2str(record(3)), '_Cl_', num2str(record(6)),'_PixelFile.txt'];
        
        ClimateFileName = strcat(Model_Path, 'ClimateZone', '_Cl_', num2str(record(6)), '.txt') ;
        
        ShpFileName = strcat(Model_Path, 'InputSHPTable_S_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        SoilParName = strcat(Model_Path, 'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        [NumPixels, numberOfSoils, numberOfClimateZones, numberOfPixelFiles, outputPixelSequence, simPeriod, numberOfLayersMax, K_GFS, NumSoilMaterial] = GetOtherParameters( PixelFileName, ClimateFileName, ShpFileName, SoilParName);
        
        clear ClimateFileName PixelFileName ShpFileName SoilParName
        
        record1 = [record(1), record(2)];
        % Write OtherInputFile
        [ OutputFileName ] = WriteOtherInputFile(Model_Path, record1, NumPixels,NumSoilMaterial, numberOfSoils,numberOfGFS, numberOfFlagLF,simPeriod,numberOfClimateZones,...,
            numberOfLayersMax,FlowDirectionModel,numberOfVerticalDeltatBands,DELTAT, numberOfStressParameters, gamRecharge, Transp_sigmaO ,Transp_sigmaU,...,
            K_GFS, bo_tree_from_top ,bu_tree_from_top,bu_crop_from_top,bu_pasture_from_top, aSoil_from_top, InitCondMat, InitCondLF, rainBand, deltaRBand,...,
            timeStepMultiplier,pixelSize,numberOfPixelFiles, outputPixelSequence, horFactor, preferentialFlowFactor, ArithmeticGeometricMeanCutoff,...,
            FluxFactor, HorizontalTransferEquation);
        
        clear record NumPixels NumSoilMaterial numberOfSoils simPeriod numberOfClimateZones numberOfLayersMax
        clear K_GFS  numberOfPixelFiles outputPixelSequence
        
        
        
    end
    toc;
    %%
elseif CS_Del_Type == 4
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_Soil_Type_CS\');
    
    FileName = [Output_Path,'data_ECS_SoilType_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_SoilType_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    
    filename = RunInfo.RootDistributionFileParameter;
    rootDist = xlsread([usr_Path, '\Toolbox_Parameter_Files\',filename]);
    
    % Read from parameter folder
    bo_tree_from_top    = rootDist(:,1);       %overstory root distribution (-)
    bu_tree_from_top    = rootDist(:,2);       %understory root distribution (-)
    bu_crop_from_top    = rootDist(:,3);       %understory root distribution (-)
    bu_pasture_from_top = rootDist(:,4);       %understory root distribution (-)
    aSoil_from_top      = rootDist(:,5);       %soil evap distribution (-)
    tic;
    for i = 1 : size(CS_ID,1)
        
        
        record = CS_ID(i,:);
        %sub_bsin                       soil                       climate
        PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_S_', num2str(record(6)), '_Cl_', num2str(record(5)),'_PixelFile.txt'];
        
        ClimateFileName = strcat(Model_Path, 'ClimateZone', '_Cl_', num2str(record(5)), '.txt') ;
        
        ShpFileName = strcat(Model_Path, 'InputSHPTable_S_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        SoilParName = strcat(Model_Path, 'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        
        [NumPixels, numberOfSoils, numberOfClimateZones, numberOfPixelFiles, outputPixelSequence, simPeriod, numberOfLayersMax, K_GFS, NumSoilMaterial] = GetOtherParameters( PixelFileName, ClimateFileName, ShpFileName, SoilParName);
        
        clear ClimateFileName PixelFileName ShpFileName SoilParName
        
        
        % Write OtherInputFile
        [ OutputFileName ] = WriteOtherInputFile(Model_Path, record, NumPixels,NumSoilMaterial, numberOfSoils,numberOfGFS, numberOfFlagLF,simPeriod,numberOfClimateZones,...,
            numberOfLayersMax,FlowDirectionModel,numberOfVerticalDeltatBands,DELTAT, numberOfStressParameters, gamRecharge, Transp_sigmaO ,Transp_sigmaU,...,
            K_GFS, bo_tree_from_top ,bu_tree_from_top,bu_crop_from_top,bu_pasture_from_top, aSoil_from_top, InitCondMat, InitCondLF, rainBand, deltaRBand,...,
            timeStepMultiplier,pixelSize,numberOfPixelFiles, outputPixelSequence, horFactor, preferentialFlowFactor, ArithmeticGeometricMeanCutoff,...,
            FluxFactor, HorizontalTransferEquation);
        
        clear record NumPixels NumSoilMaterial numberOfSoils simPeriod numberOfClimateZones numberOfLayersMax
        clear K_GFS  numberOfPixelFiles outputPixelSequence
        
        
        
    end
    toc;
    %%
end











