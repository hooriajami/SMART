function [ SM_grid_ST_LF] = SM_LF_Soil_ECS_Soil_CS( SubBasinGrid, SoilType1d, LF, CS_ID_LF, SM_LF_avg, start_process, Num_TS )
%% ========================================================================
%%   This Matlab function is part of the post-processing tools of SMART.
%%   This Matlab function distributes landform average soil moisture per soil type per sub-basin per time step for the
%%   ECS soil type simulations.
%%   This option is only available to process output files of ECS Soil type delineation approach.
%%
%%  INPUTS:
%%  1) Sub-basin grid file
%%  2) Number of simulation time steps
%%  3) Simulated soil moisture data
%%  4) Soil type
%%
%%   OUTPUTS:
%%   Three-dimensional array where its third dimension is time.
%%
%%   This function is called by the post-processing scripts:
%%    Step12b_Spatial_Distribution_SM_*_Scale.m
%%    Step13b_Spatial_Distribution_ET_*_Scale
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
%% Landform per soil type per sub-basin
CS_grid_ID_LF = nan(size(SubBasinGrid));
SM_grid_ST_LF = nan(size(SubBasinGrid,1),size(SubBasinGrid,2), Num_TS);
CS_grid_soil = nan(size(SubBasinGrid));
subBasins = reshape(SubBasinGrid,[],1);
uniq_basin = unique(SM_LF_avg(:,2));
step = 1;
for ts = start_process : Num_TS + start_process%ts = 1: Num_TS
    
    temp_LF_SM = zeros(size(SubBasinGrid));
    
    for i = 1 : numel(uniq_basin)
        
        ind_basin = find(subBasins == uniq_basin(i));
        ind_CS = find(CS_ID_LF(:,2) ==  uniq_basin(i));
        record =  CS_ID_LF(ind_CS,:);
        
        soils = SoilType1d(ind_basin);
        uniq_soils1 = unique(record(:,5), 'stable');
        uniq_soils2 = unique(soils, 'stable');
        
        mis_soil = setdiff( uniq_soils2, uniq_soils1);
        intersect_soil = intersect( uniq_soils2, uniq_soils1);
        
        if isempty(mis_soil) == 1
        else
            indf = find (soils == mis_soil);
            soils(indf) =  intersect_soil;
        end
        
        temp = zeros(size(SubBasinGrid));
        temp(ind_basin) = soils;
        
        
        for j = 1 : numel(uniq_soils1 )
            
            ind_soil = find(temp == uniq_soils1(j));
            CS_grid_soil(ind_soil) = uniq_soils1(j);
            
            LF_soil = zeros(size(SubBasinGrid));
            LF_soil(ind_soil) = LF(ind_soil);
            
            uniq_LF = unique(LF_soil);
            uniq_LF_ind = find(uniq_LF ~= 0);
            uniq_LF = uniq_LF(uniq_LF_ind);
            
            record_soil_ind = find(record(:,5)== uniq_soils1(j));
            record_soil = record(record_soil_ind,:);
            
            % if landform is missing in exisiting cross sections
            ind_m = ismember( uniq_LF, record_soil(:,3) );
            mis_LF = find(ind_m == 0);
            
            
            %
            if isempty(mis_LF) == 1
            else
                uniq_LF = unique(record_soil(:,3));
                for b= 1: numel(mis_LF)
                    indf = find (LF_soil == mis_LF(b));
                    LF_soil(indf) =  max(uniq_LF);
                end
            end
            
            
            for k = 1  : numel(uniq_LF)
                
                ind_LF = find(LF_soil ==  uniq_LF(k));
                
                ind_SM =  find(SM_LF_avg(:, 1) == record_soil(k,1) & SM_LF_avg(:,3) ==  uniq_LF(k) );
                CS_grid_ID_LF(ind_LF) = uniq_LF(k);
                
                temp_LF_SM(ind_LF) =  SM_LF_avg(ind_SM, 3+ts);
            end
            
        end
        
    end
    SM_grid_ST_LF(:,:,step) = temp_LF_SM;
    step = step+1;
end

end

