function [ pressureHead ] = CalculatePressure(Qe, Model, alpha, alphaInv, mm, mmInv, nn, nnInv, Qs, Qa, Qm)
%% ========================================================================
%%   This Matlab function calculates pressure for a given specific saturation.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

temp = 0.0; temp1 = 0.0;

switch Model
    
    case 1
        
        %van Genuchten soil hydraulic Model with Mualem's pore distribution
        %Vogel and Cislerova soil hydraulic Model with Mualem's pore distribution
        temp = max(alpha,1.0);
        temp1 = -power(1.0e300,nnInv);
        HMin  = temp1/temp;
        
        temp = -alpha*HMin;
        temp = power(temp,nn);
        temp = 1.0 + temp;
        QeeM = power(temp,-mm);
        
        temp = Qe*(Qs-Qa)/(Qm-Qa);
        temp = max(temp,QeeM);
        Qee  = min(temp,.9999999999999999999);
        
        temp = power(Qee,-mmInv)-1.0;
        temp = power(temp,nnInv);
        temp = -alphaInv*temp;
        pressureHead = max(temp,-1.0e37);
        
        
    case 2
        %Model = 2 Brooks and Corey model
        temp = power(Qe,-nnInv);
        temp = -alphaInv*temp;
        pressureHead = max(temp,-1.0e37);
        
end


end


