clear all; close all; clc;
%% ========================================================================
%%   This scripts delineates first order sub-basins from a DEM and a catchment outlet shapefile using TauDEM commandline exe files.
%%   To use this tool, the TAUDEM tools need to be installed first. 
%%
%%   INPUTS:  (...\SMART\Toolbox_Input\)
%%   1) A DEM File in Tif format.
%%   2) An Outlet shapefile.
%%   3) A flow accumulation threshhold value for delineating streams
%%   4) Number of processors
%%
%%   OUTPUTS:  (...\SMART\Toolbox_Output\)
%%   1)Pit filled DEM         (*fel.tif);
%%   2)D8 flow direction grid (*p.tif);
%%   3)D8 slope grid          (*sd8.tif);
%%   4)D8 contributing area   (*ad8.tif)
%%   5)Stream network using Stream Definition by Threshold (*src.tif);
%%   6)Strahler Stream Order                               (*ord.tif);
%%   7)Delineated First Order Sub-Basins                   (*w.tif);
%%   8)Delineated Stream Network                           (*.net.shp)
%%   9)Dinf Flow Direction Grid                            (*ang.tif);
%%   10)Dinf Slope Grid                                    (*slp.tif);
%%   11)Dinf contributing Area Grid                        (*sca.tif);
%%   12)Dinf Average Distance down Grid                    (*dd.tif);
%%   13)Slope Area Ratio Grid                              (*sar.tif);
%%
%%   OUTPUTS in txt format: (...\Toolbox_Output\)  used in the rest of commands
%%   Elevation.txt        Filled DEM
%%   Sloped8Grid.txt      D8lope grid
%%   SubBasinGrid.txt     First order sub-basins
%%   StrOrdGrid.txt       Stream order grid
%%   DisDownGrid.txt      Distance down grid -default horizontal distance and average without weight
%%   SlpAreaGrid.txt      Slope area grid
%%   StreamGrid.txt       Stream grid
%%   FlowDirBasinGrid.txt Major flow direction in sub-basin
%%   ArcGIS_Header.asc    ASCIIGRID Header file for ArcGIS or QGIS
%%
%%   It calls the following function:
%%   UserRunInfo.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;       
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Input_Path  = strcat(usr_Path, '\Toolbox_Input\');
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

dem  = input('Enter the name of a DEM File (.tif) : ',  's');
if isempty(dem);                              error('Enter the name of a DEM tif file');
elseif exist([Input_Path, dem], 'file') == 0; error('Warning: DEM file does not exist:\n%s', [dem, ' does not exist in ', Input_Path] );    
end;

gage = input('Enter the name of an outlet shapefile (.shp) : ',  's');
if isempty(gage); error('Enter the name of an outlet shapefile');
elseif exist([Input_Path, gage], 'file') == 0; error('Warning: file does not exist:\n%s', [gage,' does not exist in ', Input_Path] );
end;

np   = input('Enter number of processors : ');
if isempty(np);
    error('Enter number of processors');
elseif np == 1
    warningMessage = sprintf(' The delineation takes longer since np == 1');
    uiwait(msgbox(warningMessage));
    np_Path = [];
elseif np > 1
     np_Path1 =  '"C:\Program Files\Microsoft MPI\Bin\';
     np_Path = [np_Path1, '"mpiexec -n', ' ', num2str(np), ' '];
end

threshold   = input('Enter stream delineation threshold : ');
if isempty(threshold);
    error('Enter stream delineation threshold');
end

%%
tic;
[pathstr,name,ext] = fileparts([Input_Path, dem]) ;
a = strread(name, '%s', 'delimiter', '.');
demName = a{1,1};

% 1) Create a hydrologicaly correct DEM by removing pits (Pit Remove);
PitFilCmd = [np_Path , 'PitRemove', ' ', '-z', ' ', [Input_Path, dem], ' ', '-fel', ' ', Output_Path,demName,'fel.tif'];
system(PitFilCmd)

A = double(imread([Output_Path,demName, 'fel.tif']));
figure(1)
imagesc(A);  title('Pit filled DEM')
clear A

% 2) Create a D8 Flow Direction grid;
% fel    carved or pit filled input elevation file
% sd8    D8 slope file (output)
% p      D8 flow direction output file
flowDirCmd = [np_Path, 'D8Flowdir', ' ', '-p',' ', Output_Path,demName,'p.tif',' ', '-sd8',' ', Output_Path,demName,'sd8.tif',' ','-fel',' ', Output_Path,demName,'fel.tif'];
system(flowDirCmd)
A = double(imread([Output_Path,demName, 'p.tif']));
B = double(imread([Output_Path,demName, 'sd8.tif']));

figure(2)
subplot(1,2,1)
imagesc(A); title('Flow Direction Grid')

subplot(1,2,2)
imagesc(B); title('D8 Slope Grid')
clear A B

% 3) Create a D8 Contributing Area grid;
% AreaD8 dem (assume no outlets, no weight grid)
% Specific file and folder names used:
% AreaD8 ?p demp.tif ?ad8 demad8 [?o outletfile.shp] [?wg demwg] [?nc]
% pfile ? input flow directions grids
% ad8file ? output contributing area grids
% wgfile ? input weight grid files
% Outletfile ? input outlets shapefile
D8AreaCmd = [np_Path, 'AreaD8', ' ', '-p',' ', Output_Path,demName,'p.tif',' ', '-ad8',' ', Output_Path,demName,'ad8.tif', ' ', '-o', ' ', Input_Path,gage, ' ', '-nc'];
system(D8AreaCmd)

figure(3)
A = double(imread([Output_Path,demName, 'ad8.tif']));
imagesc(A); title('D8 contributing Area Grid')
clear A

% 4) Create a stream network using Stream Definition by Threshold tool and create a stream network using Stream Definition by
%Threshold tool and implement the Strahler stream ordering system;
StrdefCmd = [np_Path,'Threshold',' ', '-ssa',' ', Output_Path,demName,'ad8.tif',' ','-src',' ',Output_Path,demName,'src.tif',' ','-thresh',' ', num2str(threshold)];
system(StrdefCmd)

figure(4)
D = double(imread([Output_Path,demName, 'src.tif']));
image(D,'CDataMapping','scaled'); title('D8 Stream Network Grid')
caxis([0, 1]);
clear D

% 5) Delineate the sub-basins using the Stream Reach and Watershed tool;
SubWshdCmd = [np_Path, 'Streamnet', ' ', '-fel',' ', Output_Path,demName,'fel.tif',' ', '-p',' ', Output_Path,demName,'p.tif',' ', '-ad8',' ', Output_Path,demName,'ad8.tif',' ', '-src',' ',Output_Path,demName,'src.tif', ' ', '-o', ' ', Input_Path,gage,...
    ' ','-ord',' ', Output_Path,demName,'ord.tif',' ','-tree',' ', Output_Path,demName,'tree.txt',' ', '-coord', ' ', Output_Path,demName,'coord.txt',' ', '-net', ' ', Output_Path,demName,'net.shp',' ', '-w', ' ', Output_Path,demName,'w.tif'];
system(SubWshdCmd)

figure(5)
subplot(1,3,1)
D = double(imread([Output_Path,demName, 'ord.tif']));
image(D,'CDataMapping','scaled'); title('Strahler Stream Order')
clear D

subplot(1,3,2)
D = double(imread([Output_Path,demName, 'w.tif']));
image(D,'CDataMapping','scaled'); title('Delineated First Order Sub-Basins')
caxis([0, max(reshape(D,[],1))]);
clear D

subplot(1,3,3)
mapshow([Output_Path,demName,'net.shp']); title('Delineated Stream Network')
clear D

% 6) Create a D-Infinity flow direction grid;
DinfFlowDirCmd = [np_Path, 'DinfFlowdir', ' ', '-ang',' ', Output_Path,demName,'ang.tif',' ', '-slp',' ', Output_Path,demName,'slp.tif',' ','-fel',' ', Output_Path,demName,'fel.tif'];
system(DinfFlowDirCmd)
A = double(imread([Output_Path,demName, 'ang.tif']));
B = double(imread([Output_Path,demName, 'slp.tif']));

figure(6)
subplot(1,2,1)
imagesc(A); title('Dinf Flow Direction Grid')
subplot(1,2,2)
imagesc(B); title('Dinf Slope Grid')
clear A B

% 7) Compute D-infinity Contributing Area for every grid cell;
DinfAreaCmd = [np_Path, 'AreaDinf', ' ', '-ang',' ', Output_Path,demName,'ang.tif',' ', '-sca',' ', Output_Path,demName,'sca.tif', ' ', '-o', ' ', Input_Path,gage, ' ', '-nc'];
system(DinfAreaCmd)

figure(7)
A = double(imread([Output_Path,demName, 'sca.tif']));
imagesc(A); title('Dinf contributing Area Grid')
clear A

% 8) Compute the distance downslope to a stream using the D-Infinity Distance Down tool;
DistDownCmd = [np_Path, 'DinfDistDown', ' ', '-ang',' ', Output_Path,demName,'ang.tif',' ','-fel',' ', Output_Path,demName,'fel.tif',' ','-src',' ',Output_Path,demName,'src.tif',' ', '-dd', ' ', Output_Path,demName,'dd.tif', ' ','-m', ' ', 'ave h', ' ', '-nc' ];
system(DistDownCmd)

figure(8)
A = double(imread([Output_Path,demName, 'dd.tif']));
imagesc(A); title('Dinf Average Distance down Grid')
caxis([0, max(reshape(A,[],1))]);
clear A

% 9) Calculate slope-area rario MAYBE for HRU delineation is needed
SlpAreaCmd = [np_Path, 'SlopeAreaRatio', ' ', '-slp',' ', Output_Path,demName,'slp.tif',' ','-sca',' ', Output_Path,demName,'sca.tif',' ','-sar',' ',Output_Path,demName,'sar.tif'];
system(SlpAreaCmd)
figure(9)
B = double(imread([Output_Path,demName, 'sar.tif']));
imagesc(B); 
caxis([0, max(reshape(B,[],1))]);title('Slope Area Ratio Grid')
clear B

%% Export files for HRU delineation
D = imread([Output_Path,demName, 'w.tif']);
MaskGrid = single(D);
indNaN = find(MaskGrid < 0);
MaskGrid(indNaN) = NaN;
ind = find(MaskGrid >= 0);
MaskGrid(ind) = 1;

figure(10)
imagesc(MaskGrid)
title('Mask Grid')
clear D

ElevGrid = double(imread([Output_Path,demName, 'fel.tif']));
ElevGrid(indNaN) = NaN;

if exist([Output_Path,'Elevation.txt'], 'file') ; error('Warning:\n%s', ['Elevation.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'Elevation.txt'],ElevGrid,'delimiter','\t'); 
end

SlpGrid = double(imread([Output_Path,demName, 'sd8.tif']));
SlpGrid(indNaN) = NaN;

if exist([Output_Path,'Sloped8Grid.txt'], 'file') ; error('Warning:\n%s', ['Sloped8Grid.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'Sloped8Grid.txt'],SlpGrid,'delimiter','\t');
end


SubWsdGrid = double(imread([Output_Path,demName, 'w.tif']));
SubWsdGrid(indNaN) = NaN;
% imagesc(SubWsdGrid)

if exist([Output_Path,'SubBasinGrid.txt'], 'file') ; error('Warning:\n%s', ['SubBasinGrid.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'SubBasinGrid.txt'],SubWsdGrid,'delimiter','\t');
end

StrOrdGrid = double(imread([Output_Path,demName, 'ord.tif']));
StrOrdGrid(indNaN) = NaN;
% imagesc(StrOrdGrid)

if exist([Output_Path,'StrOrdGrid.txt'], 'file') ; error('Warning:\n%s', ['StrOrdGrid.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'StrOrdGrid.txt'],StrOrdGrid,'delimiter','\t');
end

DisDownGrid = double(imread([Output_Path,demName, 'dd.tif']));
DisDownGrid(indNaN) = NaN;
% imagesc(DisDownGrid)

if exist([Output_Path,'DisDownGrid.txt'], 'file') ; error('Warning:\n%s', ['DisDownGrid.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'DisDownGrid.txt'],DisDownGrid,'delimiter','\t');
end

SlpAreaGrid = double(imread([Output_Path,demName, 'sar.tif']));
SlpAreaGrid(indNaN) = NaN;
% imagesc(SlpAreaGrid)

if exist([Output_Path,'SlpAreaGrid.txt'], 'file') ; error('Warning:\n%s', ['SlpAreaGrid.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'SlpAreaGrid.txt'],SlpAreaGrid,'delimiter','\t');
end

StreamGrid = double(imread([Output_Path,demName, 'src.tif']));
ind = find(StreamGrid < 0);
StreamGrid(ind) = 0;

if exist([Output_Path,'StreamGrid.txt'], 'file')  ; error('Warning:\n%s', ['StreamGrid.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'StreamGrid.txt'],StreamGrid,'delimiter','\t');
end

str     = double(imread([Output_Path,demName, 'src.tif']));
ind = find(str < 0);
str(ind) =0;
% imagesc(str)

flowdir = double(imread([Output_Path,demName, 'p.tif']));
flowdir(ind) =0;
extract_flow = str .* flowdir;
extract_flow(ind) = NaN;

load([Output_Path,'SubBasinGrid.txt'])
basin_id_uniq = unique(SubBasinGrid);
basin_id_uniq(isnan(basin_id_uniq))=[];

FlowDirBasin = zeros(size(SubBasinGrid));

% Assign flowdir code to each sub-basin
for i = 1  : length(basin_id_uniq)
  
    SubBasin_ind         = find(SubBasinGrid == basin_id_uniq(i));  % Select grid cells for every sub-basin
    flow_code = extract_flow(SubBasin_ind); 
    ind = (flow_code ~= 0); 
    code = mode(flow_code(ind));                                    % Select dominant stream direction 
    FlowDirBasin(SubBasin_ind ) = code;                             % Stream direction for every sub-basin
    
    clear SubBasin_ind
end

if exist([Output_Path,'FlowDirBasinGrid.txt'], 'file') ; error('Warning:\n%s', ['FlowDirBasinGrid.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'FlowDirBasinGrid.txt'],FlowDirBasin,'delimiter','\t');
end

% Write ASCIIGRID Header for ArcGIS or QGIS 
[A, ~, bbox] = geotiffread([Input_Path,demName,'.tif']);

% Header for ArcASCII File 
Line1 = ['ncols', ' ', num2str(size(A, 2))];
Line2 = ['nrows', ' ', num2str(size(A, 1))];
Line3 = ['xllcorner',' ', num2str(bbox(1,1))];
Line4 = ['yllcorner',' ', num2str(bbox(1,2))];
Line5 = ['cellsize', ' ', num2str( RunInfo.DEMRes)];
Line6 = ['NODATA_value', ' ','-9999'];
OutputFileName =[Output_Path,'ArcGIS_Header.asc'];

fid = fopen(OutputFileName,'w');
fprintf (fid, '%s\n', Line1);
fprintf (fid, '%s\n', Line2);
fprintf (fid, '%s\n', Line3);
fprintf (fid, '%s\n', Line4);
fprintf (fid, '%s\n', Line5);
fprintf (fid, '%s\n', Line6);
fclose(fid);


toc;
