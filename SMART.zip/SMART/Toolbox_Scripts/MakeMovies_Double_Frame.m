function MakeMovies_Double_Frame(data1, data2, Num_frames,VideoFileName, cMax )
VideoFileName = [VideoFileName, '.avi'];

writerObj = VideoWriter(VideoFileName);
writerObj.FrameRate = 30;

open(writerObj);
x = 500; y=500; width=1000; height=800;
hFig = figure(1);
set(hFig, 'Position', [x y width height]) ;
set(gcf,'PaperPositionMode','auto')

for k=1:Num_frames
    subplot(2,1,1);
    bar(data1, 'b'); hold on;
    ylabel(' Daily Precipitation [mm/day]')
    
    plot(k, data1(k),'r*');
    xlim([1 Num_frames])
    subplot(2,1,2);
    imagescwithnan(  data2(:,:, k), flipud(jet),[1 1 1], true, cMax)
    title(['Daily top soil moisture', ' ', 'Day: ',' ', num2str(k)])
    frame(k) = getframe(hFig);
    %  frame = getframe(hFig);
    writeVideo(writerObj,frame);
end
close(writerObj);

end

