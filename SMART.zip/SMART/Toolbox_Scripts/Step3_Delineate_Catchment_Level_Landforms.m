clear all;clc; close all
%% ========================================================================
%% This script obtains landform delineation thresholds over the whole catchment based on
%% the sloped8 and distance down the stream grid files generated in step 1. One sets of thresholds for the whole catchment will be determined.
%%
%% INPUTS:
%% Sloped8Grid.txt   Reads from (...\SMART\Toolbox_Output\)
%% DisDownGrid.txt   Reads from (...\SMART\Toolbox_Output\)
%% DEM Resolution    Reads from the UserRunInfo.m script
%%
%% OUTPUTS:
%%  landform_thresholds.txt This file has threshold values.
%%  landform.txt            This grid file has four landforms.
%%  landform_gis.asc        This ASCIIGRID file can be imported to ArcGIS or QGIS
%%
%%   It calls the following function:
%%   UserRunInfo.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
tic;
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
addpath([usr_Path, '\Toolbox_Scripts'])
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

demRes = RunInfo.DEMRes;

SlopeFileName    = strcat(Output_Path, 'Sloped8Grid.txt');
DistanceFileName = strcat(Output_Path, 'DisDownGrid.txt');

% Check if slope and distance down stream grid text files are avaliable and
% load them
if exist(SlopeFileName, 'file'); load (SlopeFileName)
else error('Error: file does not exist:\n%s', [SlopeFileName,' does not exist in ', Output_Path] )
end

if exist(DistanceFileName, 'file'); load (DistanceFileName)
else error('Error: file does not exist:\n%s', [DistanceFileName,' does not exist in ', Output_Path] );
end
%% Calculate mean slope and mean distance for each class interval between 0 to max distance in dem resolution interval

% Convert 2D array to a vector
slp     =  reshape(Sloped8Grid, [],1);
dis     =  reshape(DisDownGrid, [],1);
numRows =  size(DisDownGrid,1);
clear Sloped8Grid DisDownGrid

% Remove Nan
nodata_index = find(dis == -3.40280000000000e+38);
dis(nodata_index) = NaN;

data= [dis, slp];
data(any(isnan(data),2),:)=[];

rdist      = round(data(:,1));                     % Round the distance values
data_rdist = [data(:,2),rdist ];                   % organize data to slope, round dist
data_sort  = sortrows(data_rdist,2);               % sort the data_rdist based on the distance

binranges       = (demRes: demRes : max(rdist));
binranges       = [-Inf, binranges, Inf];
[bincounts,ind] = histc(data_sort(:,2),binranges);  %classify the distance to the interval based on DEM resolution

dis_new  = data_sort(:,2);
slp_new  = data_sort(:,1);
meanDis  = zeros(max(ind),1);
meanSlp  = zeros(max(ind),1);

% Get unique distance classes
uniq = unique(ind);

% Calculate mean slope and mean distance in each class interval
for i = 1 : length(uniq)
    tmp = uniq(i);
    index = find(ind == tmp);
    meanDis(i,1) = mean(dis_new(index));
    meanSlp(i,1) = mean(slp_new(index));
    clear tmp
end

% Compute the second deravative of slope versus distance to river to obtain inflection points
x=meanDis;
y=meanSlp;
first_drv = diff(y)./diff(x);
a = diff(x);
sec_drv = diff(first_drv)./ a(2:end);
sec_drv(any(isinf(sec_drv),2),:)=[];

%% Indices where sign change occurs
indices = find([0; diff(sign(sec_drv))]~=0);

figure(1)
plot(x,y, '.-b'); hold on;
plot(x(1), y(1), '*r'); hold on;
plot(x(indices(2)-1), y(indices(2)-1), '*g'); hold on;
plot(x(indices(10)), y(indices(10)), '*k'); hold on;

title('Catchment averaged slope in discrete class intervals from the center of the river')
xlabel('Distance from center of the river (m)')
ylabel ('Average slope')

%% Write landform thresholds
Line1 = [x(1), y(1)];
Line2 = [x(indices(2)-1), y(indices(2)-1)];
Line3 = [x(indices(10)), y(indices(10))];

headerLine1 = ['%distance(m)', ' ' , 'slope'] ;
fid = fopen([Output_Path,'landform_thresholds.txt'],'w');
fprintf (fid, '%s\n', headerLine1);

fprintf(fid, '%4.2f\t%4.2f\n', Line1);
fprintf(fid, '%4.2f\t%4.2f\n', Line2);
fprintf(fid, '%4.2f\t%4.2f\n', Line3);
fclose(fid)

%% Create landform grid based on the theresholds from the distance down the river grid

% Thresholds from slope-distance curve
class=[x(1) ; x(indices(2)-1); x(indices(10))];

lc = nan(size(dis,1),1);
ind1 = find(dis <= class(1));
ind2 = find(class(1) < dis & dis <= class(2));
ind3 = find(class(2) < dis & dis <= class(3));
ind4 = find(dis > class(3));

lc(ind1) = 1;
lc(ind2) = 2;
lc(ind3) = 3;
lc(ind4) = 4;

% Convert the vector back to 2D array
landform = reshape(lc, numRows, []);

figure(2)
imagesc(landform)
title('Catchment delineated landform grid')

if   exist([Output_Path,'landform.txt'], 'file'); error('Warning:\n%s', ['landform.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'landform.txt'],landform,'delimiter','\t');
end

%Write ASCIIGRID for ArcGIS
OutputFileName =[Output_Path,'landform_gis.asc'];
landform(isnan(landform)) = -9999;

if   exist(OutputFileName, 'file') ; error('Warning:\n%s', ['landform_gis.asc already exists in ', Output_Path] );
else WriteASCIIGrid(OutputFileName, Output_Path, landform)
end

toc;