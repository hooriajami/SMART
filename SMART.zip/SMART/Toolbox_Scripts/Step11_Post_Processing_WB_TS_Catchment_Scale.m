clear all; close all; clc
%% ========================================================================
%%   This Matlab script computes Cross section and sub-basin level fluxes depending on the delineation approach for all the sub-basins.
%%
%%   INPUTS:
%%   1) User defines ones of the delineation types and the code reads respective .mat database file from  '...\Toolbox_Output\
%%     1 = DISTRIBUTED Pixel based delineation                    (6a)
%%     2 = DISTRIBUTED LANDFORM based delineation                 (6b)
%%     3 = ECS Left bank/right bank/headwater delineation         (6c)
%%     4 = ECS Soil type delineation                              (6d)
%%   2) Cross section database properties file for each delineation type
%%
%%   OUTPUTS (...\Model_Output\DelType):
%%   Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%   Time scales:    Daily, Monthly, Annual
%%   Spatial scales: Cross section and sub-basin
%%   1) CS_Daily_Type*_catchment.mat               Horizontal Flow; Deep drainage; Overstorey and understorey transpiration; Soil Evaporation
%%   2) Sub_Basin_Daily_Type*_catchment.mat        Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%   3) Sub_Basin_Monthly_Type*_catchment.mat      Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%   4) Sub_Basin_Yearly_Type*_catchment.mat       Horizontal Flow; Deep drainage; Total runoff; Overstorey and understorey transpiration; Soil Evaporation
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%   OutputPixelIndex.m
%%   CrossSectionFlux.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Code_Path = strcat(usr_Path,'\Toolbox_Scripts\U3M_2D\');
Output_Path    = strcat(usr_Path, '\Toolbox_Output\');

CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');


if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
    
else
    error('This delineation does not exist!!!');
end
%%
if CS_Del_Type == 1
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Distributed\');
    
    FileName = [Output_Path,'data_CS_Distributed_Pixel.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Distributed_Pixel.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Cross section unique number
    CS_id = (1:size(data,1))';
    
    % caclulate contributing area for each cross section
    [uniq_sub, idx1, idx2] = unique([data(:,1), data(:,5), data(:,9),data(:,10), data(:,11) ], 'stable', 'rows');
    
    % Equal distribution
    %     area_H = uniq_sub(idx2,3);
    %     count=hist(idx2,unique(idx2));
    %     count=count';
    %     area_L = uniq_sub(:,5)./count;
    %     area_R = uniq_sub(:,4)./count;
    %     area_L1 = area_L(idx2);
    %     area_R1 = area_R(idx2);
    % Equal distribution
    
    % length weighted contributing areas
    sum_CS_Length = accumarray(idx2, data(:,7));
    sum_CS_Length1 = sum_CS_Length(idx2);
    area_H = (data(:,7) ./ sum_CS_Length1) .* data(:,9);
    area_R1 = (data(:,7)./ sum_CS_Length1) .* data(:,10);
    area_L1 = (data(:,7)./ sum_CS_Length1) .* data(:,11);
    
    CS_IDm = [ CS_id, data(:,1), data(:,5), data(:,8), area_H, area_H, area_R1, area_L1];
    
    i1 = find(CS_IDm(:,3) == 0);
    CS_IDm(i1,5) = CS_IDm(i1, 6);
    i2 = find(CS_IDm(:,3) == 1);
    CS_IDm(i2,5) = CS_IDm(i2, 7);
    i3 = find(CS_IDm(:,3) == 2);
    CS_IDm(i3,5) = CS_IDm(i3, 8);
    
    CS_ID = [CS_IDm(:, 1:2), CS_IDm(:,5)];
    
    clear CS_IDm i1 i2 i3 area_R1 area_L1 area_R area_L area_H count   idx1 idx2 CS_id data
    
    [ Output_CS_d, Output_sub_d, Output_sub_m,  Output_sub_y ] = CrossSectionFlux( CS_Del_Type,Model_Out_Path, CS_ID );
    
    save([Model_Out_Path,'CS_Daily_Type1_catchment.mat'], 'Output_CS_d')
    save([Model_Out_Path,'Sub_Basin_Daily_Type1_catchment.mat'], 'Output_sub_d')
    save([Model_Out_Path,'Sub_Basin_Monthly_Type1_catchment.mat'], 'Output_sub_m')
    save([Model_Out_Path,'Sub_Basin_Yearly_Type1_catchment.mat'], 'Output_sub_y')
    
    %%
elseif CS_Del_Type == 2
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Landform\');
    
    FileName = [Output_Path,'data_CS_Landform.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Landform.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, ~ ] = OutputPixelIndex(CS_Del_Type, data);
    
    CS_ID = [CS_ID(:,1:2), CS_ID(:,7)];
    
    [ Output_CS_d, Output_sub_d, Output_sub_m,  Output_sub_y ] = CrossSectionFlux( CS_Del_Type,Model_Out_Path, CS_ID );
    
    save([Model_Out_Path,'CS_Daily_Type2_catchment.mat'], 'Output_CS_d')
    save([Model_Out_Path,'Sub_Basin_Daily_Type2_catchment.mat'], 'Output_sub_d')
    save([Model_Out_Path,'Sub_Basin_Monthly_Type2_catchment.mat'], 'Output_sub_m')
    save([Model_Out_Path,'Sub_Basin_Yearly_Type2_catchment.mat'], 'Output_sub_y')
      
    
    %%
elseif CS_Del_Type == 3
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_LB_RB_H_CS\');
    
    FileName = [Output_Path,'data_ECS_LB_RB_H_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_LB_RB_H_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, ~ ] = OutputPixelIndex(CS_Del_Type, data);
    CS_ID = [CS_ID(:,1:2), CS_ID(:,4)];
    
       
    [ Output_CS_d, Output_sub_d, Output_sub_m,  Output_sub_y ] = CrossSectionFlux( CS_Del_Type,Model_Out_Path, CS_ID );
    
    save([Model_Out_Path,'CS_Daily_Type3_catchment.mat'], 'Output_CS_d')
    save([Model_Out_Path,'Sub_Basin_Daily_Type3_catchment.mat'], 'Output_sub_d')
    save([Model_Out_Path,'Sub_Basin_Monthly_Type3_catchment.mat'], 'Output_sub_m')
    save([Model_Out_Path,'Sub_Basin_Yearly_Type3_catchment.mat'], 'Output_sub_y')
    %%
elseif CS_Del_Type == 4
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_Soil_Type_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_Soil_Type_CS\');
    
    FileName = [Output_Path,'data_ECS_SoilType_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_SoilType_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, ~ ] = OutputPixelIndex(CS_Del_Type, data);
    
    FileName2 = [Output_Path,'ECS_Soil_CS_Area.mat'];
    load(FileName2)
    uniq_sub_basin = unique(CS_ID(:,2));
    for i = 1 : numel(uniq_sub_basin)
        ind = find(CS_ID(:,2) == uniq_sub_basin(i));
        tmp1 = CS_ID(ind,:);
        
        if numel(ind) > 1
            ind2 = find(sub_soil_area(:,1) == uniq_sub_basin(i));
            tmp2 = sub_soil_area(ind2,:);
            [~,ia,ib] = intersect(tmp1(:,6),tmp2(:,2));
            tmp1(ia, 3) = tmp2(ib,3);
            CS_ID(ind,3) =  tmp1(ia, 3);
        end
        
    end
    
    
    [ Output_CS_d, Output_sub_d, Output_sub_m,  Output_sub_y ] = CrossSectionFlux( CS_Del_Type,Model_Out_Path, CS_ID );
    
    save([Model_Out_Path,'CS_Daily_Type4_catchment.mat'], 'Output_CS_d')
    save([Model_Out_Path,'Sub_Basin_Daily_Type4_catchment.mat'], 'Output_sub_d')
    save([Model_Out_Path,'Sub_Basin_Monthly_Type4_catchment.mat'], 'Output_sub_m')
    save([Model_Out_Path,'Sub_Basin_Yearly_Type4_catchment.mat'], 'Output_sub_y')
    %%
end