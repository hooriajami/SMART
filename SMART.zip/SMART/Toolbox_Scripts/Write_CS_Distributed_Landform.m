function Write_CS_Distributed_Landform(data)
%% ========================================================================
%%   This Matlab function writes pixel files for landform based distributed cross section delineation approach.
%%   Cross sectional properties are obtained on a landform basis.
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%
%%   This function is called by:
%%   CS_LF_*.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
%         data_f(k, 1)  = sub_basin_id;
%         data_f(k, 2)  = 2;                                                 % Delineation type = pixel landform
%         data_f(k, 3)  = type_hor;                                           % Stream orientation  horizontal
%         data_f(k, 4)  = 1 ;                                                 % Type 1 Horizontal stream
%         data_f(k, 5)  = CS_Type;
%         data_f(k, 6)  = CS_id;
%         data_f(k, 7)  = numel(ind3);                                       % cross section length in pixel
%         data_f(k, 8)  = areaH+areaL+areaR;
%         data_f(k, 9)  = areaH;
%         data_f(k, 10) = areaR;
%         data_f(k, 11) = areaL;
%         data_f(k, 12) = m_LF;
%         data_f(k, 14) = max_Elv;
%         data_f(k, 15) = mean_slp;
%         data_f(k, 16) = m_climate;
%         data_f(k, 17) = m_LC;
%         data_f(k, 18) = m_soil;
%
%         data_f(k, 26) = mean_soild1;
%         data_f(k, 27) = mean_soild2;
%         data_f(k, 28) = mean_soild3;
%         data_f(k, 29) = mean_soild4;


RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');

demRes = RunInfo.DEMRes ;
LyrTickness = RunInfo.LyrThickness;  %thickness of soil layers [m]
Nodata = -9999;

%Outputfile Header
line1 = 'Seq Elev Landuse Soils Md0   Md1    Md2     Md3   ML1 ML2 ML3 ML4 Salinity1 Salinity2 Salinity3 Salinity4 ClimateZone Recharge/Discharge/Stream D-infinity_angle GFS Neighbours0-7';
line2 = '(long)(M)(T/P/C/O)(int)(M)   (M)    (M)     (M)                    (dS/m)   (dS/m)    (dS/m)     (dS/m)    (A/B/C/D)       (R/D/S)               (degrees)      (int)  (long)';
line3 = '0         1         2         3         4         5         6         7         8         9         10        11        12        13        14        15';
line4 = '0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789';

% var = [(basin_ID), CS_Type,   areaH,     , AreaL,     , areaR,    ,LF,        Soil_ID,    length,                slope,     (Land_ID),  (climate),    Elev,       soil_d1,      soil_d2,    soil_d3,   soil_d4     type_hor  str_direction  CS_id];
var1 = [data(:,1), data(:,5), data(:,9), data(:,11), data(:, 10), data(:,12), data(:, 18), data(:, 7).* demRes, data(:, 15), data(:, 17), data(:, 16), data(:, 14), data(:, 26), data(:, 27), data(:, 28), data(:, 29), data(:,3), data(:,4), data(:,6)];

% Remove records from var based on landform length
Index_keep = find(var1(:,8) >= demRes./2);
var1 = var1(Index_keep,:);

% Add records if landform length is greater than 25 m
Pixel_num = round(var1(:,8) ./ demRes);

% Repeat elements based on Pixel_num
h = [];
h(cumsum(Pixel_num))=1;
var1=var1(cumsum(h)-h+1,:);

uniq_basinID = unique(var1(:,1));

for i = 1: numel(uniq_basinID)
    
    % Select rows for a given basin
    myBasin_Index = find(var1(:,1) == uniq_basinID(i));
    
    
    % Extract data based on basin_ID
    var_basin = var1( myBasin_Index,:);
    
    CS_Type_LF = unique([var_basin(:,2), var_basin(:,19)], 'rows');
    
     for j = 1: size(CS_Type_LF, 1)
        
        ind = find(var_basin(:, 2) ==   CS_Type_LF(j,1) & var_basin(:, 19) ==   CS_Type_LF(j,2));
        
        data1 =  var_basin(ind,:);
        
        %Sort records for a given soil type based on landform (4 is the top landform)
        [d,Index] =  sort(data1, 'descend');
        row_size = size(data1,1);
        
        %Sort the rest based on landform index in number of records greater
        %than 1
        if row_size > 1
            for n = 1 : 19
                data1(:,n) = data1(Index(:,6),n);   %based on landform
                
            end
        end
        
        % Add additional dummy record for discharge cell
        var_basin_soil = [data1; data1(end,:)];
        
        clear d data Index
        
        % Derive input variables from CSV file
        Elev_SoilType = var_basin_soil(:,12);
        Slp_SoilType  = var_basin_soil(:,9);
        Seq = linspace (1, numel(Elev_SoilType),numel(Elev_SoilType));
        Seq = Seq';
        
        % Adjust elevation based on slope of landform
        for x = 2 : numel(Elev_SoilType)
            Elev_SoilType(x) = Elev_SoilType(x-1) - (Slp_SoilType(x-1) .* demRes);
        end
        
        clear  Slp_SoilType
        
        Soil_SoilType1 = var_basin_soil(:,7);
        Soil_SoilType = Soil_SoilType1;
        
        %         k = size(data_f,1) ;
        [uniq_m_soil, ia, ic] = unique(Soil_SoilType1, 'stable');
        for c = 1  : numel(uniq_m_soil);
            %             data_f(k, 21+c) = c;
            Soil_Pixel_ind = find(Soil_SoilType1 == uniq_m_soil(c));
            Soil_SoilType(Soil_Pixel_ind) = c;
            
        end
        
        % Compute Horizon elevation
        Md3 = Elev_SoilType - var_basin_soil(:,13);  %% 7 13 14 15
        Md2 = Md3 - var_basin_soil(:,14);
        Md1 = Md2 - var_basin_soil(:,15);
        Md0 = Md1 - var_basin_soil(:,16);
        
        % Get MLs
        numLyr = [round(var_basin_soil(:,16) ./LyrTickness), round(var_basin_soil(:,15) ./LyrTickness),round(var_basin_soil(:,14) ./LyrTickness),round(var_basin_soil(:,13) ./LyrTickness)];
        cumNumLyr = cumsum(numLyr,2);
        
        Salinity = ones(numel(Seq),4).* 0.3;
        RDS = zeros(numel(Seq),1);     %zero recharge cell, D discharge cell = 1
        RDS(numel(RDS)) = 1;           %One discharge cell
        Dinf =  zeros(numel(Seq),1);
        GFS = 4;
        GFS = repmat(GFS, numel(Seq),1);
        dum = repmat(Nodata, numel(Seq), 3);
        Neighbor1 = [Seq(2:numel(Seq)); Nodata];
        Neighbor2 = [Nodata; Seq(1:(numel(Seq)-1))];
        
        
        % Map back the character field, landuse, climate, Recharge/Discharge
        %cells
        LandIDs = char(numel(Seq), 1);
        index1 = find(var_basin_soil(:,10) == 1);
        LandIDs(index1) = 'T';
        index2 = find(var_basin_soil(:,10) == 2);
        LandIDs(index2) = 'P';
        index3 = find(var_basin_soil(:,10) == 3);
        LandIDs(index3) = 'C';
        
        climateZones = char(numel(Seq), 1);
        index1 = find(var_basin_soil(:,11) == 1 );
        climateZones(index1) = 'A';
        index1 = find(var_basin_soil(:,11) == 2 );
        climateZones(index1) = 'A';
        index1 = find(var_basin_soil(:,11) == 3 );
        climateZones(index1) = 'A';
        index1 = find(var_basin_soil(:,11) == 4 );
        climateZones(index1) = 'A';
        
        RDSs = char(numel(Seq), 1);
        index1 = find(RDS == 1);
        RDSs(index1) = 'D';
        index2 = find(RDS == 0);
        RDSs(index2) = 'R';
        
        
        %         CHANGE TO ACCOMADATE MULTIPLE ZONES PERFILE
        climateName = 1;
        %         soilName = SoilIDu(mySoil_Basin(j));
        %
        OutputFileName = [Model_Path, 'SB_', num2str(uniq_basinID(i)),'_CS_',num2str(unique(var_basin_soil(:,2))),'_Or_', num2str(unique(var_basin_soil(:,17))), '_Dir_', num2str(unique(var_basin_soil(:,18))), '_id_', num2str(unique(var_basin_soil(:,19))), '_PixelFile.txt'];
        fid = fopen(OutputFileName,'w');
        fprintf (fid, '%s\n%s\n%s\n%s\n', line1, line2, line3, line4);
        
        for n = 1 : Seq(end)
            fprintf(fid,'%5d%8.2f%2s%2d%8.2f%8.2f%8.2f%8.2f%4d%4d%4d%4d%8.4f%8.4f%8.4f%8.4f%2s%2s%7.3f%2d%6d%6d%6d%6d%6d%6d%6d%6d\t\n',Seq(n,:), Elev_SoilType(n,:), LandIDs(n,:), Soil_SoilType(n,:), Md0(n,:),Md1(n,:), Md2(n,:),Md3(n,:), cumNumLyr(n,:), Salinity(n,:),climateZones(n,:), RDSs(n,:), Dinf(n,:), GFS(n,:) , dum(n,:), Neighbor1(n,:), dum(n,:), Neighbor2(n,:) );
        end
        fclose(fid) ;
        disp(OutputFileName)
        clear var_basin_soil
    end
end


end
