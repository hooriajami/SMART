function [SM_grid_sub] = SM_Subbasin_Average(CS_Del_Type, SubBasinGrid, SM_LF_avg, start_process, Num_TS)
%% ========================================================================
%%   This Matlab function is part of the post-processing tools of SMART.
%%   This Matlab function computes sub-basin average soil moisture per time step and distributes it to a grid
%%   for every time step defined by the user.
%%   This option is available to process output files of all cross section delineation approaches.
%%
%%   INPUTS:
%%   1) User defines the cross section delineation type 
%%     1 = DISTRIBUTED Pixel File delineation          (6a)
%%     2 = DISTRIBUTED LANDFORM Pixel File delineation (6b)
%%     3 = ECS Left bank/right bank/head water         (6c)
%%     4 = ECS Soil type                               (6d)
%%  2) Sub-basin grid file generated in Step 1
%%  3) Number of simulation time steps (user input)
%%  4) soil moisture .mat file
%%
%%   OUTPUTS:
%%   Three-dimensional array where its third dimension is time. 
%%
%%   This function is called by the post-processing scripts:
%%    Step12b_Spatial_Distribution_SM_*_Scale.m
%%    Step13b_Spatial_Distribution_ET_*_Scale
%%
%%   Copyright 2017 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ======================================================================== 

subBasins = reshape(SubBasinGrid,[],1);
SM_grid_sub = nan(size(SubBasinGrid,1),size(SubBasinGrid,2), Num_TS);

[uniq_basin, ~, idx2] = unique(SM_LF_avg(:,2));
if CS_Del_Type <= 2
    
    count =2;
elseif CS_Del_Type >= 3
    
    count = 3;
end    
k=1;
for i = start_process : start_process+Num_TS - 1 %Month or days 6/8/2017
   
    SM = accumarray(idx2,SM_LF_avg(:,i+count),[],@nanmean);
    temp1 = nan(size(SubBasinGrid));
    
    for j = 1 : numel(uniq_basin) %Num-basins
        ind_basin = find(subBasins  == uniq_basin(j));
        temp1(ind_basin) = SM(j);        
    end
    
    SM_grid_sub(:,:,k) = temp1;
    clear ind_basin SM temp1
    
    k=k+1;
end

clear idx1 idx2
    
   
end

