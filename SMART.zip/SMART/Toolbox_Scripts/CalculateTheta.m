function [ theta ] = CalculateTheta(pressureHead, Model, alpha, alphaInv, Qs, Qa, Qm, Qr, mm, mmInv, nn, nnInv)

%% ========================================================================
%%   This Matlab function calculates theta for a given pressure head.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

% 			double theta;
            temp = 0.0; temp1 = 0.0;
% 			double Qee,Qees;
% 			double HMin,Hs,HH;

switch Model
    
    case 1
        %van Genuchten soil hydraulic Model with Mualem's pore distribution
        %Vogel and Cislerova soil hydraulic Model with Mualem's pore distribution
        temp = max(alpha,1.0);
        temp1 = -power(1.0e300,nnInv);
        HMin = temp1/temp;
        
        HH = max(pressureHead,HMin);
        
        temp = (Qs-Qa)/(Qm-Qa);
        Qees = min(temp,.9999999999999999999);
        
        temp = power(Qees,-mmInv);
        temp = temp - 1.0;
        temp = power(temp,nnInv);
        Hs   = -alphaInv*temp;
        
        if(pressureHead < Hs)
            
            temp = - alpha * HH;
            temp = power(temp,nn);
            temp = 1.0 + temp;
            Qee  = power(temp,-mm);
            
            temp  = Qm - Qa;
            temp  = temp*Qee;
            temp  = temp + Qa;
            theta = max(temp,1.0e-37);
            
        else
            
            theta = Qs;
        end
        
        
        
    case 2
        %  Model = 2 Brooks and Corey model
        Hs = -alphaInv;
        
        if (pressureHead < Hs)
            
            temp = -alpha*pressureHead;
            Qee  = power(temp,-nn);
            
            temp  = Qr + (Qs - Qr)*Qee;
            theta = max(temp,1.0e-37);
            
        else
            
            theta = Qs;
        end
        
        
        
end       
        
        
end

