function [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx )
%% ========================================================================
%%   This MATLAB function removes spurious polygons from the delineated hillslopes.
%%   This function is used in Step2_Delineate_Hillslopes.m script.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
CC2 = bwconncomp(basin_one == 2,n_conn);
count2= cellfun('length',CC2.PixelIdxList);
ic2 = find(count2 ~= 1);
count2 = count2(ic2);

CC1 = bwconncomp(basin_one == 1,n_conn);
count1= cellfun('length',CC1.PixelIdxList);
ic1 = find(count1 ~= 1);
count1 = count1(ic1);

if isempty(idx) == 0
    
    if (isempty(count2) == 0 || isempty(count1) == 0)
        
        if numel(count2) >= 2
            [~,id_count] = min(count2);
            
            id = cell2mat(CC2.PixelIdxList(:,id_count));
            basin_one(id) = 3;
        elseif numel(count1) >=2
            [~,id_count] = min(count1);
            id = cell2mat(CC1.PixelIdxList(:,id_count));
            basin_one(id) = 3;
            
        end
    end
    
elseif isempty(idx) == 1
    if numel(count2) >= 2
        [~,id_count] = min(count2);
        
        
        id = cell2mat(CC2.PixelIdxList(:,id_count));
        basin_one(id) = 1;
    elseif numel(count1) >=2
        [~,id_count] = min(count1);
        
        id = cell2mat(CC1.PixelIdxList(:,id_count));
        basin_one(id) = 2;
    end
end


end

