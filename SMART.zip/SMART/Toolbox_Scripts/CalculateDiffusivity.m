function [ diffusivity ] = CalculateDiffusivity(pressureHead, conductivity, HydCapacity, Model, Qs, Qa, Qm, mm, mmInv, nn, nnInv, alpha, alphaInv, Qk, Ksat, Kk)
%% ========================================================================
%%   This Matlab function calculates diffusivity. 
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

temp = 0.0;
% 			double Qees;
% 			double Hs;
% 			double diffusivity;

switch Model
    
    case 1
        %Vogel and Cislerova soil hydraulic Model with Mualem's pore distribution
        %van Genuchten soil hydraulic Model with Mualem's pore distribution
        
        temp = (Qs-Qa)/(Qm-Qa);
        Qees = min(temp,.999);
        
        temp = power(Qees,-mmInv);
        temp = temp - 1.0;
        temp = power(temp,nnInv);
        Hs   = -alphaInv*temp;
        
        if(pressureHead < Hs)
            
            diffusivity = conductivity/HydCapacity;
            
        else
            
            temp = 1.001*Hs;
            conductivity = CalculateK(temp, Model, alpha, alphaInv, nn, nnInv, mm, mmInv, Qs, Qa, Qm, Qk, Ksat, Kk);
            HydCapacity  = CalculateHydCapacity (temp, Model, alpha , alphaInv, nn, nnInv, mm, mmInv, Qs, Qa, Qm);
            diffusivity  = conductivity/HydCapacity;
        end
        
        
    case 2
        %Model = 2 Brooks and Corey model
        
        Hs = -alphaInv;
        
        if (pressureHead < Hs)
            
            diffusivity = conductivity/HydCapacity;
            
        else
            
            temp = 1.001*Hs;
            conductivity = calculateK(temp);
            HydCapacity  = calculateHydCapacity (temp);
            diffusivity  = conductivity/HydCapacity;
        end
        
        
end
end

