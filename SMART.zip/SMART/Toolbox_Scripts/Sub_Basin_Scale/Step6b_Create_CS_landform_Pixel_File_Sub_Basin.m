clear all; close all; clc
%% ========================================================================
%%   This script delineates and obtains cross section properties from the topographic, soil and land cover variables on a "LANDFORM BASIS".
%%   It also writes U3M-2D Pixel File for every CS and stores cross section properties in a .mat database file.
%%
%%   INPUTS:
%%   1) LandCoverFile        (landcover.tif);
%%   2) ClimateZoneFile      (climatezone.tif)
%%   3) Soil depth top layer (soildepth1.tif);
%%   4) Soil depth layer 2   (soildepth2.tif);
%%   5) Soil depth layer 3   (soildepth3.tif);
%%   6) Soil depth layer 4   (soildepth4.tif);
%%   7)  Landform file        (*.txt);
%%   8)  Soil texture class files  Reads soiltype_usda*.txt files from (...\Toolbox_Output\);
%%   9)  SubBasinGrid.txt          Reads from (...\SMART\Toolbox_Output\)
%%   10) Sloped8Grid.txt           Reads from (...\SMART\Toolbox_Output\)
%%   11) Elevation.txt             Reads from (...\SMART\Toolbox_Output\)
%%   12) FlowDirBasinGrid.txt      Reads from (...\SMART\Toolbox_Output\)
%%   13) Hillslopes_Final.mat      Reads from (...\SMART\Toolbox_Output\)
%%   14) StrOrdGrid.txt            Reads from (...\SMART\Toolbox_Output\)
%%   15) Sub-basin identification number
%%
%%   OUTPUTS:
%%   1) Pixel Files for every cross section in (...\SMART\Model_Input\Pixel_Landform\)
%%   2) data_CS_Landform_Subbasin_*.mat                in (...\SMART\Toolbox_Output\)
%%   3) CS_coordinates_LF_T2_Subbasin_*.txt            in (...\SMART\Toolbox_Output\) has the coordinate index of cross sections.
%%
%%
%%   It calls four other functions:
%%   CS_LF_Vertical_Headwater.m
%%   CS_LF_Vertical_Leftbank_Rightbank.m
%%   CS_LF_Horizontal_Headwater.m
%%   CS_LF_Horizontal_Leftbank_Rightbank.m
%%   CS_LF_Diagonal_NW_Headwater.m
%%   CS_LF_Diagonal_NW_Leftbank_Rightbank.m
%%   CS_LF_Diagonal_NE_Headwater.m
%%   CS_LF_Diagonal_NE_Leftbank_Rightbank
%%   Write_CS_Pixel_based_Landform.m
%%   UserRunInfo.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Output_Path = strcat(usr_Path, '\Toolbox_Output\');
Input_Path  = strcat(usr_Path, '\Toolbox_Input\');

%Later versions should have number of soil types in each ECS.
%% Get the names of landcover, soil type and soil depth layer files from the user
LandCoverFile = input('Enter the name of a landcover file (.tif) : ', 's');
if     isempty(LandCoverFile);                          error('Enter the name of a landcover tif file');
elseif exist([Input_Path, LandCoverFile], 'file') == 0; error('Warning: file does not exist:\n%s', [LandCoverFile, ' does not exist in ', Input_Path]);
else   LandCover = double(imread([Input_Path,LandCoverFile]));
end;

ClimateZoneFile = input('Enter the name of a climate zone file (.tif) : ', 's');
if     isempty(ClimateZoneFile);                          error('Enter the name of a climate zone tif file');
elseif exist([Input_Path, ClimateZoneFile], 'file') == 0; error('Warning: file does not exist:\n%s', [ClimateZoneFile, ' does not exist in ', Input_Path]);
else   ClimateZone = double(imread([Input_Path,ClimateZoneFile]));
end;

SoilType1File = [Output_Path, 'soiltype_usda1.txt'];
if exist(SoilType1File, 'file') == 0;  error('Warning: file does not exist:\n%s', [SoilType1File , ' does not exist in ', Output_Path]);
else   load(SoilType1File); SoilType1 = soiltype_usda1;
end;

SoilType2File = [Output_Path, 'soiltype_usda2.txt'];
if exist(SoilType2File, 'file') == 0;  error('Warning: file does not exist:\n%s', [SoilType2File, ' does not exist in ', Output_Path] );
else   load(SoilType2File); SoilType2 = soiltype_usda2;
end;

SoilType3File = [Output_Path, 'soiltype_usda3.txt'];
if exist(SoilType3File, 'file') == 0;  error('Warning: file does not exist:\n%s', [SoilType3File, ' does not exist in ', Output_Path] );
else   load(SoilType3File); SoilType3 = soiltype_usda3;
end;

SoilType4File = [Output_Path, 'soiltype_usda4.txt'];
if exist(SoilType4File, 'file') == 0;  error('Warning: file does not exist:\n%s', [SoilType4File , ' does not exist in ', Output_Path]);
else   load(SoilType4File); SoilType4 = soiltype_usda4;
end;

SoilLyr1File  = input('Enter the name of the soil depth layer 1  (.tif) : ', 's');
if     isempty(SoilLyr1File );                           error('Enter the name of Soil Layer 1 tif file');
    
elseif exist([Output_Path, SoilLyr1File], 'file') == 0;   error('Warning: file does not exist:\n%s', [SoilLyr1File, ' does not exist in ', Output_Path] );
else   SoilLyr1 = double(imread([Output_Path,SoilLyr1File]));
end;

SoilLyr2File  = input('Enter the name of the soil depth layer 2  (.tif) : ', 's');
if     isempty(SoilLyr2File );                           error('Enter the name of Soil Layer 2 tif file');
    
elseif exist([Output_Path, SoilLyr2File], 'file') == 0;   error('Warning: file does not exist:\n%s', [SoilLyr2File, ' does not exist in ', Output_Path]);
else   SoilLyr2 = double(imread([Output_Path,SoilLyr2File]));
end;

SoilLyr3File  = input('Enter the name of the soil depth layer 3  (.tif) : ', 's');
if     isempty(SoilLyr3File );                           error('Enter the name of Soil Layer 3 tif file');
    
elseif exist([Output_Path, SoilLyr3File], 'file') == 0;   error('Warning: file does not exist:\n%s', [SoilLyr3File, ' does not exist in ', Output_Path]);
else   SoilLyr3 = double(imread([Output_Path,SoilLyr3File]));
end;

SoilLyr4File  = input('Enter the name of the soil depth layer 4  (.tif) : ', 's');
if     isempty(SoilLyr4File );                           error('Enter the name of Soil Layer 4 tif file');
    
elseif exist([Output_Path, SoilLyr4File], 'file') == 0;   error('Warning: file does not exist:\n%s', [SoilLyr4File, ' does not exist in ', Output_Path]);
else   SoilLyr4 = double(imread([Output_Path,SoilLyr4File]));
end;


LandformFileName  = input('Enter the name of a landform file  (.txt) : ', 's');
if     isempty(LandformFileName );                           error('Enter the name of landform file');
    
elseif exist([Output_Path, LandformFileName], 'file') == 0;   error('Warning: file does not exist:\n%s', [LandformFileName, ' does not exist in ', Output_Path]);
else   landform = load([Output_Path, LandformFileName]);
end;

clear LandCoverFile SoilTypeFile SoilLyr1File SoilLyr2File SoilLyr3File SoilLyr4File ClimateZoneFile
%% Read text Files (outputs from TauDEM)
SubBasinFileName  = strcat(Output_Path, 'SubBasinGrid.txt');
SlopeFileName     = strcat(Output_Path, 'Sloped8Grid.txt');
ElevationFileName = strcat(Output_Path, 'Elevation.txt');
FlowDirFileName  = strcat(Output_Path, 'FlowDirBasinGrid.txt');
HillslopeFileName = strcat(Output_Path, 'Hillslopes_Final.mat');
StrOrdFileName    = strcat(Output_Path, '\StrOrdGrid.txt');

% Check if sub-basin, slope, elevation and landform text files are avaliable

if   exist(SubBasinFileName, 'file'); load(SubBasinFileName);
else error('Error: file does not exist:\n%s', [SubBasinFileName, ' does not exist in ', Output_Path]);
end

if   exist(SlopeFileName, 'file'); load(SlopeFileName)
else error('Error: file does not exist:\n%s', [SlopeFileName, ' does not exist in ', Output_Path])
end

if   exist(ElevationFileName, 'file'); load(ElevationFileName)
else error('Error: file does not exist:\n%s', [ElevationFileName, ' does not exist in ', Output_Path])
end

if   exist(FlowDirFileName, 'file'); load(FlowDirFileName)
else error('Error: file does not exist:\n%s', [FlowDirFileName, ' does not exist in ', Output_Path])
end

if   exist(HillslopeFileName, 'file'); load(HillslopeFileName)
else error('Error: Hillslope file does not exist:\n%s', [HillslopeFileName, ' does not exist in ', Output_Path])
end

if exist(StrOrdFileName, 'file'); load (StrOrdFileName)
else error('Error: file does not exist:\n%s', [StrOrdFileName,' does not exist in ', Output_Path]);
end

ind_NaN = find(isnan(landform));
Elevation(ind_NaN)   = NaN;
Sloped8Grid(ind_NaN) = NaN;
SubBasinGrid(ind_NaN)= NaN;

LandCover(ind_NaN)  = NaN;
ClimateZone(ind_NaN)= NaN;
SoilType1(ind_NaN)= NaN;
SoilType2(ind_NaN)= NaN;
SoilType3(ind_NaN)= NaN;
SoilType4(ind_NaN)= NaN;
SoilLyr1(ind_NaN)= NaN;
SoilLyr2(ind_NaN)= NaN;
SoilLyr3(ind_NaN)= NaN;
SoilLyr4(ind_NaN)= NaN;

clear SubBasinFileName SlopeFileName ElevationFileName LandformFileName ind_NaN HillslopeFileName
%% Start Processing
% Convert to 1D array
LandCover1d   = reshape(LandCover, [], 1);
ClimateZone1d = reshape(ClimateZone, [], 1);
SoilType1d    = reshape(SoilType1, [], 1);
SoilType2d    = reshape(SoilType2, [], 1);
SoilType3d    = reshape(SoilType3, [], 1);
SoilType4d    = reshape(SoilType4, [], 1);
SoilLyr1d     = reshape(SoilLyr1, [], 1);
SoilLyr2d     = reshape(SoilLyr2, [], 1);
SoilLyr3d     = reshape(SoilLyr3, [], 1);
SoilLyr4d     = reshape(SoilLyr4, [], 1);

ind = find(LandCover1d == 255);
LandCover1d(ind) = 1;

clear LandCover ClimateZone SoilType1 SoilLyr1 SoilLyr2 SoilLyr3 SoilLyr4 SoilType2 SoilType3 SoilType4

slp       =  reshape(Sloped8Grid, [],1);
Elev      =  reshape(Elevation, [],1);
LF        =  reshape(landform, [],1);
subBasins = reshape(SubBasinGrid, [], 1);
FlowDir   = reshape(FlowDirBasinGrid, [], 1);
Hillslopes = reshape(Hill_Grid, [], 1);
StrOrd    =  reshape(StrOrdGrid,  [],1);
numRows   = size(SubBasinGrid,1);

clear Sloped8Grid Elevation StrOrdGrid

% Find unique sub-basins in the catchment
uniq_basins = unique(subBasins);
uniq_basins(isnan(uniq_basins)) = [];

figure(1)
imagescwithnan(SubBasinGrid, jet, [0 1 1], false, [min(min(SubBasinGrid)) max(max(SubBasinGrid))])
title('Sub-Basin Identification number');

pause

Sub_Basin_ID = input('Select the Sub-basin ID for model simulation :');
if     isempty(Sub_Basin_ID);                           error('Enter the ID of a sub-basin');
end;

index_sub_basin = find(uniq_basins == Sub_Basin_ID);
uniq_basins = uniq_basins(index_sub_basin, :);


% Find flow direction of each sub-basin
FlowDir_Sub = zeros(numel(uniq_basins), 2);

for i = 1 : numel(uniq_basins)
    ind =  find(subBasins == uniq_basins(i));
    FlowDir_Sub(i,1) = uniq_basins(i);
    FlowDir_Sub(i,2) =  max(FlowDir(ind));
    
end

% Find stream order of each sub-basin
StrOrd_Sub = zeros(numel(uniq_basins), 2);

for i = 1 : numel(uniq_basins)
    ind =  find(subBasins == uniq_basins(i));
    StrOrd_Sub(i,1) = uniq_basins(i);
    StrOrd_Sub(i,2) =  max(StrOrd(ind));
    
end
tic;

data =[];
for i = 1 : size(uniq_basins,1)
    
    ind  =   find(subBasins == uniq_basins(i));     % Select a specific sub-basin
    temp =   zeros(size(SubBasinGrid));
    temp(ind) = landform(ind);                      % Find associated landforms for a given sub-basin
    
    Hillslp = Hillslopes(ind);
    
    [r_ex, c_ex]   = find(temp ~= 0);               % Find the extent of the sub-basin
    [r_LF1, c_LF1] = find(temp == 1);               % Find the index of river cells (LF ==1)
    
    sub_info(1,1) = StrOrd_Sub(i,2);
    sub_info(1,2) = FlowDir_Sub(i,2);
    sub_info(1,3)  = numel(find(Hillslp == 3));
    sub_info(1,4)  = numel(find(Hillslp == 1));
    sub_info(1,5)  = numel(find(Hillslp == 2));
    clear Hillslp
    if numel(ind) == 1                            % If there is only one catchment cell ignore
        
        text = ['One cell sub-basin:', ' ', num2str(uniq_basins(i))];
        disp(text)
        data_f=[];
    else
        
        % Use index of river cells to specify orientation of stream
        
        if FlowDir_Sub(i,2) == 3 ||  FlowDir_Sub(i,2) == 7
            
            type_hor = 1;  %vertical river
            [data_f] = CS_LF_Vertical_Headwater(uniq_basins(i), r_LF1, c_LF1, r_ex, type_hor, temp, Elev, LF, slp, LandCover1d, ClimateZone1d, SoilType1d, SoilType2d, SoilType3d, SoilType4d, SoilLyr1d, SoilLyr2d, SoilLyr3d, SoilLyr4d, sub_info);
            
        elseif FlowDir_Sub(i,2) == 1 ||  FlowDir_Sub(i,2) == 5
            type_hor = 0; %horizontal river
            [data_f] = CS_LF_Horizontal_Headwater(uniq_basins(i), r_LF1, c_LF1, c_ex, type_hor, temp, Elev, LF, slp, LandCover1d, ClimateZone1d, SoilType1d, SoilType2d, SoilType3d, SoilType4d, SoilLyr1d, SoilLyr2d, SoilLyr3d, SoilLyr4d, sub_info);
            
        elseif FlowDir_Sub(i,2) == 2 ||  FlowDir_Sub(i,2) == 6
            
            type_hor = 2;
            [data_f] = CS_LF_Diagonal_NE_Headwater(uniq_basins(i), r_LF1, c_LF1, r_ex, c_ex, type_hor, temp, Elev, LF, slp, LandCover1d, ClimateZone1d, SoilType1d, SoilType2d, SoilType3d, SoilType4d, SoilLyr1d, SoilLyr2d, SoilLyr3d, SoilLyr4d, sub_info);
        else
            
            type_hor = 3;
            [data_f] = CS_LF_Diagonal_NW_Headwater(uniq_basins(i), r_LF1, c_LF1, r_ex, c_ex, type_hor, temp, Elev, LF, slp, LandCover1d, ClimateZone1d, SoilType1d, SoilType2d, SoilType3d, SoilType4d, SoilLyr1d, SoilLyr2d, SoilLyr3d, SoilLyr4d, sub_info);
            
        end
        
    end
    
    data=[data; data_f];
    clear data_f temp ind r_LF1 c_LF1 c_ex r_ex
    
end


if exist([Output_Path,'data_CS_Landform_Subbasin_',num2str(uniq_basins),'.mat'], 'file') ;
    disp(['data_CS_Landform.mat already exists in ', Output_Path] );
    choice = questdlg('Do you want to overwrite the database file?', ...
        'Warning File Exists!', ...
        'Yes','No', 'No');
    switch choice
        case 'Yes'
            save([Output_Path,'data_CS_Landform_Subbasin_',num2str(uniq_basins),'.mat'], 'data')
            FileName = [Output_Path,'data_CS_Landform_Subbasin_',num2str(uniq_basins),'.mat'];
            load(FileName)
            Write_CS_Distributed_Landform(data)
            
        case 'No'
            disp('Pixel Files are not updated!')
    end
else
    save([Output_Path,'data_CS_Landform_Subbasin_',num2str(uniq_basins),'.mat'], 'data')
    FileName = [Output_Path,'data_CS_Landform_Subbasin_',num2str(uniq_basins),'.mat'];
    load(FileName)
    Write_CS_Distributed_Landform(data)
end

movefile([Output_Path,'CS_coordinates_LF.txt'],[Output_Path,'CS_coordinates_LF_T2_Subbasin_',num2str(uniq_basins),'.txt'])

toc;