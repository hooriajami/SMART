function RunInfo = UserRunInfo
%% ========================================================================
%%   This Matlab function enables the user to set-up information for the run
%%   and to construct the data structure "RunInfo".
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside 
%%   Version 1.0
%% ========================================================================

%%--(1)-- Set Up Run Information ------------------------------------------
    RunInfo.UserPath                      = 'D:\Codes\Test\Full_SMART1B'; % Enter the Path Name to the SMART toolbox 
    RunInfo.DEMRes                        = 30;             
    RunInfo.TimeStepMultiplier            = 1.3;  
    RunInfo.StartDate                     = '01/01/1985';
    RunInfo.EndDate                       = '31/12/1995'; 
%%--(2)-- Other User-specifiable Information ------------------------------    
    RunInfo.Kpan                          = 1.0;   % Pan coefficent. If PET data is used in climate input file is set to 1. 
    RunInfo.LyrThickness                  = 0.1;   % Thickness of computional layers (defualt is 0.1 m) 
    RunInfo.gamRecharge                   = 0.5;      
    RunInfo.Transp_sigmaO                 = 0.0;      
    RunInfo.Transp_sigmaU                 = 0.0;    
    RunInfo.horFactor                     = 0.5;
    RunInfo.PreferentialFlowFactor        = 0.1;
    RunInfo.ArithmeticGeometricMeanCutoff = 0.1;
    RunInfo.HorizontalTransferEquation    = 2;
        
%%--(3)-- Parameter Files ...\SMART\Toolbox_Parameter_Files-----------    
    RunInfo.SoilTextureFileParameter      = 'Soil_texture_ROSETTA_U3M.xlsx';
    RunInfo.RootDistributionFileParameter = 'root_distribution.xlsx';
        
%%--(4)-- Fixed Parameters Information -------------------------------------   
    RunInfo.numberOfGFS                  = 1;            % Equal to 1 in U3M-2D
    RunInfo.numberOfFlagLF               = 4;            % Lanform flag, dummy here
    RunInfo.FlowDirectionModel           = 1;            % For cross section modeling
    RunInfo.DELTAT                       = 86400;        % Number of seconds in a day for a daily model run
    RunInfo.numberOfStressParameters     = 4;            % Plant water stress parameters % thFC[m] thWT[m] thWP[m] thWC[m]
    RunInfo.InitCondLF                   = ones(4, 1);   % Dummy variable
    RunInfo.numberOfVerticalDeltatBands  = 5;
    RunInfo.FluxFactor                   = 1;            
    
end

