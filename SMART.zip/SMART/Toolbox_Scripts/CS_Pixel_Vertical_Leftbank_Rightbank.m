function [ data_f ] = CS_Pixel_Vertical_Leftbank_Rightbank(sub_basin_id, r_LF1, type_hor, temp, k, Elev, LF, slp, LandCover1d, ClimateZone1d, SoilType1d,SoilType2d, SoilType3d, SoilType4d, SoilLyr1d, SoilLyr2d, SoilLyr3d, SoilLyr4d, data_f, sub_info )
%% ========================================================================
%%   This Matlab function generates right and left banks cross sections for vertical streams.
%%   It works for Two stream dirtections:   1) Type I:  North to South (outlet)
%%                                          2) Type II: South to North (outlet)
%%   It also obtains cross section properties from the topographic and land cover variables on a "PIXEL BASIS".
%%
%%   It calls the following functions:
%%    Write_Distributed_Pixel_File.m
%%    UserRunInfo.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

%% Define the number of cross sections for the right bank
r_LF1s = sort(r_LF1);                                                  % sort the row index for the stream cells


row_cs_index = r_LF1s(2) : 3: r_LF1s(end)-1;                            % Delineate the right and left bank cross sections using the index of first and last row (3) can change!

areaH  = sub_info(1,3);
areaR  = sub_info(1,4);
areaL  = sub_info(1,5);

str_direction= sub_info(1,2);

for j = 1 : numel(row_cs_index)
    
    row  =  row_cs_index(j);
    
    str_row = temp(row,:);                                            % From the landform 2d grid, select all the columns for a particular river row
    ind_river = find(str_row == 1);                                   % Select the stream cell
    
    if numel(ind_river) > 1
        ind_riverR = ind_river(1);
        ind_riverL = ind_river(2);
    else
        ind_riverR = ind_river;
        ind_riverL = ind_river;
    end
    
    % Select right bank cells and adjust the index
    col_indexR = find(str_row(ind_riverR : end) ~= 0)+ ind_riverR - 1;  % Select non-zero cells
    
    % check if  cells are empty
    %  if    numel(length1) ~= 1
    
    CS_Type = 1;                                                        % Right bank cross section code
    
    % Map the cells back to the linear index in the original grid to extract properties
    ind3 = sub2ind(size(temp), repmat(row, numel(col_indexR), 1), col_indexR');
    %     numel(ind3)
    max_Elv     = (Elev(ind3));
    mean_slp    = (slp(ind3));
    m_LF        = (LF(ind3));
    m_LC        = (LandCover1d(ind3));
    m_climate   = mode(ClimateZone1d(ind3));
    m_soil      = (SoilType1d(ind3));
    m_soil2     = mode(SoilType2d(ind3));
    m_soil3     = mode(SoilType3d(ind3));
    m_soil4     = mode(SoilType4d(ind3));
    mean_soild1 = (SoilLyr1d(ind3));
    mean_soild2 = (SoilLyr2d(ind3));
    mean_soild3 = (SoilLyr3d(ind3));
    mean_soild4 = (SoilLyr4d(ind3));
    [row1, col1] = ind2sub(size(temp),ind3);
    length =  RunInfo.DEMRes;
    
    data_f(k, 1) =  sub_basin_id;
    data_f(k, 2) =  1;                                                 % Delineation Type Pixel based == 1
    data_f(k, 3) =  type_hor;                                          % Stream orientation  vertical or horizontal
    data_f(k, 4) =  str_direction ;                                    % Get stream direction from the headwater
    data_f(k, 5) =  CS_Type;                                           % Right bank cross section code = 1
    data_f(k, 6) =  j;      %CS_id;
    data_f(k, 7) =  numel(ind3); %%length 11/6;
    data_f(k, 8) =  areaH+areaL+areaR;                                  %sub_area;  %???
    data_f(k, 9) =  areaH;
    data_f(k, 10) = areaR;
    data_f(k, 11) = areaL;
    data_f(k, 12) = 0;                                                 %landform = 0
    data_f(k, 13) = 0;                                                 %soil_type_landform = 0
    %data_f 14 to 15 is zero
    data_f(k, 16) = m_climate;
    %data_f 17 is zero
    
    uniq_m_soil = unique(m_soil);
    for c = 1  : numel(uniq_m_soil);
        data_f(k, 17+c) = uniq_m_soil(c);
    end
    data_f(k, 30) = row1(1);
    data_f(k, 31) = col1(1);
    
    data_f(k, 36) = m_soil2;
    data_f(k, 37) = m_soil3;
    data_f(k, 38) = m_soil4;
    
    dlmwrite([Output_Path, 'CS_coordinates.txt' ],ind3','precision','%10d','-append', 'delimiter','\t','newline','pc');
    
    var1 = table(repmat(sub_basin_id,numel(col_indexR), 1), m_soil, m_LF, repmat(length,numel(col_indexR), 1), mean_slp, m_LC, repmat(m_climate,numel(col_indexR), 1), max_Elv, mean_soild1, mean_soild2, mean_soild3, mean_soild4, row1, col1);
    
    [data_f ] = Write_CS_Distributed_Pixel(var1, data_f);
    
    k = k+1;
    clear var1
    
    %% Now delineate the Left bank cross section for the selected row
    
    col_indexL = find(str_row(1: ind_riverL) ~= 0);
    
    CS_Type = 2;                                                     % Left bank cross section code
    
    % Map the cells back to the linear index in the original grid to extract properties
    ind3 = sub2ind(size(temp),repmat(row, numel(col_indexL), 1),col_indexL');
    %      numel(ind3)
    max_Elv     = (Elev(ind3));
    mean_slp    = (slp(ind3));
    m_LF        = (LF(ind3));
    m_LC        = (LandCover1d(ind3));
    m_climate   = mode(ClimateZone1d(ind3));
    m_soil      = (SoilType1d(ind3));
    m_soil2     = mode(SoilType2d(ind3));
    m_soil3     = mode(SoilType3d(ind3));
    m_soil4     = mode(SoilType4d(ind3));
    mean_soild1 = (SoilLyr1d(ind3));
    mean_soild2 = (SoilLyr2d(ind3));
    mean_soild3 = (SoilLyr3d(ind3));
    mean_soild4 = (SoilLyr4d(ind3));
    [row1, col1] = ind2sub(size(temp),ind3);
    length =  RunInfo.DEMRes;
    
    data_f(k, 1) =  sub_basin_id;
    data_f(k, 2) =  1;                                                 % Delineation Type Pixel based == 1
    data_f(k, 3) =  type_hor;                                          % Stream orientation  vertical or horizontal
    data_f(k, 4) =  str_direction ;                                    % Get stream direction from the headwater
    data_f(k, 5) =  CS_Type;                                           % Right bank cross section code = 1
    data_f(k, 6) =  j;      %CS_id;
    data_f(k, 7) =  numel(ind3); %%%%length;
    data_f(k, 8) =  areaH+areaL+areaR;  %???
    data_f(k, 9) =  areaH;
    data_f(k, 10) = areaR;
    data_f(k, 11) = areaL;
    data_f(k, 12) = 0;                                                 %landform = 0
    data_f(k, 13) = 0;                                                 %soil_type_landform = 0
    %data_f 14 to 15 is zero
    data_f(k, 16) = m_climate;
    %data_f 17 is zero
    
    uniq_m_soil = unique(m_soil);
    for c = 1  : numel(uniq_m_soil);
        data_f(k, 17+c) = uniq_m_soil(c);
    end
    data_f(k, 30) = row1(1);
    data_f(k, 31) = col1(1);
    
    
    data_f(k, 36) = m_soil2;
    data_f(k, 37) = m_soil3;
    data_f(k, 38) = m_soil4;
    dlmwrite([Output_Path, 'CS_coordinates.txt' ],ind3','precision','%10d','-append', 'delimiter','\t','newline','pc');
    var1 = table(repmat(sub_basin_id, numel(col_indexL),1), m_soil, m_LF, repmat(length,numel(col_indexL), 1), mean_slp, m_LC, repmat(m_climate,numel(col_indexL), 1), max_Elv, mean_soild1, mean_soild2, mean_soild3, mean_soild4, row1, col1);
    [data_f ] = Write_CS_Distributed_Pixel(var1, data_f);
    
    k = k+1;
    clear var1
    
end

end  % End function CS_Pixel_Vertical_Leftbank_rightbank.m


