function [Output_Daily, Output_Monthly, Output_Yearly ] = LF_ET( CS_Del_Type,Model_Out_Path, CS_ID,CS_ID_LF  )
%% ========================================================================
%%   This Matlab function is part of the post processing tools of SMART.
%%   It calculates LF level ET values from U3M-2D output files for type 2, 3 and 4 cross section delineations. 
%%
%%   OUTPUTS:
%%   Daily, monthly and annual level ET for every landform  
%%
%%   It is called by the following post-processing script:
%%    Step13a_Post_Processing_ET_*_Scale.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

RunInfo  = UserRunInfo;
st_date = RunInfo.StartDate;
end_date = RunInfo.EndDate;
Date_Num = (datenum(st_date, 'dd/mm/yyyy'):datenum(end_date, 'dd/mm/yyyy'));
[year, month, day] = datevec(datestr(Date_Num,'dd/mm/yyyy'),'dd/mm/yyyy' );
SimPeriod = size(year,1);

To_mean_LF = zeros(size(CS_ID_LF,1), SimPeriod + 3);
Tu_mean_LF = zeros(size(CS_ID_LF,1), SimPeriod + 3);
Ev_mean_LF = zeros(size(CS_ID_LF,1), SimPeriod + 3);

if CS_Del_Type == 2
    
    step =1;
    for i = 1 :  size(CS_ID, 1)%numel(CS_id)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        
        To_mean = zeros(record(3),  SimPeriod);
        Tu_mean = zeros(record(3),  SimPeriod);
        Ev_mean = zeros(record(3),  SimPeriod);
        
        for j = 1: record(3)   %read all pixels
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            To_mean(j, :) = (Tb.Var6)';
            Tu_mean(j, :) = (Tb.Var7)';
            Ev_mean(j, :) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,4));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,4) + 1;
       
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            To_mean_LF(step,1) = record(1);      %CS_id
            To_mean_LF(step,2) = record(2);      %Subbasin Num
            To_mean_LF(step,3) = LF_Num(k);  %Landform Num
            To_mean_LF(step,4:end) = mean(To_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Tu_mean_LF(step,1) = record(1);      %CS_id
            Tu_mean_LF(step,2) = record(2);      %Subbasin Num
            Tu_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Tu_mean_LF(step,4:end) = mean(Tu_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Ev_mean_LF(step,1) = record(1);      %CS_id
            Ev_mean_LF(step,2) = record(2);      %Subbasin Num
            Ev_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Ev_mean_LF(step,4:end) = mean(Ev_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            
            step = step +1;
        end
        clear  To_mean Tu_mean  Ev_mean
    end
    
    
    To_mean_LF_d  = [To_mean_LF(:, (1:3)), To_mean_LF(:,4).*1000, (diff(To_mean_LF(:, 4:end), [],2).*1000)];
    Tu_mean_LF_d  = [Tu_mean_LF(:, (1:3)), Tu_mean_LF(:,4).*1000, (diff(Tu_mean_LF(:, 4:end), [],2).*1000)];
    Ev_mean_LF_d  = [Ev_mean_LF(:, (1:3)), Ev_mean_LF(:,4).*1000, (diff(Ev_mean_LF(:, 4:end), [],2).*1000)];
    
    Output_Daily = struct('To_mean_LF',To_mean_LF_d, 'Tu_mean_LF', Tu_mean_LF_d, 'Ev_mean_LF', Ev_mean_LF_d);
    
    
elseif CS_Del_Type == 3
    
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        To_mean = zeros(record(3),  SimPeriod);
        Tu_mean = zeros(record(3),  SimPeriod);
        Ev_mean = zeros(record(3),  SimPeriod);
        for j = 1  :   record(3)  %read all pixels
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            To_mean(j, :) = (Tb.Var6)';
            Tu_mean(j, :) = (Tb.Var7)';
            Ev_mean(j, :) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,4));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,4) + 1;
       
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            To_mean_LF(step,1) = record(1);      %CS_id
            To_mean_LF(step,2) = record(2);      %Subbasin Num
            To_mean_LF(step,3) = LF_Num(k);  %Landform Num
            To_mean_LF(step,4:end) = mean(To_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Tu_mean_LF(step,1) = record(1);      %CS_id
            Tu_mean_LF(step,2) = record(2);      %Subbasin Num
            Tu_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Tu_mean_LF(step,4:end) = mean(Tu_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Ev_mean_LF(step,1) = record(1);      %CS_id
            Ev_mean_LF(step,2) = record(2);      %Subbasin Num
            Ev_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Ev_mean_LF(step,4:end) = mean(Ev_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            
            step = step +1;
        end
        clear  To_mean Tu_mean  Ev_mean
    end
    
    To_mean_LF_d  = [To_mean_LF(:, (1:3)), To_mean_LF(:,4).*1000, (diff(To_mean_LF(:, 4:end), [],2).*1000)];
    Tu_mean_LF_d  = [Tu_mean_LF(:, (1:3)), Tu_mean_LF(:,4).*1000, (diff(Tu_mean_LF(:, 4:end), [],2).*1000)];
    Ev_mean_LF_d  = [Ev_mean_LF(:, (1:3)), Ev_mean_LF(:,4).*1000, (diff(Ev_mean_LF(:, 4:end), [],2).*1000)];
    
    Output_Daily = struct('To_mean_LF',To_mean_LF_d, 'Tu_mean_LF', Tu_mean_LF_d, 'Ev_mean_LF', Ev_mean_LF_d);
    
elseif CS_Del_Type == 4
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        
        To_mean = zeros(record(4),  SimPeriod);
        Tu_mean = zeros(record(4),  SimPeriod);
        Ev_mean = zeros(record(4),  SimPeriod);
        
        for j = 1  :   record(4)  %read all pixels
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            To_mean(j, :) = (Tb.Var6)';
            Tu_mean(j, :) = (Tb.Var7)';
            Ev_mean(j, :) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,8));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,8) + 1;
        
        
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        
        for k = 1 : size(LF_start,1)          %get average per landform
            To_mean_LF(step,1) = record(1);      %CS_id
            To_mean_LF(step,2) = record(2);      %Subbasin Num
            To_mean_LF(step,3) = LF_Num(k);  %Landform Num
            To_mean_LF(step,4:end) = mean(To_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Tu_mean_LF(step,1) = record(1);      %CS_id
            Tu_mean_LF(step,2) = record(2);      %Subbasin Num
            Tu_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Tu_mean_LF(step,4:end) = mean(Tu_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Ev_mean_LF(step,1) = record(1);      %CS_id
            Ev_mean_LF(step,2) = record(2);      %Subbasin Num
            Ev_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Ev_mean_LF(step,4:end) = mean(Ev_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            
            step = step +1;
        end
        clear  To_mean Tu_mean  Ev_mean
    end
    
    To_mean_LF_d  = [To_mean_LF(:, (1:3)), To_mean_LF(:,4).*1000, (diff(To_mean_LF(:, 4:end), [],2).*1000)];
    Tu_mean_LF_d  = [Tu_mean_LF(:, (1:3)), Tu_mean_LF(:,4).*1000, (diff(Tu_mean_LF(:, 4:end), [],2).*1000)];
    Ev_mean_LF_d  = [Ev_mean_LF(:, (1:3)), Ev_mean_LF(:,4).*1000, (diff(Ev_mean_LF(:, 4:end), [],2).*1000)];
    
    Output_Daily = struct('To_mean_LF',To_mean_LF_d, 'Tu_mean_LF', Tu_mean_LF_d, 'Ev_mean_LF', Ev_mean_LF_d);
    
elseif CS_Del_Type == 5
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        To_mean = zeros(record(3),  SimPeriod);
        Tu_mean = zeros(record(3),  SimPeriod);
        Ev_mean = zeros(record(3),  SimPeriod);
        for j = 1  :   record(3)  %read all pixels
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            To_mean(j, :) = (Tb.Var6)';
            Tu_mean(j, :) = (Tb.Var7)';
            Ev_mean(j, :) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,4));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,4) + 1;
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
                    
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            To_mean_LF(step,1) = record(1);      %CS_id
            To_mean_LF(step,2) = record(2);      %Subbasin Num
            To_mean_LF(step,3) = LF_Num(k);  %Landform Num
            To_mean_LF(step,4:end) = mean(To_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Tu_mean_LF(step,1) = record(1);      %CS_id
            Tu_mean_LF(step,2) = record(2);      %Subbasin Num
            Tu_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Tu_mean_LF(step,4:end) = mean(Tu_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Ev_mean_LF(step,1) = record(1);      %CS_id
            Ev_mean_LF(step,2) = record(2);      %Subbasin Num
            Ev_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Ev_mean_LF(step,4:end) = mean(Ev_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            
            step = step +1;
                 
        end
        
    end
    
     To_mean_LF_d  = [To_mean_LF(:, (1:3)), To_mean_LF(:,4).*1000, (diff(To_mean_LF(:, 4:end), [],2).*1000)];
    Tu_mean_LF_d  = [Tu_mean_LF(:, (1:3)), Tu_mean_LF(:,4).*1000, (diff(Tu_mean_LF(:, 4:end), [],2).*1000)];
    Ev_mean_LF_d  = [Ev_mean_LF(:, (1:3)), Ev_mean_LF(:,4).*1000, (diff(Ev_mean_LF(:, 4:end), [],2).*1000)];
    
    Output_Daily = struct('To_mean_LF',To_mean_LF_d, 'Tu_mean_LF', Tu_mean_LF_d, 'Ev_mean_LF', Ev_mean_LF_d);
elseif CS_Del_Type == 6
    
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        
        To_mean = zeros(record(4),  SimPeriod);
        Tu_mean = zeros(record(4),  SimPeriod);
        Ev_mean = zeros(record(4),  SimPeriod);
        
        for j = 1  :   record(4)  %read all pixels
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            To_mean(j, :) = (Tb.Var6)';
            Tu_mean(j, :) = (Tb.Var7)';
            Ev_mean(j, :) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,8));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,8) + 1;
              
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        for k = 1 : size(LF_start,1)          %get average per landform
            To_mean_LF(step,1) = record(1);      %CS_id
            To_mean_LF(step,2) = record(2);      %Subbasin Num
            To_mean_LF(step,3) = LF_Num(k);  %Landform Num
            To_mean_LF(step,4:end) = mean(To_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Tu_mean_LF(step,1) = record(1);      %CS_id
            Tu_mean_LF(step,2) = record(2);      %Subbasin Num
            Tu_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Tu_mean_LF(step,4:end) = mean(Tu_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            Ev_mean_LF(step,1) = record(1);      %CS_id
            Ev_mean_LF(step,2) = record(2);      %Subbasin Num
            Ev_mean_LF(step,3) = LF_Num(k);  %Landform Num
            Ev_mean_LF(step,4:end) = mean(Ev_mean(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            
            step = step +1;
        end
        clear  To_mean Tu_mean  Ev_mean
    end
    
    To_mean_LF_d  = [To_mean_LF(:, (1:3)), To_mean_LF(:,4).*1000, (diff(To_mean_LF(:, 4:end), [],2).*1000)];
    Tu_mean_LF_d  = [Tu_mean_LF(:, (1:3)), Tu_mean_LF(:,4).*1000, (diff(Tu_mean_LF(:, 4:end), [],2).*1000)];
    Ev_mean_LF_d  = [Ev_mean_LF(:, (1:3)), Ev_mean_LF(:,4).*1000, (diff(Ev_mean_LF(:, 4:end), [],2).*1000)];
    
    Output_Daily = struct('To_mean_LF',To_mean_LF_d, 'Tu_mean_LF', Tu_mean_LF_d, 'Ev_mean_LF', Ev_mean_LF_d);
end

%% Monthly and Annual
tic
day_d = ones(size(day,1),1);
date_num_ind = datenum(year, month, day_d);
[~, ~, idx2] = unique(date_num_ind);

To_mean_LFa     =  To_mean_LF_d(:, 4:end)';
Tu_mean_LFa     =  Tu_mean_LF_d(:, 4:end)';
Ev_mean_LFa     =  Ev_mean_LF_d(:, 4:end)';


% Save Monthly

Num_years = unique(year);
To_LF_m  = zeros(numel(Num_years).*12,size(To_mean_LFa, 2));
Tu_LF_m  = zeros(numel(Num_years).*12,size(To_mean_LFa, 2));
Ev_LF_m  = zeros(numel(Num_years).*12,size(Ev_mean_LFa, 2));

for i = 1 : size(To_mean_LFa,2);
    
    To_LF_m(:,i)   = accumarray(idx2, To_mean_LFa(:,i),[],@sum);
    Tu_LF_m(:,i)   = accumarray(idx2, Tu_mean_LFa(:,i),[],@sum);
    Ev_LF_m(:,i)   = accumarray(idx2, Ev_mean_LFa(:,i),[],@sum);
    
end

To_LF_Month = [To_mean_LF_d(:, (1:3)),To_LF_m']; clear To_LF_m
Tu_LF_Month = [Tu_mean_LF_d(:, (1:3)),Tu_LF_m'];clear Tu_LF_m
Ev_LF_Month = [Ev_mean_LF_d(:, (1:3)),Ev_LF_m'];clear Ev_LF_m

Output_Monthly = struct('To_LF_Month',To_LF_Month, 'Tu_LF_Month',Tu_LF_Month,'Ev_LF_Month',  Ev_LF_Month);

% Save Annual
date_num_ind2 = datenum(year, ones(size(day,1),1), day_d);
[~, ~, idx_yr] = unique(date_num_ind2);

Num_years = unique(year);
To_LF_y      = zeros(numel(Num_years),size(To_mean_LFa,2));
Tu_LF_y      = zeros(numel(Num_years),size(To_mean_LFa,2));
Ev_LF_y      = zeros(numel(Num_years),size(To_mean_LFa,2));

for i = 1 : size(To_mean_LFa,2);
    
    To_LF_y(:,i)    = accumarray(idx_yr,To_mean_LFa(:,i),[],@sum);
    Tu_LF_y(:,i)    = accumarray(idx_yr,Tu_mean_LFa(:,i),[],@sum);
    Ev_LF_y(:,i)    = accumarray(idx_yr,Ev_mean_LFa(:,i),[],@sum);
end

To_LF_Year = [To_mean_LF_d(:, (1:3)),To_LF_y']; clear To_LF_y;
Tu_LF_Year = [Tu_mean_LF_d(:, (1:3)),Tu_LF_y']; clear Tu_LF_y;
Ev_LF_Year = [Ev_mean_LF_d(:, (1:3)),Ev_LF_y']; clear Ev_LF_y;

Output_Yearly = struct('To_LF_Year',To_LF_Year,'Tu_LF_Year',Tu_LF_Year, 'Ev_LF_Year', Ev_LF_Year);


end









