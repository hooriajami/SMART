function [ OutputFileName ] = WriteOtherInputFile(Model_Path, record, NumPixels,NumSoilMaterial, numberOfSoils,numberOfGFS, numberOfFlagLF,simPeriod,numberOfClimateZones,...,
    numberOfLayersMax,FlowDirectionModel,numberOfVerticalDeltatBands,DELTAT, numberOfStressParameters, gamRecharge, Transp_sigmaO ,Transp_sigmaU,...,
    K_GFS, bo_tree_from_top ,bu_tree_from_top,bu_crop_from_top,bu_pasture_from_top, aSoil_from_top, InitCondMat, InitCondLF, rainBand, deltatBand,...,
    timeStepMultiplier,pixelSize,numberOfPixelFiles, outputPixelSequence, horFactor, preferentialFlowFactor, ArithmeticGeometricMeanCutoff,...,
    FluxFactor, HorizontalTransferEquation)

%% ========================================================================
%%   This Matlab function writes the U3M-2D OtherInput Parameter file for every cross section.
%%    
%%   This function is called by:
%%   Step9-Write_OtherInputFile_.m 
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

% Line1 = 'read numberOfPixels (-)';
% Line3 = 'read number of soil materials M (-)';
% Line5 = 'read numberOfSoils (-)';
% Line7 = 'read numberOfGFS (-)';
% Line9 = 'read numberOfFlagLF (-)';
% Line11 = 'read numberOfDays or total simulation period (days)';
% Line13 = 'read numberOfClimateZones (-)';
% Line15 = 'read numberOfLayersMax or number of overstory root distribution values (-)';
% Line17 = 'read FlowDirectionModel (0 for D8 and 1 for Tarboton) (-)';
% Line19 = 'read numberOfVerticalDeltatBands (vertical water balance time step bands) (-)';
% Line21 = 'read DELTAT (horizontal re-distribution time step) (s)';
% Line23 = 'read numberOfStressParameters';
% Line25 = 'read gamRecharge';
% Line27 = 'read Transp_sigmaO';
% Line29 = 'read Transp_sigmaU';
% Line31 = 'read K_GFS[] aray (one value per line; total K_GFS[] values must equal numberOfGFS) (m.s-1) assumed 50 cm/day for testing';
% Line33 = 'read bo_tree_from_top[] array (one value per line; total bo[] values must equal numberOfboValues)';
% Line35 =  'read bu_tree_from_top[] array (one value per line; total bu[] values must equal numberOfbuValues)';
% Line37 =  'read bu_crop_from_top[] array (one value per line; total bu[] values must equal numberOfbuValues)';
% read bu_pasture_from_top[] array (one value per line; total bu[] values must equal numberOfbuValues)
% Line38 =  'read aSoil_from_top[] array (one value per line; total aSoil[] values must equal numberOfaSoilValues)';
% Line39 =  'read InitCondMat[](one value per line; total InitCondMat[] values must equal number Of Soil Materials M)';
% Line41 =  'read InitCondLF[](one value per line; total InitCondLF[] values must equal numberOfFlagLF)';
% Line43 = 'read rainBand [](one value per line; total rainBand[] values must equal numberOfVerticalDeltatBands)';
% Line45 = 'read deltatBand [](one value per line; total deltatBand[] values must equal numberOfVerticalDeltatBands)';
% Line47 = 'read timeStepMultiplier (multiplier for increasing the time step)';
% Line49 = 'read pixelSize (m)';
% Line51 = 'read numberOfPixelFiles (number of pixels for which daily output files are required)';
% Line53 = 'read outputPixelSequence (pixel sequence number for which daily output is required)';
% Line55 = 'read horFactor (range 0.5-1); 1: fast hor flow, 0.5: slow hor flow';
% Line57 = 'read preferentialFlowFactor (range 0-1); 1: all hor flow as prerential, 0: all hor flow as matrix flow';
% Line59 = 'read ArithmeticGeometricMeanCutoff (set >= 1 for this parameter to be ineffective)';
% Line61 = 'read FluxFactor (set = 1 for this parameter to be ineffective)';
% Line63 = 'read HorizontalTransferEquation (set = 1 for unsaturated Darcys law; set = 2 for saturated Darcy law)';

OutputFileName = strcat(Model_Path,'InputOtherData_S_', num2str(record(1)),'_SB_',num2str(record(2)), '.txt');
fid = fopen(OutputFileName,'w');
fprintf (fid, '%s\n', 'read numberOfPixels (-)');
fprintf (fid, '%10d\n', NumPixels);
fprintf (fid, '%s\n', 'read number of soil materials M (-)');
fprintf (fid, '%10d\n', NumSoilMaterial);
fprintf (fid, '%s\n', 'read numberOfSoils (-)');
fprintf (fid, '%10d\n', numberOfSoils);
fprintf (fid, '%s\n', 'read numberOfGFS (-)');
fprintf (fid, '%10d\n', numberOfGFS);
fprintf (fid, '%s\n', 'read numberOfFlagLF (-)');
fprintf (fid, '%10d\n', numberOfFlagLF);
fprintf (fid, '%s\n', 'read numberOfDays or total simulation period (days)');
fprintf (fid, '%10d\n', simPeriod);
fprintf (fid, '%s\n', 'read numberOfClimateZones (-)');
fprintf (fid, '%10d\n', numberOfClimateZones);
fprintf (fid, '%s\n', 'read numberOfLayersMax or number of overstory root distribution values (-)');
fprintf (fid, '%10d\n', numberOfLayersMax);
fprintf (fid, '%s\n', 'read FlowDirectionModel (0 for D8 and 1 for Tarboton) (-)');
fprintf (fid, '%10d\n',FlowDirectionModel);
fprintf (fid, '%s\n', 'read numberOfVerticalDeltatBands (vertical water balance time step bands) (-)');
fprintf (fid, '%10d\n',numberOfVerticalDeltatBands);
fprintf (fid, '%s\n', 'read DELTAT (horizontal re-distribution time step) (s)');
fprintf (fid, '%10d\n',DELTAT);
fprintf (fid, '%s\n', 'read numberOfStressParameters');
fprintf (fid, '%10d\n',numberOfStressParameters);
fprintf (fid, '%s\n', 'read gamRecharge');
fprintf (fid, '%10.1f\n',gamRecharge);  %9.1
fprintf (fid, '%s\n', 'read Transp_sigmaO');
fprintf (fid, '%10.1f\n',Transp_sigmaO); %9.1
fprintf (fid, '%s\n', 'read Transp_sigmaU');
fprintf (fid, '%10.1f\n',Transp_sigmaU); %9.1
fprintf (fid, '%s\n', 'read K_GFS[] aray (one value per line; total K_GFS[] values must equal numberOfGFS) (m.s-1) assumed 50 cm/day for testing');
fprintf (fid, '%10.4e\n',K_GFS);   %10.6
fprintf (fid, '%s\n', 'read bo_tree_from_top[] array (one value per line; total bo[] values must equal numberOfboValues)');
fprintf (fid, '%10.1f\n',bo_tree_from_top); %9.1


fprintf (fid, '%s\n', 'read bu_tree_from_top[] array (one value per line; total bu[] values must equal numberOfbuValues)');
fprintf (fid, '%10.1f\n',bu_tree_from_top); %9.1


fprintf (fid, '%s\n', 'read bu_crop_from_top[] array (one value per line; total bu[] values must equal numberOfbuValues)');
fprintf (fid, '%10.1f\n',bu_crop_from_top);


fprintf (fid, '%s\n', 'read bu_pasture_from_top[] array (one value per line; total bu[] values must equal numberOfbuValues)');
fprintf (fid, '%10.1f\n',bu_pasture_from_top);

fprintf (fid, '%s\n', 'read aSoil_from_top[] array (one value per line; total aSoil[] values must equal numberOfaSoilValues)');
fprintf (fid, '%10.1f\n',aSoil_from_top);

fprintf (fid, '%s\n', 'read InitCondMat[](one value per line; total InitCondMat[] values must equal number Of Soil Materials M)');
fprintf (fid, '%10.4f\n',InitCondMat);

fprintf (fid, '%s\n', 'read InitCondLF[](one value per line; total InitCondLF[] values must equal numberOfFlagLF)');
fprintf (fid, '%10.4f\n',InitCondLF);

fprintf (fid, '%s\n', 'read rainBand [](one value per line; total rainBand[] values must equal numberOfVerticalDeltatBands)');
fprintf (fid, '%10d\n',rainBand);

fprintf (fid, '%s\n', 'read deltatBand [](one value per line; total deltatBand[] values must equal numberOfVerticalDeltatBands)');
fprintf (fid, '%10d\n',deltatBand);

fprintf (fid, '%s\n', 'read timeStepMultiplier (multiplier for increasing the time step)');
fprintf (fid, '%10.1f\n', timeStepMultiplier); %9.1
fprintf (fid, '%s\n', 'read pixelSize (m)');
fprintf (fid, '%10d\n', pixelSize);
fprintf (fid, '%s\n', 'read numberOfPixelFiles (number of pixels for which daily output files are required)');
fprintf (fid, '%10d\n', numberOfPixelFiles);
fprintf (fid, '%s\n', 'read outputPixelSequence (pixel sequence number for which daily output is required)');
fprintf (fid, '%10d\n',outputPixelSequence);


fprintf (fid, '%s\n', 'read horFactor (range 0.5-1); 1: fast hor flow, 0.5: slow hor flow');
fprintf (fid, '%10.1f\n', horFactor); %9.1
fprintf (fid, '%s\n', 'read preferentialFlowFactor (range 0-1); 1: all hor flow as prerential, 0: all hor flow as matrix flow');
fprintf (fid, '%10.1f\n',preferentialFlowFactor);
fprintf (fid, '%s\n',  'read ArithmeticGeometricMeanCutoff (set >= 1 for this parameter to be ineffective)');
fprintf (fid, '%10.1f\n', ArithmeticGeometricMeanCutoff);
fprintf (fid, '%s\n', 'read FluxFactor (set = 1 for this parameter to be ineffective)');
fprintf (fid, '%10d\n',FluxFactor);
fprintf (fid, '%s\n','read HorizontalTransferEquation (set = 1 for unsaturated Darcys law; set = 2 for saturated Darcy law)');
fprintf (fid, '%10d\n',HorizontalTransferEquation);

fclose(fid) ;

end

