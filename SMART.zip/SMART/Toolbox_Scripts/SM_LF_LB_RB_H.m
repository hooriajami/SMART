function [ SM_grid_ST_LF ] = SM_LF_LB_RB_H( SubBasinGrid, Hillslopes, LF, CS_ID_LF, SM_LF_avg,start_process, Num_TS )
%% ========================================================================
%%   This Matlab function is part of the post-processing tools of SMART.
%%   This Matlab function distributes landform level soil moisture for left bank/right bank and headwater hillslopes per hillslope per time step.
%%   This option is only available to process output files of three ECSs delineation approach.
%%
%%   INPUTS:
%%  1) Sub-basin grid file
%%  2) Number of simulation time steps
%%  3) Simulated soil moisture data
%%  4) Hillslope
%%  5) Landform
%%
%%   OUTPUTS:
%%   Three-dimensional array where its third dimension is time.
%%
%%   This function is called by the post-processing scripts:
%%    Step12b_Spatial_Distribution_SM_*_Scale.m
%%    Step13b_Spatial_Distribution_ET_*_Scale
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

CS_grid_ID_LF = nan(size(SubBasinGrid));
SM_grid_ST_LF = nan(size(SubBasinGrid,1),size(SubBasinGrid,2), Num_TS);

subBasins = reshape(SubBasinGrid,[],1);
uniq_basin = unique(SM_LF_avg(:,2));
step=1;
for ts = start_process : Num_TS + start_process;%ts = 1: Num_TS
    
    temp_LF_SM = zeros(size(SubBasinGrid));
    for i = 1 : numel(uniq_basin)
        
        ind_basin = find(subBasins == uniq_basin(i));
        ind_CS = find(CS_ID_LF(:,2) ==  uniq_basin(i));
        record =  CS_ID_LF(ind_CS,:);
        
        uniq_CS = unique(record(:,3));
        temp = nan(size(SubBasinGrid));
        temp(ind_basin) = Hillslopes(ind_basin);
        
        ind_z = find(uniq_CS == 0);
        uniq_CS2 =uniq_CS;
        uniq_CS2(ind_z) = 3;
        
        for j = 1 : numel(uniq_CS2 )
            
            ind_hill = find(temp == uniq_CS2(j));
            %             CS_grid_soil(ind_soil) = uniq_soils(j);
            
            LF_hill = zeros(size(SubBasinGrid));
            LF_hill(ind_hill) = LF(ind_hill);
            
            uniq_LF = unique(LF_hill);
            uniq_LF_ind = find(uniq_LF ~= 0);
            uniq_LF = uniq_LF(uniq_LF_ind);
            
            record_CS_ind = find(record(:,3)== uniq_CS(j));
            record_CS = record(record_CS_ind,:);
            
            % if landform is missing in exisiting cross sections
            ind_m = ismember( uniq_LF, record_CS(:,4) );
            mis_LF = find(ind_m == 0);
            
            
            
            if isempty(mis_LF) == 1
            else
                 uniq_LF = unique(record_CS(:,4));                   
                for b= 1: numel(mis_LF)                       
                  indf = find (LF_hill == mis_LF(b));
                  LF_hill(indf) =  max(uniq_LF);                                                  
                end                   
            end
            
           
            
            
                     
            for k = 1  : numel(uniq_LF)
                
                ind_LF = find(LF_hill ==  uniq_LF(k));
                
                ind_SM =  find(SM_LF_avg(:, 1) == record_CS(k,1) & SM_LF_avg(:,3) ==  uniq_LF(k) );
                if isempty(ind_SM) == 1
                    pause
                end
                
                CS_grid_ID_LF(ind_LF) = uniq_LF(k);
                
                temp_LF_SM(ind_LF) =  SM_LF_avg(ind_SM, 3+ts);
                %               imagesc(temp_LF_SM)
            end %LF
            
        end %hillslope
        
        
    end  % basin
    SM_grid_ST_LF(:,:,step) = temp_LF_SM;
    step=step+1;
    %      clear temp_LF_SM
end  % time step


end

