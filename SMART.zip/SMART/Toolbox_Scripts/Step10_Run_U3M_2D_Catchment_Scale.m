clear all; close all; clc
%% ========================================================================
%%   This Matlab script runs U3M-2D for the whole catchment (all sub-basins).
%%
%%   INPUTS:
%%   1) User defines ones of the delineation types and the code reads respective .mat file from  '...\Toolbox_Output\
%%     1 = DISTRIBUTED Pixel based delineation                    (6a)
%%     2 = DISTRIBUTED LANDFORM based delineation                 (6b)
%%     3 = ECS Left bank/right bank/headwater delineation         (6c)
%%     4 = ECS Soil type delineation                              (6d)
%%  2) SubBasinGrid.txt       Reads from (...\SMART\Toolbox_Output\)
%%  3) Enter number of processors to run U3M-2D across multiple processors
%%
%%   OUTPUTS:
%%   For every cross section a folder is generated in (...\SMART\Model_Output\DEL TYPE)
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%   OutputPixelIndex.m
%%   U3M-2D.exe
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
addpath(genpath(usr_Path))

Code_Path = strcat(usr_Path,'\Toolbox_Scripts\U3M_2D\');
Output_Path    = strcat(usr_Path, '\Toolbox_Output\');

CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');

if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
else
    error('This delineation does not exist!!!');
end

np   = input('Enter number of processors : ');
if isempty(np);
    error('Enter number of processors');
end

%%
if CS_Del_Type == 1
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Distributed\');
    
    FileName = [Output_Path,'data_CS_Distributed_Pixel.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Distributed_Pixel.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Cross section unique number
    CS_id = (1:size(data,1))';
    CS_ID = [CS_id, data(:, 1:17)];
    clear data CS_id
    
    tic;
    parpool('local',np)
    parfor i = 1 :  size(CS_ID,1)
        
        record = CS_ID(i,:);
        
        NewFolder = strcat('CS_', num2str(record(1)),'_SB_', num2str(record(2)));
        mkdir(Model_Out_Path , NewFolder)
        
        PixelFileName   = [Model_Path,'SB_', num2str(record(2)),'_CS_', num2str(record(6)), '_Or_', num2str(record(4)), '_Dir_', num2str(record(5)), '_id_', num2str(record(7)),'_PixelFile.txt'];
        ClimateFileName = strcat(Model_Path,'ClimateZone','_Cl_', num2str(record(17)), '.txt') ;
        ShpFileName     = strcat(Model_Path,'InputSHPTable_S_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        SoilParName     = strcat(Model_Path,'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        InputOtherName  = strcat(Model_Path,'InputOtherData_S_', num2str(record(1)),'_SB_',num2str(record(2)), '.txt');
        
        
        copyfile(PixelFileName,[Model_Out_Path, NewFolder,'\PixelFile.txt'])
        copyfile(ClimateFileName,[Model_Out_Path, NewFolder,'\ClimateZone.txt']);
        copyfile(ShpFileName,[Model_Out_Path, NewFolder,'\InputSHPTable.txt']);
        copyfile(SoilParName,[Model_Out_Path, NewFolder,'\InputSoilPar.txt']);
        copyfile(InputOtherName,[Model_Out_Path,NewFolder,'\InputOtherData.txt']);
        
        
        copyfile([Code_Path,'U3M_2D_code.exe'], [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'])
        cd ([Model_Out_Path, NewFolder])
        Run_U3M = [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'];
        
        system(Run_U3M)
        
        
    end
    
    delete(gcp('nocreate'))
    
    toc;
    
    
    clear CS_ID
    
    
    %%
elseif CS_Del_Type == 2
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Landform\');
    
    FileName = [Output_Path,'data_CS_Landform.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Landform.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, ~ ] = OutputPixelIndex(CS_Del_Type, data);
    
    
    tic;
    parpool('local',np)
    parfor i = 1 :  size(CS_ID,1)
        
        record = CS_ID(i,:);
        
        NewFolder = strcat('CS_', num2str(record(1)),'_SB_', num2str(record(2)));
        mkdir(Model_Out_Path , NewFolder)
        
        PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_CS_', num2str(record(5)), '_Or_', num2str(record(3)), '_Dir_', num2str(record(4)), '_id_', num2str(record(6)),'_PixelFile.txt'];
        %         PixelFileName   = [Model_Path,'SB_', num2str(record(2)),'_CS_', num2str(record(6)), '_Or_', num2str(record(4)), '_Dir_', num2str(record(5)), '_id_', num2str(record(7)),'_PixelFile.txt'];
        ClimateFileName = strcat(Model_Path,'ClimateZone', '_Cl_', num2str(record(9)), '.txt') ;
        ShpFileName     = strcat(Model_Path,'InputSHPTable_S_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        SoilParName     = strcat(Model_Path,'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        InputOtherName  = strcat(Model_Path,'InputOtherData_S_', num2str(record(1)),'_SB_',num2str(record(2)), '.txt');
        
        copyfile(PixelFileName,[Model_Out_Path, NewFolder,'\PixelFile.txt'])
        copyfile(ClimateFileName,[Model_Out_Path, NewFolder,'\ClimateZone.txt']);
        copyfile(ShpFileName,[Model_Out_Path, NewFolder,'\InputSHPTable.txt']);
        copyfile(SoilParName,[Model_Out_Path, NewFolder,'\InputSoilPar.txt']);
        copyfile(InputOtherName,[Model_Out_Path,NewFolder,'\InputOtherData.txt']);
        
        
        copyfile([Code_Path,'U3M_2D_code.exe'], [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'])
        cd ([Model_Out_Path, NewFolder])
        Run_U3M = [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'];
        
        system(Run_U3M)
        
        
    end
    
    delete(gcp('nocreate'))
    toc;
    
    
    %%
elseif CS_Del_Type == 3
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_LB_RB_H_CS\');
    
    FileName = [Output_Path,'data_ECS_LB_RB_H_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_LB_RB_H_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    
    
    tic;
    parpool('local',np)
    
    parfor i = 1 : size(CS_ID,1)
        
        record = CS_ID(i,:);
        
        
        NewFolder = strcat('CS_', num2str(record(1)),'_SB_', num2str(record(2)));
        mkdir(Model_Out_Path , NewFolder)
        PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_CS_', num2str(record(3)), '_Cl_', num2str(record(6)),'_PixelFile.txt'];
        ClimateFileName = strcat(Model_Path, 'ClimateZone', '_Cl_', num2str(record(6)), '.txt') ;
        ShpFileName = strcat(Model_Path, 'InputSHPTable_S_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        SoilParName = strcat(Model_Path, 'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        InputOtherName  = strcat(Model_Path,'InputOtherData_S_', num2str(record(1)),'_SB_',num2str(record(2)), '.txt');
        
        copyfile(PixelFileName,[Model_Out_Path, NewFolder,'\PixelFile.txt'])
        copyfile(ClimateFileName,[Model_Out_Path, NewFolder,'\ClimateZone.txt']);
        copyfile(ShpFileName,[Model_Out_Path, NewFolder,'\InputSHPTable.txt']);
        copyfile(SoilParName,[Model_Out_Path, NewFolder,'\InputSoilPar.txt']);
        copyfile(InputOtherName,[Model_Out_Path,NewFolder,'\InputOtherData.txt']);
        
        
        copyfile([Code_Path,'U3M_2D_code.exe'], [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'])
        cd ([Model_Out_Path, NewFolder])
        Run_U3M = [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'];
        
        system(Run_U3M)
        
        
    end
    toc;
    delete(gcp('nocreate'))
    
    %%
elseif CS_Del_Type == 4
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_Soil_Type_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_Soil_Type_CS\');
    
    FileName = [Output_Path,'data_ECS_SoilType_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_SoilType_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, ~ ] = OutputPixelIndex(CS_Del_Type, data);
    
    tic;
    parpool('local',np)
    parfor i = 1 : size(CS_ID,1)
        
        record = CS_ID(i,:);
        
        NewFolder = strcat('CS_', num2str(record(1)),'_SB_', num2str(record(2)));
        mkdir(Model_Out_Path , NewFolder)
        
        PixelFileName = [Model_Path, 'SB_', num2str(record(2)),'_S_', num2str(record(6)), '_Cl_', num2str(record(5)),'_PixelFile.txt'];
        ClimateFileName = strcat(Model_Path, 'ClimateZone', '_Cl_', num2str(record(5)), '.txt') ;
        ShpFileName = strcat(Model_Path, 'InputSHPTable_S_', num2str(record(1)), '_SB_', num2str(record(2)),'.txt');
        SoilParName = strcat(Model_Path, 'InputSoilParS_', num2str(record(1)),'_SB_', num2str(record(2)), '.txt');
        InputOtherName  = strcat(Model_Path,'InputOtherData_S_', num2str(record(1)),'_SB_',num2str(record(2)), '.txt');
        
        copyfile(PixelFileName,[Model_Out_Path, NewFolder,'\PixelFile.txt'])
        copyfile(ClimateFileName,[Model_Out_Path, NewFolder,'\ClimateZone.txt']);
        copyfile(ShpFileName,[Model_Out_Path, NewFolder,'\InputSHPTable.txt']);
        copyfile(SoilParName,[Model_Out_Path, NewFolder,'\InputSoilPar.txt']);
        copyfile(InputOtherName,[Model_Out_Path,NewFolder,'\InputOtherData.txt']);
        
        
        copyfile([Code_Path,'U3M_2D_code.exe'], [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'])
        cd ([Model_Out_Path, NewFolder])
        Run_U3M = [Model_Out_Path, NewFolder,'\U3M_2D_code.exe'];
        
        system(Run_U3M)
        
        
    end
    
    delete(gcp('nocreate'))
    toc;
    
    %%
    
    
    
end

