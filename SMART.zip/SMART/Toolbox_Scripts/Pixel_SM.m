function [ Output_Daily, Output_Monthly ] = Pixel_SM(  CS_Del_Type,Model_Out_Path, CS_ID)
%% ========================================================================
%%   This Matlab function is part of the post-processing tools of SMART.
%%   It maps pixel level soil moisture values per time step using user defined dates. 
%%   This option is only available to process U3M-2D output files of type 1 and 2 cross section delineations (distributed approaches).
%%   
%%   OUTPUTS:
%%   Daily and monthly pixel level soil moisture at 3 depths (top layer, 0-0.3m, 0-0.5m) 
%%
%%   This function is called by the post-processing scripts:
%%    Step13b_Spatial_Distribution_ET_*_Scale
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

RunInfo  = UserRunInfo;
st_date = RunInfo.StartDate;
end_date = RunInfo.EndDate;
Date_Num = (datenum(st_date, 'dd/mm/yyyy'):datenum(end_date, 'dd/mm/yyyy'));
[year, month, day] = datevec(datestr(Date_Num,'dd/mm/yyyy'),'dd/mm/yyyy' );
SimPeriod = size(year,1);

SM1_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);
SM3_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);
SM5_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);

step =1;

if CS_Del_Type == 1
    for i = 1 :  size(CS_ID, 1) %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        
        SM_mean_1 = zeros(record(3),  SimPeriod+2);
        SM_mean_2 = zeros(record(3),  SimPeriod+2);   %0.3 m
        SM_mean_3 = zeros(record(3),  SimPeriod+2);   %0.5 m
        for j = 1  :   record(3)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            
            SM_mean_1(j, 1) =  record(1);
            SM_mean_1(j, 2) =  record(2);
            SM_mean_1(j, 3:end) =  (A(:,end_col))';
            
            SM_mean_2(j, 1) =  record(1);
            SM_mean_2(j, 2) =  record(2);
            SM_mean_2(j, 3:end) = (mean(A(:, end_col-2: end_col),2))' ;
            
            SM_mean_3(j, 1) =  record(1);
            SM_mean_3(j, 2) =  record(2);
            SM_mean_3(j, 3:end) = (mean(A(:, end_col-4: end_col),2))' ;
            
            clear T A end_col
            
        end
        
        SM1_Pixel(step: size(SM_mean_1,1)+step-1 , :) = SM_mean_1;
        SM3_Pixel(step: size(SM_mean_2,1)+step-1 , :) = SM_mean_2;
        SM5_Pixel(step: size(SM_mean_3,1)+step-1 , :) = SM_mean_3;
        
        step = step + size(SM_mean_1,1);
    end
    %%
elseif CS_Del_Type == 2
    
    for i = 1 :  size(CS_ID, 1)%numel(CS_id)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        
        SM_mean_1 = zeros(record(3),  SimPeriod+2);
        SM_mean_2 = zeros(record(3),  SimPeriod+2);   %0.3 m
        SM_mean_3 = zeros(record(3),  SimPeriod+2);   %0.5 m
        for j = 1  :   record(3)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            
            SM_mean_1(j, 1) =  record(1);
            SM_mean_1(j, 2) =  record(2);
            % Need to add LF number
            SM_mean_1(j, 3:end) =  (A(:,end_col))';
            
            SM_mean_2(j, 1) =  record(1);
            SM_mean_2(j, 2) =  record(2);
            SM_mean_2(j, 3:end) = (mean(A(:, end_col-2: end_col),2))' ;
            
            SM_mean_3(j, 1) =  record(1);
            SM_mean_3(j, 2) =  record(2);
            SM_mean_3(j, 3:end) = (mean(A(:, end_col-4: end_col),2))' ;
            
            clear T A end_col
            
        end
        
        SM1_Pixel(step: size(SM_mean_1,1)+step-1 , :) = SM_mean_1;
        SM3_Pixel(step: size(SM_mean_2,1)+step-1 , :) = SM_mean_2;
        SM5_Pixel(step: size(SM_mean_3,1)+step-1 , :) = SM_mean_3;
        
        step = step + size(SM_mean_1,1);
        
        clear SM_mean_1 SM_mean_2 SM_mean_3
    end
end

Output_Daily = struct('SM1_Pixel',SM1_Pixel, 'SM3_Pixel', SM3_Pixel, 'SM5_Pixel', SM5_Pixel);

%% Monthly and Annual

day_d = ones(size(day,1),1);
date_num_ind = datenum(year, month, day_d);
[~, ~, idx2] = unique(date_num_ind);

c_days  = accumarray(idx2, day_d);
end_days_ind = cumsum(c_days);
start_days_ind = end_days_ind - c_days+1;

clear day_d date_num_ind idx2 c_days

% Save Monthly
Num_years = unique(year);
SM1_Pixel_Month  = zeros(size(SM1_Pixel, 1), numel(Num_years).*12);
SM3_Pixel_Month  = zeros(size(SM1_Pixel, 1), numel(Num_years).*12);
SM5_Pixel_Month  = zeros(size(SM1_Pixel, 1), numel(Num_years).*12);

SM1_Pixel_Month(:, 1:2) = SM1_Pixel(:, (1:2));
SM3_Pixel_Month(:, 1:2) = SM1_Pixel(:, (1:2));
SM5_Pixel_Month(:, 1:2) = SM1_Pixel(:, (1:2));

for i = 1 : numel(Num_years)*12
    
    SM1_Pixel_Month(:,i+2)   = mean(SM1_Pixel(:,start_days_ind(i)+2 :end_days_ind(i)+2  ), 2);
    SM3_Pixel_Month(:,i+2)   = mean(SM3_Pixel(:,start_days_ind(i)+2 :end_days_ind(i)+2  ), 2);
    SM5_Pixel_Month(:,i+2)   = mean(SM5_Pixel(:,start_days_ind(i)+2 :end_days_ind(i)+2  ), 2);
    
end

Output_Monthly = struct('SM1_Pixel_Month',SM1_Pixel_Month, 'SM3_Pixel_Month',SM3_Pixel_Month,'SM5_Pixel_Month', SM5_Pixel_Month);

clear SM1_Pixel_Month SM3_Pixel_Month SM5_Pixel_Month


end %function

