function [Output_Daily, Output_Monthly, Output_Yearly ] = LF_SM( CS_Del_Type,Model_Out_Path, CS_ID,CS_ID_LF  )
%% ========================================================================
%%   This Matlab function is part of the post processing tools of SMART.
%%   It calculates LF level soil moisture values from from U3M-2D output files for type 2, 3 and 4 cross section delineations. 
%%
%%   OUTPUTS:
%%   Daily, monthly and annual level soil moisture for every landform is stored at 3 depths (top layer, 0-0.3m, 0-0.5m) 
%%
%%   It is called by the following post-processing script:
%%   Step12a_Post_Processing_SM_*_Scale.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

RunInfo  = UserRunInfo;
st_date = RunInfo.StartDate;
end_date = RunInfo.EndDate;
Date_Num = (datenum(st_date, 'dd/mm/yyyy'):datenum(end_date, 'dd/mm/yyyy'));
[year, month, day] = datevec(datestr(Date_Num,'dd/mm/yyyy'),'dd/mm/yyyy' );
SimPeriod = size(year,1);

SM1_mean_LF = zeros(size(CS_ID_LF,1), SimPeriod + 3);
SM3_mean_LF = zeros(size(CS_ID_LF,1), SimPeriod + 3);
SM5_mean_LF = zeros(size(CS_ID_LF,1), SimPeriod + 3);

if CS_Del_Type == 2
    
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        SM_mean_1 = zeros(record(3),  SimPeriod);
        SM_mean_2 = zeros(record(3),  SimPeriod);   %0.3 m
        SM_mean_3 = zeros(record(3),  SimPeriod);   %0.5 m
        for j = 1: record(3)   %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            SM_mean_1(j, :) =  (A(:,end_col))';
            SM_mean_2(j, :) = (mean(A(:, end_col-2: end_col),2))' ;
            SM_mean_3(j, :) = (mean(A(:, end_col-4: end_col),2))' ;
            
            clear T A end_col
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,4));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,4) + 1;
        
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            SM1_mean_LF(step,1) = record(1);      %CS_id
            SM1_mean_LF(step,2) = record(2);      %Subbasin Num
            SM1_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM1_mean_LF(step,4:end) = mean(SM_mean_1(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM3_mean_LF(step,1) = record(1);      %CS_id
            SM3_mean_LF(step,2) = record(2);      %Subbasin Num
            SM3_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM3_mean_LF(step,4:end) = mean(SM_mean_2(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM5_mean_LF(step,1) = record(1);      %CS_id
            SM5_mean_LF(step,2) = record(2);      %Subbasin Num
            SM5_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM5_mean_LF(step,4:end) = mean(SM_mean_3(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            step = step +1;
        end
        clear  SM_mean_1  SM_mean_2  SM_mean_3
    end
    
    Output_Daily = struct('SM1_mean_LF',SM1_mean_LF, 'SM3_mean_LF', SM3_mean_LF, 'SM5_mean_LF', SM5_mean_LF);
    
elseif CS_Del_Type == 3
    
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        SM_mean_1 = zeros(record(3),  SimPeriod);
        SM_mean_2 = zeros(record(3),  SimPeriod);   %0.3 m
        SM_mean_3 = zeros(record(3),  SimPeriod);   %0.5 m
        for j = 1  :   record(3)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            SM_mean_1(j, :) =  (A(:,end_col))';
            SM_mean_2(j, :) = (mean(A(:, end_col-2: end_col),2))' ;
            SM_mean_3(j, :) = (mean(A(:, end_col-4: end_col),2))' ;
            
            clear T A end_col
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,4));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,4) + 1;
        
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            SM1_mean_LF(step,1) = record(1);      %CS_id
            SM1_mean_LF(step,2) = record(2);      %Subbasin Num
            SM1_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM1_mean_LF(step,4:end) = mean(SM_mean_1(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM3_mean_LF(step,1) = record(1);      %CS_id
            SM3_mean_LF(step,2) = record(2);      %Subbasin Num
            SM3_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM3_mean_LF(step,4:end) = mean(SM_mean_2(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM5_mean_LF(step,1) = record(1);      %CS_id
            SM5_mean_LF(step,2) = record(2);      %Subbasin Num
            SM5_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM5_mean_LF(step,4:end) = mean(SM_mean_3(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            step = step +1;
        end
        
    end
    
    Output_Daily = struct('SM1_mean_LF',SM1_mean_LF, 'SM3_mean_LF', SM3_mean_LF, 'SM5_mean_LF', SM5_mean_LF);
    
elseif CS_Del_Type == 4
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        
        SM_mean_1 = zeros(record(4),  SimPeriod);
        SM_mean_2 = zeros(record(4),  SimPeriod);   %0.3 m
        SM_mean_3 = zeros(record(4),  SimPeriod);   %0.5 m
        
        for j = 1  :   record(4)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            SM_mean_1(j, :) =  (A(:,end_col))';
            SM_mean_2(j, :) = (mean(A(:, end_col-2: end_col),2))' ;
            SM_mean_3(j, :) = (mean(A(:, end_col-4: end_col),2))' ;
            
            clear T A end_col
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,8));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,8) + 1;
        
        
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            SM1_mean_LF(step,1) = record(1);      %CS_id
            SM1_mean_LF(step,2) = record(2);      %Subbasin Num
            SM1_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM1_mean_LF(step,4:end) = mean(SM_mean_1(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM3_mean_LF(step,1) = record(1);      %CS_id
            SM3_mean_LF(step,2) = record(2);      %Subbasin Num
            SM3_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM3_mean_LF(step,4:end) = mean(SM_mean_2(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM5_mean_LF(step,1) = record(1);      %CS_id
            SM5_mean_LF(step,2) = record(2);      %Subbasin Num
            SM5_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM5_mean_LF(step,4:end) = mean(SM_mean_2(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            step = step +1;
        end
        
    end
    
    Output_Daily = struct('SM1_mean_LF',SM1_mean_LF, 'SM3_mean_LF', SM3_mean_LF, 'SM5_mean_LF', SM5_mean_LF);
    
elseif CS_Del_Type == 5
    
    step =1;
    for i = 1 :  size(CS_ID, 1) %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        SM_mean_1 = zeros(record(3),  SimPeriod);
        SM_mean_2 = zeros(record(3),  SimPeriod);   %0.3 m
        SM_mean_3 = zeros(record(3),  SimPeriod);   %0.5 m
        for j = 1  :   record(3)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            SM_mean_1(j, :) =  (A(:,end_col))';
            SM_mean_2(j, :) = (mean(A(:, end_col-2: end_col),2))' ;
            SM_mean_3(j, :) = (mean(A(:, end_col-4: end_col),2))' ;
            
            clear T A end_col
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,4));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,4) + 1;
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            SM1_mean_LF(step,1) = record(1);      %CS_id
            SM1_mean_LF(step,2) = record(2);      %Subbasin Num
            SM1_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM1_mean_LF(step,4:end) = mean(SM_mean_1(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM3_mean_LF(step,1) = record(1);      %CS_id
            SM3_mean_LF(step,2) = record(2);      %Subbasin Num
            SM3_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM3_mean_LF(step,4:end) = mean(SM_mean_2(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM5_mean_LF(step,1) = record(1);      %CS_id
            SM5_mean_LF(step,2) = record(2);      %Subbasin Num
            SM5_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM5_mean_LF(step,4:end) = mean(SM_mean_3(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            step = step +1;
        end
        
    end
    
    Output_Daily = struct('SM1_mean_LF',SM1_mean_LF, 'SM3_mean_LF', SM3_mean_LF, 'SM5_mean_LF', SM5_mean_LF);
    
elseif CS_Del_Type == 6
    
    step =1;
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        ind_CS = find(CS_ID_LF(:,1) == record(1));
        
        
        SM_mean_1 = zeros(record(4),  SimPeriod);
        SM_mean_2 = zeros(record(4),  SimPeriod);   %0.3 m
        SM_mean_3 = zeros(record(4),  SimPeriod);   %0.5 m
        
        for j = 1  :   record(4)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            SM_mean_1(j, :) =  (A(:,end_col))';
            SM_mean_2(j, :) = (mean(A(:, end_col-2: end_col),2))' ;
            SM_mean_3(j, :) = (mean(A(:, end_col-4: end_col),2))' ;
            
            clear T A end_col
            
        end
        
        Pixel_Num_LF1 = cumsum(CS_ID_LF(ind_CS,8));
        LF_start1 = (Pixel_Num_LF1) - CS_ID_LF(ind_CS,8) + 1;
        
        
        p_num = flipud(Pixel_Num_LF1 - LF_start1 + 1);
        Pixel_Num_LF = cumsum(p_num);
        LF_start = Pixel_Num_LF - p_num + 1;
        LF_Num = flipud(CS_ID_LF(ind_CS,3));
        
        for k = 1 : size(LF_start,1)          %get average per landform
            
            SM1_mean_LF(step,1) = record(1);      %CS_id
            SM1_mean_LF(step,2) = record(2);      %Subbasin Num
            SM1_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM1_mean_LF(step,4:end) = mean(SM_mean_1(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM3_mean_LF(step,1) = record(1);      %CS_id
            SM3_mean_LF(step,2) = record(2);      %Subbasin Num
            SM3_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM3_mean_LF(step,4:end) = mean(SM_mean_2(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            SM5_mean_LF(step,1) = record(1);      %CS_id
            SM5_mean_LF(step,2) = record(2);      %Subbasin Num
            SM5_mean_LF(step,3) = LF_Num(k);  %Landform Num
            SM5_mean_LF(step,4:end) = mean(SM_mean_2(LF_start(k) : Pixel_Num_LF(k), :),1);
            
            step = step +1;
        end
        
    end
    
    Output_Daily = struct('SM1_mean_LF',SM1_mean_LF, 'SM3_mean_LF', SM3_mean_LF, 'SM5_mean_LF', SM5_mean_LF);
end

%% Monthly and Annual
tic
day_d = ones(size(day,1),1);
date_num_ind = datenum(year, month, day_d);
[~, ~, idx2] = unique(date_num_ind);

SM1_mean_LFa     =  SM1_mean_LF(:, 4:end)';
SM3_mean_LFa     =  SM3_mean_LF(:, 4:end)';
SM5_mean_LFa     =  SM5_mean_LF(:, 4:end)';

% Save Monthly
Num_years = unique(year);
SM1_LF_m  = zeros(numel(Num_years).*12,size(SM1_mean_LFa, 2));
SM3_LF_m  = zeros(numel(Num_years).*12,size(SM1_mean_LFa, 2));
SM5_LF_m  = zeros(numel(Num_years).*12,size(SM1_mean_LFa, 2));

for i = 1 : size(SM1_mean_LFa,2);
    
    %         SM1_LF_m(:,i)   = accumarray(idx2, SM1_mean_LFa(:,i),[],@mean);
    SM1_LF_m(:,i)   = accumarray(idx2, SM1_mean_LFa(:,i))./accumarray(idx2,1);
    SM3_LF_m(:,i)   = accumarray(idx2, SM3_mean_LFa(:,i))./accumarray(idx2,1);
    SM5_LF_m(:,i)   = accumarray(idx2, SM5_mean_LFa(:,i))./accumarray(idx2,1);
    
end

%     SM1_LF_m1 = SM1_LF_m';
SM1_LF_Month = [SM1_mean_LF(:, (1:3)),SM1_LF_m']; clear SM1_LF_m

%     SM3_LF_m1 = SM3_LF_m';
SM3_LF_Month = [SM3_mean_LF(:, (1:3)),SM3_LF_m'];clear SM3_LF_m

%     SM5_LF_m1 = SM5_LF_m';
SM5_LF_Month = [SM5_mean_LF(:, (1:3)),SM5_LF_m'];clear SM5_LF_m

Output_Monthly = struct('SM1_LF_Month',SM1_LF_Month, 'SM3_LF_Month',SM3_LF_Month,'SM5_LF_Month', SM5_LF_Month);

% Save Annual
date_num_ind2 = datenum(year, ones(size(day,1),1), day_d);
[~, ~, idx_yr] = unique(date_num_ind2);

Num_years = unique(year);
SM1_LF_y      = zeros(numel(Num_years),size(SM1_mean_LFa,2));
SM3_LF_y      = zeros(numel(Num_years),size(SM1_mean_LFa,2));
SM5_LF_y      = zeros(numel(Num_years),size(SM1_mean_LFa,2));

for i = 1 : size(SM1_mean_LFa,2);
    
    %         SM1_LF_y(:,i)    = accumarray(idx_yr,SM1_mean_LFa(:,i),[],@mean);
    SM1_LF_y(:,i)    = accumarray(idx_yr,SM1_mean_LFa(:,i))./accumarray(idx_yr,1);
    SM3_LF_y(:,i)    = accumarray(idx_yr,SM3_mean_LFa(:,i))./accumarray(idx_yr,1);
    SM5_LF_y(:,i)    = accumarray(idx_yr,SM5_mean_LFa(:,i))./accumarray(idx_yr,1);
    
end

%     SM1_LF_y1 = SM1_LF_y';
SM1_LF_Year = [SM1_mean_LF(:, (1:3)),SM1_LF_y']; clear SM1_LF_y

%     SM3_LF_y1 = SM3_LF_y';
SM3_LF_Year = [SM3_mean_LF(:, (1:3)),SM3_LF_y']; clear SM3_LF_y

%     SM5_LF_y1 = SM5_LF_y';
SM5_LF_Year = [SM5_mean_LF(:, (1:3)),SM5_LF_y']; clear SM5_LF_y
Output_Yearly = struct('SM1_LF_Year',SM1_LF_Year,'SM3_LF_Year',SM3_LF_Year, 'SM5_LF_Year', SM5_LF_Year);


end
