clear all; close all; clc
%% ========================================================================
%%   This Matlab script creates pixle based or landform based ET output files from U3M-2D outputs for all the sub-basins.
%%   Outputs are at daily, monthly and yearly time scales.
%%
%%   INPUTS:
%%   1) User defines ones of the delineation types and the code reads respective .mat database file from  '...\Toolbox_Output\
%%     1 = DISTRIBUTED Pixel based delineation                    (6a)
%%     2 = DISTRIBUTED LANDFORM based delineation                 (6b)
%%     3 = ECS Left bank/right bank/headwater delineation         (6c)
%%     4 = ECS Soil type delineation                              (6d)
%%   2) Cross section database properties file for each delineation type
%%
%%   OUTPUTS:
%%   For every sub-basin one or multiple outputs are generated depending on the delineation mothod.
%%   1) Pixel_ET_Daily_Type*_catchment.mat     (TYPE 1 and 2)
%%   2) Pixel_ET_Monthly_Type*_catchment.mat   (TYPE 1 and 2)
%%   3) Pixel_ET_Yearly_Type*_catchment.mat    (TYPE 1 and 2)
%%   4) LF_ET_Daily_Type*_catchment.mat        (TYPE 2, 3, 4)
%%   5) LF_ET_Monthly_Type*_catchment.mat      (TYPE 2, 3, 4)
%%   6) LF_ET_Yearly_Type*_catchment.mat       (TYPE 2, 3, 4)
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%   OutputPixelIndex.m
%%   Pixel_ET.m
%%   LF_ET.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Code_Path = strcat(usr_Path,'\Toolbox_Scripts\U3M_2D\');
Output_Path    = strcat(usr_Path, '\Toolbox_Output\');

CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');

if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
    
else
    error('This delineation does not exist!!!');
end


%%
if CS_Del_Type == 1
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Distributed\');
    
    FileName = [Output_Path,'data_CS_Distributed_Pixel.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Distributed_Pixel.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Cross section unique number
    CS_id = (1:size(data,1))';
    CS_ID = [CS_id, data];
    CS_ID = [CS_ID(:,1), CS_ID(:,2), CS_ID(:,8)];
    clear data
    
    
    [Output_Daily, Output_Monthly, Output_Yearly] = Pixel_ET(CS_Del_Type,Model_Out_Path, CS_ID );
    
    save([Model_Out_Path,'Pixel_ET_Daily_Type1_catchment.mat'],'Output_Daily')
    save([Model_Out_Path,'Pixel_ET_Monthly_Type1_catchment.mat'],'Output_Monthly')
    save([Model_Out_Path,'Pixel_ET_Yearly_Type1_catchment.mat'],'Output_Yearly')
    
    %%
elseif CS_Del_Type == 2
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Landform\');
    
    FileName = [Output_Path,'data_CS_Landform.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Landform.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, CS_ID_LF  ] = OutputPixelIndex(CS_Del_Type, data);
    CS_ID = [CS_ID(:,1), CS_ID(:,2), CS_ID(:,8)];
    CS_ID_LF = [CS_ID_LF(:,1), CS_ID_LF(:,2), CS_ID_LF(:,13), CS_ID_LF(:,8)];
    
    [Output_Daily1, Output_Monthly1, Output_Yearly1 ] = Pixel_ET( CS_Del_Type,Model_Out_Path, CS_ID  );
    
    save([Model_Out_Path,'Pixel_ET_Daily_Type2_catchment.mat'], 'Output_Daily1','-v7.3')
    save([Model_Out_Path,'Pixel_ET_Monthly_Type2_catchment.mat'], 'Output_Monthly1','-v7.3')
    save([Model_Out_Path,'Pixel_ET_Yearly_Type2_catchment.mat'], 'Output_Yearly1','-v7.3')
    
    [Output_Daily, Output_Monthly, Output_Yearly ] = LF_ET( CS_Del_Type,Model_Out_Path, CS_ID,CS_ID_LF  );
    
    save([Model_Out_Path,'LF_ET_Daily_Type2_catchment.mat'], 'Output_Daily','-v7.3')
    save([Model_Out_Path,'LF_ET_Monthly_Type2_catchment.mat'], 'Output_Monthly','-v7.3')
    save([Model_Out_Path,'LF_ET_Yearly_Type2_catchment.mat'], 'Output_Yearly','-v7.3')
    
    %%
elseif CS_Del_Type == 3
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_LB_RB_H_CS\');
    
    FileName = [Output_Path,'data_ECS_LB_RB_H_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_LB_RB_H_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, CS_ID_LF  ] = OutputPixelIndex(CS_Del_Type, data);
    CS_ID = [CS_ID(:,1), CS_ID(:,2), CS_ID(:,5)];
    CS_ID_LF = [CS_ID_LF(:,1), CS_ID_LF(:,2), CS_ID_LF(:,4), CS_ID_LF(:,9)];
    
    [Output_Daily, Output_Monthly,Output_Yearly ] = LF_ET( CS_Del_Type,Model_Out_Path, CS_ID,CS_ID_LF  );
    
    save([Model_Out_Path,'LF_ET_Daily_Type3_catchment.mat'], 'Output_Daily','-v7.3')
    save([Model_Out_Path,'LF_ET_Monthly_Type3_catchment.mat'], 'Output_Monthly','-v7.3')
    save([Model_Out_Path,'LF_ET_Yearly_Type3_catchment.mat'], 'Output_Yearly','-v7.3')
    %%
elseif CS_Del_Type == 4
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_Soil_Type_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_Soil_Type_CS\');
    
    FileName = [Output_Path,'data_ECS_SoilType_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_SoilType_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    
    
    [Output_Daily, Output_Monthly, Output_Yearly ] = LF_ET( CS_Del_Type,Model_Out_Path, CS_ID,CS_ID_LF  );
    
    save([Model_Out_Path,'LF_ET_Daily_Type4_catchment.mat'], 'Output_Daily','-v7.3')
    save([Model_Out_Path,'LF_ET_Monthly_Type4_catchment.mat'], 'Output_Monthly','-v7.3')
    save([Model_Out_Path,'LF_ET_Yearly_Type4_catchment.mat'], 'Output_Yearly','-v7.3')
    %%
    
    
end