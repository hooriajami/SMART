function [conductivity] = CalculateK(pressureHead, Model, alpha, alphaInv, nn, nnInv, mm, mmInv, Qs, Qa, Qm, Qk, Ksat, Kk)

%% ========================================================================
%%   This Matlab function calculates unsaturated K for a given pressure head.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

conductivity=-100.0;
% 			double Qe,Qee,Qees,Qeek,Qek;
% 			double HMin,Hs,Hk,HH;
% 			double Lambda;
% 			double FFQ,FFQk;
% 			double PPar;
temp = 0.0; temp1 = 0.0;

switch Model
    
    case 1
        
        %van Genuchten soil hydraulic Model with Mualem's pore distribution
        %Vogel and Cislerova soil hydraulic Model with Mualem's pore distribution
        BPar = 0.5;
        PPar = 2.0;
        
        temp = max(alpha,1.0);
        temp1 = -power(1.0e300,nnInv);
        HMin  = temp1/temp;
        
        HH = max(pressureHead,HMin);
        
        temp = (Qs-Qa)/(Qm-Qa);
        Qees = min(temp,.9999999999999999999);
        
        temp = (Qk-Qa)/(Qm-Qa);
        Qeek = min(temp,Qees);
        
        temp = power(Qees,-mmInv);
        temp = temp - 1.0;
        temp = power(temp,nnInv);
        Hs = -alphaInv*temp;
        
        temp = power(Qeek,-mmInv);
        temp = temp - 1.0;
        temp = power(temp,nnInv);
        Hk   = -alphaInv*temp;
        
        if (pressureHead < Hk)
            
            temp = - alpha * HH;
            temp = power(temp,nn);
            temp = 1.0 + temp;
            Qee  = power(temp,-mm);
            
            Qe  = Qee*(Qm - Qa)/(Qs - Qa);
            Qek = Qeek*(Qm - Qa)/(Qs - Qa);
            
            temp = power(Qee,mmInv);
            temp = 1.0 - temp;
            temp = power(temp,mm);
            FFQ  = 1.0 - temp;
            
            temp = power(Qeek,mmInv);
            temp = 1.0 - temp;
            temp = power(temp,mm);
            FFQk = 1.0 - temp;
            
            if (FFQ <= 0.0)
                
                FFQ = mm*power(Qee,mmInv);
                
            end
            temp = Qe/Qek;
            temp = power(temp,BPar);
            temp1 = FFQ/FFQk;
            temp1 = power(temp1,PPar);
            Kr    = temp*temp1*Kk/Ksat;
            
            temp = Ksat*Kr;
            conductivity = max(temp,1.0e-37);
            
        end
        
        if (pressureHead >= Hk && pressureHead < Hs)
            
            temp  = Kk/Ksat;
            temp  = 1.0 - temp;
            temp1 = Hs - Hk;
            temp  = temp/temp1;
            temp1 = pressureHead - Hs;
            temp  = temp*temp1;
            Kr    = temp + 1.0;
            conductivity = Kr*Ksat;
        end
        
        if (pressureHead >= Hs)
            
            conductivity = Ksat;
        end
        
        
    case 2
        %Model = 2 Brooks and Corey model
        BPar   = 1.0;
        Lambda = 2.0;  %//=2 for Mualem's model
        Hs     = -alphaInv;
        
        if (pressureHead < Hs)
            
            temp  = BPar + Lambda;
            temp  = temp * nn;
            temp  = temp + 2.0;
            temp1 = -alpha*pressureHead;
            temp  = power(temp1,temp);
            Kr    = 1.0/temp;
            temp  = Kr * Ksat;
            conductivity = max(temp,1.0e-37);
            
        else
            
            conductivity = Ksat;
            
        end
        
end


end

