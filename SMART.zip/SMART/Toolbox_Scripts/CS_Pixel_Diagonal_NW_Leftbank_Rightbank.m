function [ data_f ] = CS_Pixel_Diagonal_NW_Leftbank_Rightbank(sub_basin_id, r_LF1, r_ex, c_ex, type_hor, temp, k, Elev, LF, slp, LandCover1d, ClimateZone1d, SoilType1d,SoilType2d, SoilType3d, SoilType4d, SoilLyr1d, SoilLyr2d, SoilLyr3d, SoilLyr4d, data_f,sub_info)
%% ========================================================================
%%   This Matlab function generates right and left banks cross sections for diagonal (NW and SE) streams.
%%   It works for Two stream directions:   1) Type I: South East to Northwest(outlet)
%%                                         2) Type II: Northwest to SouthEast (outlet)
%%   It also obtains cross section properties from the topographic and land cover variables on a "PIXEL BASIS".
%%
%%   It calls the following function:
%%    Write_Distributed_Pixel_File.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

%% Define number of cross sections for the right bank
r_LF1s = sort(r_LF1);                                                  % sort the row index for the stream cells


row_cs_index = r_LF1s(2) : 3: r_LF1s(end)-1;                            % Delineate the right and left bank cross sections using the index of first and last row (3) can change!





areaH  = sub_info(1,3);
areaR  = sub_info(1,4);
areaL  = sub_info(1,5);

str_direction= sub_info(1,2);

for j = 1 : numel(row_cs_index )
    
    row  =  row_cs_index(j);
    
    str_row = temp(row,:);                                            % From the landform 2d grid, select all the columns for a particular river row
    ind_river = find(str_row == 1);                                   % Select the stream cell
    
    if numel(ind_river) > 1
        
        ind_riverR = ind_river(1);
        ind_riverL = ind_river(2);
    else
        ind_riverR    = ind_river;
        ind_riverL    = ind_river;
    end
    
    [max_c_ex, I] =max(c_ex);
    test = temp(min(r_ex):row , ind_riverR: max_c_ex +1);
    
    col_IndexR = min(ind_riverR + (1:size(test,2))-1, size(temp,2));
    row_IndexR = row - (1:numel(col_IndexR))+1;
    
    
    
    CS_Type = 1;                                       % Right bank cross section code
    
    
    
    % Map the cells back to the linear index in the original grid to extract properties
    %     ind3 = sub2ind(size(temp),row_IndexR, repmat(col, numel(row_IndexR), 1));
    ind3 = sub2ind(size(temp),row_IndexR, col_IndexR);
    
    %check for non-zero cells
    ind= find(temp(ind3) ~= 0);
    if numel(ind) >= 1
        ind3 = ind3(ind)';
        
        
        max_Elv     = (Elev(ind3));
        mean_slp    = (slp(ind3));
        m_LF        = (LF(ind3));
        m_LC        = (LandCover1d(ind3));
        m_climate   = mode(ClimateZone1d(ind3));
        m_soil      = (SoilType1d(ind3));
        m_soil2     = mode(SoilType2d(ind3));
        m_soil3     = mode(SoilType3d(ind3));
        m_soil4     = mode(SoilType4d(ind3));
        mean_soild1 = (SoilLyr1d(ind3));
        mean_soild2 = (SoilLyr2d(ind3));
        mean_soild3 = (SoilLyr3d(ind3));
        mean_soild4 = (SoilLyr4d(ind3));
        [row1, col1] = ind2sub(size(temp),ind3);
        length       =  RunInfo.DEMRes;
        
        data_f(k, 1) =  sub_basin_id;
        data_f(k, 2) =  1;                                                 % Delineation Type Pixel based == 1
        data_f(k, 3) =  type_hor;                                          % Stream orientation horizontal
        data_f(k, 4) =  str_direction ;                                    % Get stream direction from the headwater Type 1 Horizontal stream
        data_f(k, 5) =  CS_Type;                                           % Right bank cross section code = 1
        data_f(k, 6) =  j;      %CS_id;
        data_f(k, 7) =  numel(ind3);%%length;
        data_f(k, 8) =  areaH+areaL+areaR;                                  %sub_area;  %???
        data_f(k, 9) =  areaH;
        data_f(k, 10) = areaR;
        data_f(k, 11) = areaL;
        data_f(k, 12) = 0;                                                 %landform = 0
        data_f(k, 13) = 0;                                                 %soil_type_landform = 0
        %data_f 14 to 15 is zero
        data_f(k, 16) = m_climate;
        %data_f 17 is zero
        
        uniq_m_soil = unique(m_soil);
        for c = 1  : numel(uniq_m_soil);
            data_f(k, 17+c) = uniq_m_soil(c);
        end
        data_f(k, 30) = row1(1);
        data_f(k, 31) = col1(1);
        
        data_f(k, 36) = m_soil2;
        data_f(k, 37) = m_soil3;
        data_f(k, 38) = m_soil4;
        dlmwrite([Output_Path, 'CS_coordinates.txt' ],ind3','precision','%10d','-append', 'delimiter','\t','newline','pc');
        %     var1 = table(repmat(sub_basin_id,size(row_IndexR,1), 1), m_soil, m_LF, repmat(length,size(row_IndexR,1), 1), mean_slp, m_LC, repmat(m_climate,size(row_IndexR,1),1), max_Elv, mean_soild1, mean_soild2, mean_soild3, mean_soild4, row1, col1);
        var1 = table(repmat(sub_basin_id,numel(ind3),1), m_soil, m_LF, repmat(length,numel(ind3), 1), mean_slp, m_LC, repmat(m_climate,numel(ind3),1), max_Elv, mean_soild1, mean_soild2, mean_soild3, mean_soild4, row1, col1); %8/6
        [data_f ] = Write_CS_Distributed_Pixel(var1,data_f);
        
        k = k+1;
        clear var1
    end
    %% Now delineate the Left bank cross section for the selected column
    
    %    row_IndexL = find(str_col(ind_riverL: end) ~= 0)+ ind_riverL - 1;
    [min_c_ex, I] =min(c_ex);
    %      test = temp(row: r_ex(I)+1, min_c_ex: ind_riverL);
    test = temp(row: max(r_ex), min_c_ex: ind_riverL);
    
    col_IndexL = min(ind_riverL - (1 : size(test,2))+1, size(temp,2));
    row_IndexL = row + (1 : numel(col_IndexL))-1;
    
    
    
    CS_Type = 2;                                                      % Left bank cross section code
    
    
    ind3 = sub2ind(size(temp),row_IndexL, col_IndexL);
    %     ind3 = sub2ind(size(temp),row_IndexL, repmat(col, numel(row_IndexL), 1));
    
    %check for non-zero cells
    ind= find(temp(ind3) ~= 0);
    if numel(ind) >= 1
        ind3 = ind3(ind)';
        
        max_Elv     = (Elev(ind3));
        mean_slp    = (slp(ind3));
        m_LF        = (LF(ind3));
        m_LC        = (LandCover1d(ind3));
        m_climate   = mode(ClimateZone1d(ind3));
        m_soil      = (SoilType1d(ind3));
        m_soil2     = mode(SoilType2d(ind3));
        m_soil3     = mode(SoilType3d(ind3));
        m_soil4     = mode(SoilType4d(ind3));
        mean_soild1 = (SoilLyr1d(ind3));
        mean_soild2 = (SoilLyr2d(ind3));
        mean_soild3 = (SoilLyr3d(ind3));
        mean_soild4 = (SoilLyr4d(ind3));
        [row1, col1] = ind2sub(size(temp),ind3);
        length      =  RunInfo.DEMRes;
        
        data_f(k, 1) =  sub_basin_id;
        data_f(k, 2) =  1;                                                 % Delineation Type Pixel based == 1
        data_f(k, 3) =  type_hor;                                          % Stream orientation horizontal
        data_f(k, 4) =  str_direction ;                                    % Get stream direction from the headwater
        data_f(k, 5) =  CS_Type;                                           % Left bank cross section code
        data_f(k, 6) =  j;
        data_f(k, 7) =  numel(ind3);%%length;
        data_f(k, 8) =  areaH+areaL+areaR;                                  %sub_area;  %???
        data_f(k, 9) =  areaH;
        data_f(k, 10) = areaR;
        data_f(k, 11) = areaL;
        data_f(k, 12) = 0;                                                 %landform = 0
        data_f(k, 13) = 0;                                                 %soil_type_landform = 0
        %data_f 14 to 15 is zero
        data_f(k, 16) = m_climate;
        %data_f 17 is zero
        
        uniq_m_soil = unique(m_soil);
        for c = 1  : numel(uniq_m_soil);
            data_f(k, 17+c) = uniq_m_soil(c);
        end
        data_f(k, 30) = row1(1);
        data_f(k, 31) = col1(1);
        
        data_f(k, 36) = m_soil2;
        data_f(k, 37) = m_soil3;
        data_f(k, 38) = m_soil4;
        dlmwrite([Output_Path, 'CS_coordinates.txt' ],ind3','precision','%10d','-append', 'delimiter','\t','newline','pc');
        %     var1 = table(repmat(sub_basin_id, numel(row_IndexL),1), m_soil, m_LF, repmat(length,numel(row_IndexL), 1), mean_slp, m_LC, repmat(m_climate,numel(row_IndexL),1), max_Elv, mean_soild1, mean_soild2, mean_soild3, mean_soild4, row1, col1);
        var1 = table(repmat(sub_basin_id, numel(ind3),1), m_soil, m_LF, repmat(length,numel(ind3),1), mean_slp, m_LC, repmat(m_climate,numel(ind3),1), max_Elv, mean_soild1, mean_soild2, mean_soild3, mean_soild4, row1, col1);
        [data_f ] = Write_CS_Distributed_Pixel(var1,data_f);
        
        k = k+1;
        clear var1
    end
    
end

end  % End function CS_Pixel_Horizontal_Leftbank_rightbank.m


