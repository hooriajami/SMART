function MakeMovies(data, Num_frames,VideoFileName, cMax )

VideoFileName = [VideoFileName, '.avi'];

writerObj = VideoWriter(VideoFileName);
writerObj.FrameRate = 2;

open(writerObj);
x = 500; y=500; width=1000; height=800;
hFig = figure(1);
set(hFig, 'Position', [x y width height]) ;
set(gcf,'PaperPositionMode','auto')

for k=1:Num_frames
  
%   imagescwithnan(  data(140:250,550:740, k), flipud(jet),[1 1 1], true, cMax)
   imagescwithnan(  data(:,:, k), flipud(jet),[1 1 1], true, cMax)
 title(['Monthly top soil moisture', ' ', 'Month: ',' ', num2str(k)]) 
 frame = getframe(hFig);
  writeVideo(writerObj,frame);
end
close(writerObj);

end

