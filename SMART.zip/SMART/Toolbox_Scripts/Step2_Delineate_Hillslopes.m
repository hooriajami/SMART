clear all; close all; clc;
%% ========================================================================
%%   This script delineates headwater, right bank and left bank hillslopes using TauDEM outputs from step 1 and TauDEM commandline exe files.
%%   To use this tool, the TAUDEM tools needs to be installed.
%%
%%   INPUTS:  (...\SMART\Toolbox_Input\)
%%   1) SubBasinGrid.txt
%%   2) StreamGrid.txt
%%   3) FlowDirBasinGrid.txt
%%   4) DInf Flow direction       (*ang.tif)
%%   5) stream network shapefile  (*net.shp)
%%
%%   OUTPUTS:
%%   Hillslopes_Final.mat Headwater =3, Right bank = 1, Left bank = 2;
%%   Hillslopes.txt
%%   Hillslopes_gis.asc   ASCIIGRID for ArcGIS or QGIS
%%
%%   It calls the following function:
%%   UserRunInfo.m
%%   Hillslope_Connect.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0 - Last update 1/11/2017
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Output_Path = strcat(usr_Path, '\Toolbox_Output\');
Input_Path  = strcat(usr_Path, '\Toolbox_Input\');
mkdir(Output_Path , 'temp')
tmp_Path    = strcat(usr_Path, '\Toolbox_Output\temp\');

dem  = input('Enter the name of the DEM File (.tif) : ',  's');
if isempty(dem);                              error('Enter the name of the DEM tif file');
elseif exist([Input_Path, dem], 'file') == 0; error('Warning: file does not exist:\n%s', [dem,' does not exist in ', Input_Path] );
end;

tic;
[pathstr,name,ext] = fileparts([Input_Path, dem]) ;
a = strread(name, '%s', 'delimiter', '.');
demName = a{1,1};

SubBasinFileName = strcat(Output_Path, '\SubBasinGrid.txt');
StreamFileName   = strcat(Output_Path,   '\StreamGrid.txt');
FlowDirFileName  = strcat(Output_Path,  '\FlowDirBasinGrid.txt');

% Check if sub-basin, stream and flowdirection text files are avaliable
if   exist(SubBasinFileName, 'file'); load(SubBasinFileName);
else error('Error: file does not exist:\n%s', [SubBasinFileName, ' does not exist in ', Output_Path]);
end

if   exist(StreamFileName, 'file'); load(StreamFileName)
else error('Error: file does not exist:\n%s', [StreamFileName, ' does not exist in ', Output_Path])
end

if   exist(FlowDirFileName, 'file'); load(FlowDirFileName)
else error('Error: file does not exist:\n%s', [FlowDirFileName , ' does not exist in ', Output_Path])
end

%%
Stream     = reshape(StreamGrid,[],1);
subBasins  = reshape(SubBasinGrid,[],1);
FlowDir    = reshape(FlowDirBasinGrid,[],1);
clear SubBasinFileName StreamFileName FlowDirFileName

% Find unique sub-basins in the catchment
uniq_basins = unique(subBasins);
uniq_basins(isnan(uniq_basins)) = [];

% Find flow direction of each sub-basin
FlowDir_Sub = zeros(numel(uniq_basins), 2);

for i = 1 : numel(uniq_basins)
    ind =  find(subBasins == uniq_basins(i));
    FlowDir_Sub(i,1) = uniq_basins(i);
    FlowDir_Sub(i,2) =  max(FlowDir(ind));
    clear ind
end

clear FlowDir FlowDirBasinGrid

%% Write river End nodes
[~, ~, ~, bbox] = geotiffread([Input_Path,demName,'.tif']);
rivers = shaperead([Output_Path, demName ,'net.shp']);

if isfield(rivers, 'Order') == 0
    riv_order ={rivers.strmOrder}';
else
    riv_order ={rivers.Order}';
end
WSNO     = {rivers.WSNO}';
riv_order1 = cell2mat(riv_order);
WSNO1 = cell2mat(WSNO);
StrOrd_Sub = [WSNO1, riv_order1];
clear WSNO WSNO1 riv_order riv_order1

for i = 1: numel(rivers)
    
    x = rivers(i).X(end-1);
    y = rivers(i).Y(end-1)  ;
    if i == 1
        structArray =struct('BoundingBox', bbox, 'id', rivers(i).WSNO(1));
        p = geopoint(y,x,structArray);
    else
        p = append(p, y,x, 'id', rivers(i).WSNO(1));
    end
    clear x y
end
shapewrite(p,[tmp_Path,'river_nodes_end'])
clear p rivers

riv_nodes = shaperead([tmp_Path,'river_nodes_end.shp']);
riv_nodes_id ={riv_nodes.id}';
riv_nodes_basin_id = cell2mat(riv_nodes_id);
clear riv_nodes_id riv_nodes

%% Delineate headwater hillslopes

np_Path1 =  '"C:\Program Files\Microsoft MPI\Bin\';
np_Path = [np_Path1, '"mpiexec -n', ' ', num2str(2), ' '];

for i = 1 : size(uniq_basins,1)
    
    ind_node = find(riv_nodes_basin_id == uniq_basins(i));
    cur_riv = shaperead([tmp_Path,'river_nodes_end.shp'], 'RecordNumbers', ind_node );
    shapewrite(cur_riv,[tmp_Path,'out1'])
    
    DinfAreaCmd = [np_Path, 'AreaDinf', ' ', '-ang',' ', Output_Path,demName,'ang.tif',' ', '-sca',' ', tmp_Path,num2str(i),'sca.tif', ' ', '-o', ' ', tmp_Path,'out1.shp', ' ', '-nc'];
    system(DinfAreaCmd)
    
    delete([tmp_Path,'out1','.*'])
    
    clear ind_node cur_riv
    
end


% Assign headwater hillslope  versus sideslopes
Hill_type =   zeros(size(SubBasinGrid));
for i = 1 :  size(uniq_basins,1)
    
    ind  = find(subBasins == uniq_basins(i));     % Select a specific sub-basin
    
    FlowAccInfGrid = double(imread([tmp_Path,num2str(i),'sca.tif']));
    idx = find(FlowAccInfGrid > 0);
    
    C1 = intersect(ind,idx);
    Hill_type(C1) = 3; %HW
    C2=setdiff(ind, idx);
    Hill_type(C2) = 2; %bank
    
    clear idx FlowAccInfGrid ind C1 C2
    
end
save([Output_Path,'Hill_Type_Temp.mat'], 'Hill_type')

%% Delineate side slopes (left bank and right bank)

Hill_Grid = zeros(size(SubBasinGrid));
area_HW_f = zeros(numel(uniq_basins),1);
n_conn = 4;

for i = 1 : size(uniq_basins,1)
    
    ind       = find(subBasins == uniq_basins(i));     % Select a specific sub-basin
    area_sub = numel(ind);
    temp      = zeros(size(SubBasinGrid));
    temp(ind) = Stream(ind);                        % Find stream in a given sub-basin
    
    [r_ex, c_ex]   = ind2sub(size(SubBasinGrid), ind); %find(temp ~= 0);               % Find the extent of the sub-basin
    [r_LF1, c_LF1] = find(temp == 1);                % Find the index of river cells (LF ==1)
    
    [max_rLF1, Imaxr] =max(r_LF1);
    Imaxr =  find(r_LF1>= max_rLF1, 1,'last');
    [min_rLF1, Iminr] =min(r_LF1);
    Iminr =  find(r_LF1<= min_rLF1, 1,'first');
    
    [max_cLF1, Imaxc] =max(c_LF1);
    Imaxc =  find(c_LF1>= max_cLF1, 1,'last');
    [min_cLF1, Iminc] =min(c_LF1);
    Iminc =  find(c_LF1<= min_cLF1, 1,'first');
    
    basin_one = zeros(size(SubBasinGrid));
    
    temp1 = zeros(size(SubBasinGrid));
    temp1(ind) = Hill_type(ind);
    %     figure(2)
    %     imagesc(temp1)
    idx = find(temp1 == 3); %select HW
    
    %     ind_HW = find(area_HW(:,1) == uniq_basins(i));
    area_HW_f = (numel(idx)/numel(ind))*100;
    
    %     if area_HW(ind_HW,2) < 20
    
    %         temp1(idx) = 2;
    %         idx=[];
    if area_HW_f < 2
        temp1(idx) = 2;
        idx=[];
        
    end
    
    % for intermediate sub-basins delete headwater
    ind_ord = find(StrOrd_Sub(:,1) == uniq_basins(i));
    str_ord = StrOrd_Sub(ind_ord,2);
    if str_ord >= 2
        temp1(idx) = 2;
        idx=[];
    end
    
    % Use index of river cells to specify orientation of stream
    if FlowDir_Sub(i,2) == 3
        
        temp(max_rLF1 : max(r_ex), c_LF1(Imaxr))= 1;
        temp(min(r_ex):min_rLF1, c_LF1(Iminr))= 1;
        [r_LF1, c_LF1] = find(temp == 1);
        
        for j = 1 : numel(r_LF1)
            temp1(r_LF1(j), 1: c_LF1(j)) = 2;
            temp1(r_LF1(j), c_LF1(j): max(c_ex)) = 1;
        end
        
        temp1(idx) = 3;
        basin_one(ind) =  temp1(ind);
        
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        
    elseif FlowDir_Sub(i,2) == 7
        
        temp(max_rLF1 : max(r_ex), c_LF1(Imaxr))= 1;
        temp(min(r_ex) : min_rLF1 , c_LF1(Iminr))= 1;
        [r_LF1, c_LF1] = find(temp == 1);
        
        for j = 1 : numel(r_LF1)
            temp1(r_LF1(j), 1: c_LF1(j)) = 1;
            temp1(r_LF1(j), c_LF1(j): max(c_ex)) = 2;
        end
        
        temp1(idx) = 3;
        basin_one(ind) =  temp1(ind);
        imagesc(basin_one)
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        
        %         imagesc(basin_one)
        
    elseif FlowDir_Sub(i,2) == 1
        
        temp( r_LF1(Imaxc), max_cLF1 : max(c_ex))= 1;
        temp(r_LF1(Iminc), min(c_ex): min_cLF1)= 1;
        [r_LF1, c_LF1] = find(temp == 1);
        
        for j = 1 : numel(r_LF1)
            temp1(r_LF1(j):max(r_ex), c_LF1(j)) = 1;
            temp1(1: r_LF1(j), c_LF1(j)) = 2;
        end
        
        temp1(idx) = 3;
        basin_one(ind) =  temp1(ind);
        
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        
    elseif FlowDir_Sub(i,2) == 5
        
        temp( r_LF1(Imaxc), max_cLF1 : max(c_ex))= 1;
        temp( r_LF1(Iminc), min(c_ex) : min_cLF1)= 1;
        [r_LF1, c_LF1] = find(temp == 1);
        imagesc(temp)
        
        
        for j = 1 : numel(r_LF1)
            temp1(r_LF1(j):max(r_ex), c_LF1(j)) = 2;
            temp1(1: r_LF1(j), c_LF1(j)) = 1;
            
        end
        imagesc(temp1)
        
        temp1(idx) = 3;
        basin_one(ind) =  temp1(ind);
        
        
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        
        imagesc(basin_one)
        
    elseif FlowDir_Sub(i,2) == 2
        
        count = numel(min(c_ex):  min_cLF1);
        for k = 1 : count
            idx_r(k,1)=r_LF1(Iminc) + k;
            idx_c(k,1)=min_cLF1 - k;
        end
        t= sub2ind(size(temp), idx_r,idx_c);
        temp(t) = 1;
        [r_LF1, c_LF1] = find(temp == 1);
        clear idx_r idx_c
        
        for j = 1 : numel(r_LF1)
            temp1(r_LF1(j), min(c_ex):max(c_ex)) = 2;
            temp1(r_LF1(j),c_LF1(j): max(c_ex)) = 1;
        end
        temp1(idx) = 3;
        
        
        basin_one(ind) =  temp1(ind);
        
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        
        
    elseif FlowDir_Sub(i,2) == 6
        
        count = numel(max_cLF1:  max(c_ex));
        for k = 1 : count
            idx_r(k,1)=r_LF1(Imaxc) - k;
            idx_c(k,1)=max_cLF1 + k;
        end
        t= sub2ind(size(temp), idx_r,idx_c);
        temp(t) =1 ;
        [r_LF1, c_LF1] = find(temp == 1);
        clear idx_r idx_c
        
        for j = 1 : numel(r_LF1)
            %                temp1(1:r_LF1(j), min(c_ex):max(c_ex)) = 1;
            temp1(1:r_LF1(j), min(c_ex):c_LF1(j)) = 1;
            temp1(r_LF1(j),c_LF1(j): max(c_ex)) = 2;
        end
        
        temp1(idx) = 3;
        basin_one(ind) =  temp1(ind);
        
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        
        
    elseif FlowDir_Sub(i,2) == 4
        
        count = numel(max_cLF1:  max(c_ex));
        for k = 1 : count
            idx_r(k,1)=r_LF1(Imaxc) + k;
            idx_c(k,1)=max_cLF1 + k;
        end
        t= sub2ind(size(temp), idx_r,idx_c);
        temp(t)=1;
        [r_LF1, c_LF1] = find(temp == 1);
        clear idx_r idx_c
        
        for j = 1 : numel(r_LF1)
            temp1( min(r_ex):r_LF1(j), c_LF1(j)) = 1;
            temp1(r_LF1(j):max(r_ex), c_LF1(j)) = 2;
        end
        
        
        temp1(idx) = 3;
        basin_one(ind) =  temp1(ind);
        
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        
    else
        
        count = numel(min(c_ex):  min_cLF1);
        for k = 1 : count
            idx_r(k,1)=r_LF1(Iminc) - k;
            idx_c(k,1)=min_cLF1 - k;
        end
        t= sub2ind(size(temp), idx_r,idx_c);
        temp(t)=1;
        
        [r_LF1, c_LF1] = find(temp == 1);
        clear idx_r idx_c
        
        for j = 1 : numel(r_LF1)
            temp1(1: r_LF1(j),  c_LF1(j)) = 2;
            temp1(r_LF1(j):max(r_ex), c_LF1(j)) = 1;
        end
        
        temp1(idx) = 3;
        basin_one(ind) =  temp1(ind);
        
        CC2 = bwconncomp(basin_one == 2,n_conn);
        count2= cellfun('length',CC2.PixelIdxList);
        ic2 = find(count2 ~= 1);
        count2 = count2(ic2);
        
        CC1 = bwconncomp(basin_one == 1,n_conn);
        count1= cellfun('length',CC1.PixelIdxList);
        ic1 = find(count1 ~= 1);
        count1 = count1(ic1);
        
        [ basin_one ] = Hillslope_Connect( basin_one,n_conn, idx );
        %         num_itr1 = numel(count1);
        %         num_itr2 = numel(count2);
        %
        %          if num_itr1 >= 2
        %              num_itr = num_itr1;
        %          elseif num_itr2 >= 2
        %                num_itr = num_itr2;
        %          end
        %
        %         while num_itr >= 2
        %             [ basin_one ] = hillslope_connect( basin_one,n_conn, idx );
        %            num_itr = num_itr- 1;
        %             imagesc(basin_one)
        %         end
        
    end
    
    Hill_Grid = Hill_Grid + basin_one;
    clear temp r_LF1 c_LF1  ind idx basin_one r_ex c_ex basin_one max_rLF1 Imaxr max_cLF1 Imaxc  min_rLF1 Iminr max_rLF1 Imaxr temp1
    
end

figure(1)
imagesc(Hill_Grid)
title('Hillslope Grid')
save([Output_Path,'Hillslopes_Final.mat'], 'Hill_Grid')

if  exist([Output_Path,'Hillslopes.txt'], 'file'); error('Warning:\n%s', ['Hillslopes.txt already exists in ', Output_Path] );
else dlmwrite([Output_Path,'Hillslopes.txt'],Hill_Grid,'delimiter','\t');
end


%Write ASCIIGRID for ArcGIS
OutputFileName =[Output_Path,'Hillslopes_gis.asc'];
if  exist(OutputFileName, 'file'); error('Warning:\n%s', ['Hillslopes_gis.asc already exists in ', Output_Path] );
else WriteASCIIGrid(OutputFileName, Output_Path, Hill_Grid)
end

toc;