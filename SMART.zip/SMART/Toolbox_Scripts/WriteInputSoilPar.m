function WriteInputSoilPar(uniq_CS_soil, ModelType, Pars,Model_Path)
%% ========================================================================
%%   This Matlab function writes the soil input parameter file for every soil type in a cross section.
%%   The format of this file is based on U3M-2D model code.
%%
%%   INPUTS:
%%   User defines : Cross section id, Soil hydraulic model, Soil hydraulic parameters and path to save files. 
%%
%%   OUTPUTS:
%%   1) Input Soil Parameter files (InputSoilParS_*_SB_*.txt) for every cross section in (...\Model_Input\DEL TYPE)
%%
%%   This function is called by:
%%   Step7-CreateSoilPar_Files_*.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
headerLine1 = 'Number of materials 4';
headerLine2 =  'modelType[material 1] modelType[material 2]......';
headerLine4 = '         Qr        Qs     alpha         n      Ksat         l        Qm        Qa        Qk        Kk';

FileName = [Model_Path, 'InputSoilPar', 'S_', num2str(uniq_CS_soil(:,1)),'_SB_',num2str(uniq_CS_soil(:,2)),'.txt' ];
fid = fopen(FileName,'a+');
fprintf (fid, '%s\n', headerLine1);
fprintf (fid, '%s\n', headerLine2);
fprintf (fid, '%10d%10d%10d%10d\t\n', ModelType, ModelType, ModelType, ModelType);
fprintf (fid, '%s\n', headerLine4);

for j = 1 : 4
% fprintf(fid, '%10.2E%s%10.2E%s%10.2E%s%10.2E%s%10.2E%s%10.2E%s%10.2E%s%10.2E%s%10.2E%s%10.2E\n', t(j,1), ',',t(j,2), ',',t(j,3), ',',t(j,4), ',',t(j,5), ',',t(j,6),',', 0, ',', 0, ',',0, ',', 0 );
% fprintf(fid, '%11.4f%s%10.4f%s%5.2f%s%12.4f%s%14.5E%s%10.1f%s%10.3f%s%10.3f%s%10.3f%s%10.3f\n', Pars(j,1), ',',Pars(j,2), ',',Pars(j,3), ',',Pars(j,4), ',',Pars(j,5), ',',Pars(j,6).*-1,',', 0.2, ',', 0.2, ',',0.2, ',', 0.2 );
fprintf(fid, '%11.4f%s%10.4f%s%5.2f%s%12.4f%s%14.5E%s%10.1f%s%10.3f%s%10.3f%s%10.3f%s%10.3f\n', Pars(j,1), ',',Pars(j,2), ',',Pars(j,3), ',',Pars(j,4), ',',Pars(j,5), ',',Pars(j,6),',', 0.2, ',', 0.2, ',',0.2, ',', 0.2 ); %7/7/15
end

fprintf (fid, '%s\n', 'Ksub m/s' );
fprintf (fid, '%10.5E\n', Pars(1,5) );
fclose(fid) ;

end

