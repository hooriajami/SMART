function [ Output_Daily] = Pixel_SM_Lyr(  CS_Del_Type,Model_Out_Path, CS_ID)
%% ========================================================================
%%   This Matlab function is part of the post processing tools of the toolbox.
%%   It calculate pixel level soil moisture values from output files for type 1 and 2 delineations
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

RunInfo  = UserRunInfo;
st_date = RunInfo.StartDate;
end_date = RunInfo.EndDate;
Date_Num = (datenum(st_date, 'dd/mm/yyyy'):datenum(end_date, 'dd/mm/yyyy'));
[year, month, day] = datevec(datestr(Date_Num,'dd/mm/yyyy'),'dd/mm/yyyy' );
SimPeriod = size(year,1);

SM2_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);
SM3_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);

step =1;

if CS_Del_Type == 1
    for i = 1 :  size(CS_ID, 1)%numel(CS_id)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        
        %         SM_mean_1 = zeros(record(3),  SimPeriod+2);
        SM_mean_2 = zeros(record(3),  SimPeriod+2);   %0.3 m
        SM_mean_3 = zeros(record(3),  SimPeriod+2);   %0.5 m
        for j = 1  :   record(3)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            
            
            SM_mean_2(j, 1) =  record(1);
            SM_mean_2(j, 2) =  record(2);
            SM_mean_2(j, 3:end) = A(:, end_col-1)' ;
            
            SM_mean_3(j, 1) =  record(1);
            SM_mean_3(j, 2) =  record(2);
            SM_mean_3(j, 3:end) = A(:, end_col-2)' ;
            
            clear T A end_col
            
        end
        
        SM2_Pixel(step: size(SM_mean_2,1)+step-1 , :) = SM_mean_2;
        SM3_Pixel(step: size(SM_mean_3,1)+step-1 , :) = SM_mean_3;
        
        step = step + size(SM_mean_2,1);
    end
    %%
elseif CS_Del_Type == 2
    
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        
        SM_mean_2 = zeros(record(3),  SimPeriod+2);   %0.3 m
        SM_mean_3 = zeros(record(3),  SimPeriod+2);   %0.5 m
        for j = 1  :   record(3)  %read all pixels
            
            SM_FileName = [Output_Files_Path,'OutputSoilMoisture_', num2str(j),'.txt'];
            
            T = readtable(SM_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            A = table2array(T);
            end_col =  size(T,2)-1;
            
            
            SM_mean_2(j, 1) =  record(1);
            SM_mean_2(j, 2) =  record(2);
            SM_mean_2(j, 3:end) = A(:, end_col-1) ;
            
            SM_mean_3(j, 1) =  record(1);
            SM_mean_3(j, 2) =  record(2);
            SM_mean_3(j, 3:end) = A(:, end_col-2)' ;
            
            clear T A end_col
            
        end
        
        SM2_Pixel(step: size(SM_mean_2,1)+step-1 , :) = SM_mean_2;
        SM3_Pixel(step: size(SM_mean_3,1)+step-1 , :) = SM_mean_3;
        
        step = step + size(SM_mean_2,1);
        
        clear SM_mean_2 SM_mean_3
    end
end

Output_Daily = struct('SM2_Pixel',SM2_Pixel, 'SM3_Pixel', SM3_Pixel);



end %function

