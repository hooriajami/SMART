% This function determines soil texture class based on USDA classification
% scheme. This file is originally written by Holger Hoffman and it was downloaded from MATLAB File Exchange:
% https://www.mathworks.com/matlabcentral/fileexchange/45468-soil-classification-sand--clay--t-varargin-/content/soil_classification.m
% This function file is modified by Hoori Ajami. 
%--------------------------------------------------------------------------
%Input:
%sand: sand fraction [%], (nx1)
%clay: Clay fraction[%], (nx1)
%T: type of classification: 'usda'
%Varargin{1}: PLOT, BOOLEAN: 1: plots the usda texture triangle plus data
%points
%
%Output:
%CellArray of soil classes
%silt: silt fraction [%], (nx1)
%
%Example:
%soil_classification(sand,clay, 'usda')
%soil_classification([0.5;0.3;0.1;0],[0.1;0.2;0.4;0.8], 'usda',1)
%--------------------------------------------------------------------------
%disp('-------------------------------------------------------------------')
%disp('                       U S D A soil Classification                 ')
%disp('-------------------------------------------------------------------')
function [SC, SC_num, silt]=Soil_Classification(sand, clay, T)
 if strcmp(T,'usda')==0
    error('only usda defined so far...')
 end
 if isempty(sand)|isnan(sand)|min(sand)<0
     error('wrong input: sand')
 end
 if isempty(clay)|isnan(clay)|min(clay)<0
     error('wrong input: sand')
 end
 if max(sand)>1
     sand=sand/100;
     warning('sand is >1; ...divided by 100 to get fraction instead of %')
 end
 if max(clay)>1
     clay=clay/100;
     warning('clay is >1; ...divided by 100 to get fraction instead of %')
 end
 if max(sand+clay)>1
    error('data inconsisent: (Clay + Sand)>1')
 end
%--------------------------------------------------------------------------
 silt=1-sand-clay;

 for i=1:length(clay)
     
     if (silt(i)+1.5*clay(i))<.15
         SC{i,:}='SAND';
         SC_num(i,1) = 1;
     elseif ((silt(i)+1.5*clay(i))>=.15)&&((silt(i)+2*clay(i))<.3)
         SC{i,:}='LOAMY SAND';
         SC_num(i,1) = 2;
%      elseif (clay(i)>=0.07) && (clay(i)<=0.2) && (sand(i)>0.52) && ((silt(i)+2*clay(i))>=0.3) 
     elseif ((clay(i)>=0.07) && (clay(i)<=0.2) && (sand(i)>0.52) && ((silt(i)+2*clay(i))>=0.3) || (clay(i) < 0.07 && silt(i) < 0.5 && (silt(i)+2*clay(i))>= .3))
         SC{i,:}='SANDY LOAM';
         SC_num(i,1) = 3;
%      elseif (clay(i)<0.07) && (silt(i) < 0.5) && ((silt(i)+2*clay(i))>=0.3)
%          SC{i,:}='SANDY LOAM';
%          SC_num(i,1) = 3;  %HA
     elseif (clay(i)>=0.07) && (clay(i)<=0.27) && (silt(i)>=0.28) && (silt(i)<0.5) && (sand(i)<=0.52)
         SC{i,:}='LOAM';
         SC_num(i,1) = 4;
     elseif ((silt(i)>0.5) && clay(i)>0.12 && clay(i)<0.27) || (silt(i)>=0.5 && silt(i)<0.8 && clay(i)<0.12)
         SC{i,:}='SILT LOAM';
         SC_num(i,1) = 5;
     elseif silt(i)>=0.8 && clay(i)<0.12
         SC{i,:}='SILT';
         SC_num(i,1) = 6;
     elseif clay(i)>=0.2 && clay(i)<0.35 && silt(i)<0.28 && sand(i)>0.45
         SC{i,:}='SANDY CLAY LOAM';
         SC_num(i,1) = 7;
     elseif clay(i)>=0.27 && clay(i) <0.4 && sand(i)>0.2 && sand(i)<=0.45
         SC{i,:}='CLAY LOAM';
         SC_num(i,1) = 8;
     elseif clay(i)>=0.27 && clay(i)<0.4 && sand(i)<=0.2
         SC{i,:}='SILTY CLAY LOAM';
         SC_num(i,1) = 9;
     elseif clay(i)>=0.35 && sand(i)>0.45
         SC{i,:}='SANDY CLAY';
         SC_num(i,1) = 10;
     elseif clay(i)>=0.4 && silt(i)>=0.4
         SC{i,:}='SILTY CLAY';
         SC_num(i,1) = 11;
     elseif clay(i)>= 0.4 && sand(i)<=0.45 && silt(i)<0.4
         SC{i,:}='CLAY';
         SC_num(i,1) = 12;

     end
 end
 
end 