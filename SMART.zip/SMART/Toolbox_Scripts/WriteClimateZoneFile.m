function WriteClimateZoneFile(uniq_climate,data, Param_Path , Model_Path, InputLAIMonth, Kpan)
%% ========================================================================
%%   This Matlab function writes the climatezone.txt file and stores it in a relevant path based on the cross 
%%   section delineation approach.
%%   The format of this file is based on U3M-2D input.
%%
%%  INPUTS:
%%  1) Climate time series for each climate zone in the domain with the following information in header (1)ClimateZone	(2)Date	(3)T.Max	(4)T.Min	(5)Rain	(6)Evap	(7)Radn
%%  2) User defined Monthly LAI climatology or default LAI climatology provided in SMART parameter files folder. LAI is adjused based on monthly precipitation to get PET for tree, pasture and crop.
%%     See U3M-1D documentation for the equations used here.
%%
%%   OUTPUTS:
%%   1) It generates ClimayZone_Cl_*.txt' for every cross section in (...\Model_Input\DEL TYPE)
%%
%%   This function is called by:
%%   Step8_WriteClimateZoneFile_*_Scale.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
% data is climate series input

date = data{1,1};
[year month day] = datevec(date(:,2), 'dd/mm/yyyy');

clim = (data{1,2});
rain = clim(:,3);
evap = clim(:,4);
clear data

% Calculate monthly precipitation to get scalers for the monthly LAI
uniq_yr = unique(year);
for i = 1 : length(uniq_yr)
    
    ind = find(year == uniq_yr(i));
    tmp_month = month(ind);
    tmp_rain = rain(ind);
    
    for j = 1 : 12
        ind2 = find(tmp_month == j);
        P_month(i,j) = sum(tmp_rain(ind2));
        
    end
    clear tmp_rain tmp_month ind ind2
    
end

meanP = mean(reshape(P_month, [],1));
scaler_P = P_month ./ meanP;

% Read Monthly LAI data and input parameters
% Header Line 1: Month	Tree_LAI	Crop_LAI	Pasture_LAI	Beta_Tree	Beta_crop	Beta_pasture	k_light_tree	k_light_crop	k_light_pasture
fid = fopen([Param_Path,InputLAIMonth], 'rt');
data_L = textscan(fid, '%d %f %f %f %f %f %f %f %f %f','Delimiter',',', 'CollectOutput',1, 'HeaderLines', 1);
fclose(fid);

data_LAI = data_L{1,2};
clear data_L

LAIavg_T = data_LAI(:,1);
LAIavg_C = data_LAI(:,2);
LAIavg_P = data_LAI(:,3);

beta_T = data_LAI(:,4);
beta_C = data_LAI(:,5);
beta_P = data_LAI(:,6);

Klight_T = data_LAI(:,7);
Klight_C = data_LAI(:,8);
Klight_P = data_LAI(:,9);

LAI_month_T = repmat(LAIavg_T',size(P_month, 1),1).* (scaler_P).^ repmat(beta_T',size(P_month, 1),1);
LAI_month_P = repmat(LAIavg_P',size(P_month, 1),1).* (scaler_P).^ repmat(beta_P',size(P_month, 1),1);
LAI_month_C = repmat(LAIavg_C',size(P_month, 1),1).* (scaler_P).^ repmat(beta_C',size(P_month, 1),1);

% For tree
var1_T = exp(repmat(Klight_T',size(P_month, 1),1) .* LAI_month_T.* -1);
var=zeros(size(rain,1),1);
exp_mLAI_T =[];
for i = 1 : length(uniq_yr)
    
    ind = find(year == uniq_yr(i));
    tmp_month = month(ind);
    tmp_var = var(ind);
    
    for j = 1 : 12
        ind2 = find(tmp_month == j);
        tmp_var(ind2,1) = var1_T(i,j);
    end
    
    exp_mLAI_T = [exp_mLAI_T; tmp_var];
end

ETo_T = evap .* Kpan .* (1-exp_mLAI_T);
ETg_T = evap .* Kpan .* exp_mLAI_T;
ETu_T = zeros(size(rain,1),1);

% For crop
var1_C = exp(repmat(Klight_C',size(P_month, 1),1) .* LAI_month_C.* -1);
var=zeros(size(rain,1),1);
exp_mLAI_C =[];
for i = 1 : length(uniq_yr)
    
    ind = find(year == uniq_yr(i));
    tmp_month = month(ind);
    tmp_var = var(ind);
    
    for j = 1 : 12
        ind2 = find(tmp_month == j);
        tmp_var(ind2,1) = var1_C(i,j);
    end
    
    exp_mLAI_C = [exp_mLAI_C; tmp_var];
end

ETo_C = zeros(size(rain,1),1);
ETg_C = evap .* Kpan .* exp_mLAI_C;
ETu_C = evap .* Kpan .* (1-exp_mLAI_C);


% For pasture
var1_P = exp(repmat(Klight_P',size(P_month, 1),1) .* LAI_month_P.* -1);
var=zeros(size(rain,1),1);
exp_mLAI_P =[];

for i = 1 : length(uniq_yr)
    
    ind = find(year == uniq_yr(i));
    tmp_month = month(ind);
    tmp_var = var(ind);
    
    for j = 1 : 12
        ind2 = find(tmp_month == j);
        tmp_var(ind2,1) = var1_P(i,j);
    end
    
    exp_mLAI_P = [exp_mLAI_P; tmp_var];
end

ETo_P = zeros(size(rain,1),1);
ETg_P = evap .* Kpan .* exp_mLAI_P;
ETu_P = evap .* Kpan .* (1-exp_mLAI_P);


%% Write ClimateZone.txt
headerLine1 ='(1)ClimateZone,(2)Date,(3)T.Max,(4)T.Min,(5)Rain,(6)Evap,(7)Radn,(8)P_Eto_tree,(9)P_Etu_tree,(10)P_Etg_tree,(11)P_Etu_crop,(12)P_Etg_crop,(13)P_Etu_pasture,(14)P_Etg_pasture';
headerLine2 ='(A/B/C/D),(dd/mm/yyyy),(oC),(oC),(mm),(mm),(MJ/m2),(mm),(mm),(mm),(mm),(mm),(mm),(mm)';

fid = fopen([Model_Path,'ClimateZone_Cl_', num2str(uniq_climate), '.txt'],'w');
fprintf (fid, '%s\n', headerLine1);
fprintf (fid, '%s\n', headerLine2);

for i = 1 : size(rain,1)
    
    fprintf(fid, '%s', date{i,1}, ',');      %zone
    fprintf(fid, '%s', date{i,2}, ',');      %date
    fprintf(fid, '%4.2f%s', clim(i,1), ',');  %Tmax
    fprintf(fid, '%4.2f%s', clim(i,2), ',');  %Tmin
    fprintf(fid, '%4.2f%s', rain(i), ',');
    fprintf(fid, '%4.2f%s', evap(i), ',');
    fprintf(fid, '%4.2f%s', clim(i,5), ',');
    fprintf(fid, '%10.8f%s', ETo_T(i,1), ',');
    fprintf(fid, '%10.8f%s', ETu_T(i,1), ',');
    fprintf(fid, '%10.8f%s', ETg_T(i,1), ',');
    fprintf(fid, '%10.8f%s', ETu_C(i,1), ',');
    fprintf(fid, '%10.8f%s', ETg_C(i,1), ',');
    fprintf(fid, '%10.8f%s', ETu_P(i,1), ',');
    fprintf(fid, '%10.8f\n', ETg_P(i,1));
    
end

fclose(fid);

end

