clear all;clc;
%% ========================================================================
%%   This Matlab script writes soil input parameter file and SHP Input Table file for every cross section in a sub-basin depending on the delineation approach.
%%   This version gets hydraulic properties from the ROSETTA database based on USDA soil texture properties.
%%   This version hydraulic model is "van Genuchten".
%%
%%   INPUTS:
%%   User defines ones of the delineation types and the code reads respective .mat database file from  '...\SMART\Toolbox_Output\
%%   1 = DISTRIBUTED Pixel based delineation                    (6a)
%%   2 = DISTRIBUTED LANDFORM based delineation                 (6b)
%%   3 = ECS Left bank/right bank/headwater delineation         (6c)
%%   4 = ECS Soil type delineation                              (6d)
%%
%%   OUTPUTS:
%%   Cross section Soil Parameter files 'InputSoilParS_*.txt'   in (...\SMART\Model_Input\DEL TYPE)
%%   Cross section InputSHPTable files  'InputSHPTable_S_*.txt' in (...\SMART\Model_Input\DEL TYPE)
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%   WriteInputSoilPar.m
%%   WriteInputSHPTable.m   This calls multiple functions.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

% Load soil parameter file
filename = RunInfo.SoilTextureFileParameter;
SoilPars = xlsread([usr_Path, '\Toolbox_Parameter_Files\', filename]);

ModelType = input('Select Hydraulic Model (van Genuchten = 0; Brooks and Corey =1 ; Vogel and Cislerova=2: ');

CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');

if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
else
    
    error('This delineation type does not exist!!!');
    
end

%%
if CS_Del_Type == 1
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');
    FileName = [Output_Path,'data_CS_Distributed_Pixel.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Distributed_Pixel.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Stores soil types for the catchment in a master parameter matrix
    soil_id    = [data(:, 18:22),data(:, 36:38)] ;
    soil_idr   = reshape(soil_id,[],1);
    uniq_soil1 = unique(soil_idr);
    ind = find(uniq_soil1 ~= 0);
    uniq_soil = uniq_soil1(ind);
    clear ind soil_id soil_idr uniq_soil1
    
    % Cross section unique number
    CS_id = (1:size(data,1));
    CS_id = [CS_id', data(:, 1)];
    Model_Pars = zeros(size(uniq_soil,1), 7);
    
    for i = 1 : size(uniq_soil,1)
        
        index                = find(SoilPars(:,1) == uniq_soil(i));
        Model_Pars(i, 1)     = uniq_soil(i);
        Model_Pars(i, 2:end) = SoilPars(index, 4:end);
        
    end
    
    
    for f = 1 : size(data,1)
        
        tmp_data = data(f,18: 21);                %select top layer soil types for a given CS
        soil_cs_top_ind = find(tmp_data ~= 0);
        soil_cs_top = tmp_data(soil_cs_top_ind);
        soil_cs_lyr3 = data(f,36:38);             %select layers 2 to 4 soil types for a given CS. These are dominant soil types
        
        % Write for each soil type
        uniq_soil_top = unique(soil_cs_top, 'stable');
        
        for k = 1 : numel(uniq_soil_top)
            % top layer is on the bottom
            ind_pars4 =  find(Model_Pars(:, 1) == uniq_soil_top(k));
            ind_pars3 =  find(Model_Pars(:, 1) == soil_cs_lyr3(1));
            ind_pars2 =  find(Model_Pars(:, 1) == soil_cs_lyr3(2));
            ind_pars1 =  find(Model_Pars(:, 1) == soil_cs_lyr3(3));
            
            Pars = Model_Pars([ind_pars1; ind_pars2; ind_pars3; ind_pars4], 2:end);
            
            
            WriteInputSoilPar(CS_id(f,:), ModelType, Pars, Model_Path)
            WriteInputSHPTable(CS_id(f,:), ModelType, Pars, Model_Path, k, numel(uniq_soil_top))
        end
        
    end
    
    %%
elseif CS_Del_Type == 2
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    
    FileName = [Output_Path,'data_CS_Landform.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_CS_Landform.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Stores soil types for the catchment in a master parameter matrix
    soil_id = [data(:, 18), data(:, 36:38)] ;
    soil_idr   = reshape(soil_id,[],1);
    uniq_soil1 = unique(soil_idr);
    ind = find(uniq_soil1 ~= 0);
    uniq_soil = uniq_soil1(ind);
    clear ind soil_id soil_idr uniq_soil1
    
    % Construct Master Parameter File
    Model_Pars = zeros(size(uniq_soil,1), 7);
    
    for i = 1 : size(uniq_soil,1)
        
        index                = find(SoilPars(:,1) == uniq_soil(i));
        Model_Pars(i, 1)     = uniq_soil(i);
        Model_Pars(i, 2:end) = SoilPars(index, 4:end);
        
    end
    
   
    sub_basin_CS = [data(:,1), data(:,5), data(:,6)];
    [uniq_sub_CS idx1 idx2] = unique(sub_basin_CS, 'stable', 'rows');
    
    % Construct unique ids for every cross section
    CS_id = (1: size(uniq_sub_CS,1))';
    CS_id = CS_id(idx2);
    CS_ID = [CS_id, data];
    clear idx1 idx2 CS_id
    
    uniq_CS_id = unique(CS_ID(:,1:2),'stable','rows');  %15/9
    
    for j = 1: size(uniq_CS_id,1)
        
        
        ind = find(CS_ID(:,1) == uniq_CS_id(j));
        tmp_data =  [CS_ID(ind,13), CS_ID(ind,19), CS_ID(ind,37), CS_ID(ind,38), CS_ID(ind,39)] ;  % LF S1 S2 S3 S4
        
        
        %         tmp_data_sort = sort(tmp_data, 'descend');
        [tmp_data_sort,d2] = sort(tmp_data, 1, 'descend'); %??1
        tmp_data = tmp_data(d2(:,1),:);
        [tmp_soil_uniq] = unique(tmp_data(:,2), 'stable');
        
        for f = 1 : numel(tmp_soil_uniq)
            
            soil_cs_lyr3_ind  = find(tmp_data(:,2) ==  tmp_soil_uniq(f));
            soil_cs_lyr3 = mode(tmp_data(soil_cs_lyr3_ind ,3:5),1);
            
            ind_pars4 =  find(Model_Pars(:, 1) == tmp_soil_uniq(f));
            ind_pars3 =  find(Model_Pars(:, 1) == soil_cs_lyr3(1));
            ind_pars2 =  find(Model_Pars(:, 1) == soil_cs_lyr3(2));
            ind_pars1 =  find(Model_Pars(:, 1) == soil_cs_lyr3(3));
            
            Pars = Model_Pars([ind_pars1; ind_pars2; ind_pars3; ind_pars4], 2:end);
            
            
            WriteInputSoilPar(uniq_CS_id(j,:), ModelType, Pars, Model_Path)
            WriteInputSHPTable(uniq_CS_id(j,:), ModelType, Pars, Model_Path,f, numel(tmp_soil_uniq))
        end
        
    end
    
    
    %%
elseif CS_Del_Type == 3
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');
    
    FileName = [Output_Path,'data_ECS_LB_RB_H_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_LB_RB_H_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    soil_id = [data(:, 18), data(:, 36:38)] ;
    soil_idr   = reshape(soil_id,[],1);
    uniq_soil1 = unique(soil_idr);
    ind = find(uniq_soil1 ~= 0);
    uniq_soil = uniq_soil1(ind);
    clear ind soil_id soil_idr uniq_soil1
    
    % Construct Master Parameter File
    Model_Pars = zeros(size(uniq_soil,1), 7);
    
    for i = 1 : size(uniq_soil,1)
        
        index                = find(SoilPars(:,1) == uniq_soil(i));
        Model_Pars(i, 1)     = uniq_soil(i);
        Model_Pars(i, 2:end) = SoilPars(index, 4:end);
        
    end
    
    % This needs to be fixed in step 5???????
    ind_zero = find(data(:,12) == 0);
    data(ind_zero,:) = NaN;
    data(any(isnan(data),2),:)=[];
    
    % Find unique landform subbasin and cross section combination
    sub_basin_CS_LF = [data(:,1), data(:,5), data(:,12)];
    [uniq_sub_CS idx1 idx2] = unique(sub_basin_CS_LF, 'stable', 'rows');
    CS_id = (1: size(uniq_sub_CS,1))';
    CS_id = CS_id(idx2);
    CS_ID = [CS_id, data];
    
    
    % Find the dominent soil properties among landforms
    uniq_CS = unique(CS_ID(:,1));
    new_data = zeros(numel(uniq_CS), 8);
    for j = 1 : numel(uniq_CS)
        
        ind = find(CS_ID(:,1) == uniq_CS(j));
        tmp_data =  [CS_ID(ind,1),CS_ID(ind,2),CS_ID(ind,6),CS_ID(ind,13), CS_ID(ind,8), CS_ID(ind,19), CS_ID(ind,37), CS_ID(ind,38), CS_ID(ind,39)] ;
        %           new_data(j,:) = mode(tmp_data,1);
        new_data(j, 1:4) = mode(tmp_data(:,1:4),1);
        [x, ia, ib]= unique(tmp_data(:, 6), 'stable');
        count = accumarray(ib, tmp_data(:, 5));
        q = x(count==max(count));
        new_data(j,5) = q(1);%x(count==max(count)); %m_top soil
        
        [x, ia, ib]= unique(tmp_data(:, 7), 'stable');
        count = accumarray(ib, tmp_data(:, 5));
        q = x(count==max(count));
        new_data(j,6) = q(1);%x(count==max(count)); %m_soil 2
        
        [x, ia, ib]= unique(tmp_data(:, 8), 'stable');
        count = accumarray(ib, tmp_data(:, 5));
        q = x(count==max(count));
        new_data(j,7) = q(1); %m_soil 3
        
        [x, ia, ib]= unique(tmp_data(:, 9), 'stable');
        count = accumarray(ib, tmp_data(:, 5));
        q = x(count==max(count));
        new_data(j,8) = q(1) ; %m_soil 4
        
    end
    
    
    [uniq_CS i3 j4] = unique([new_data(:,2), new_data(:,3)],'stable', 'rows');
    CS_id = (1: size(uniq_CS,1))';
    CS_id = CS_id(j4);
    CS_IDm = [CS_id, new_data];
    
    uniq_CS2 = unique([CS_IDm(:,1),CS_IDm(:,3)],'stable','rows');   %15/9
    clear i3 j4
    
    for j = 1 : size(uniq_CS2,1)
        
        ind = find(CS_IDm(:,1) == uniq_CS2(j));
        %             LF S1 S2 S3 S4
        tmp_data =  [CS_IDm(ind,5), CS_IDm(ind,6), CS_IDm(ind,7), CS_IDm(ind,8), CS_IDm(ind,9)];
        
        %         tmp_data_sort = sort(tmp_data, 1, 'descend');
        %         [tmp_soil_uniq id1 id2] = unique(tmp_data_sort(:,2), 'stable');
        %         ind2 = find(tmp_soil_uniq ~= 0);
        %         tmp_soil_uniq = tmp_soil_uniq(ind2);
        
        [tmp_data_sort,d2] = sort(tmp_data, 1, 'descend'); %??1
        tmp_data = tmp_data(d2(:,1),:);
        [tmp_soil_uniq] = unique(tmp_data(:,2), 'stable');
        
        
        for f = 1 : numel(tmp_soil_uniq)
            
            %             soil_cs_lyr3_ind  = find(tmp_data_sort(:,2) ==  tmp_soil_uniq(f));
            %             soil_cs_lyr3 = mode(tmp_data_sort(soil_cs_lyr3_ind ,2:4),1);
            
            soil_cs_lyr3_ind  = find(tmp_data(:,2) ==  tmp_soil_uniq(f));
            soil_cs_lyr3 = mode(tmp_data(soil_cs_lyr3_ind ,3:5),1);
            
            ind_pars4 =  find(Model_Pars(:, 1) == tmp_soil_uniq(f));
            ind_pars3 =  find(Model_Pars(:, 1) == soil_cs_lyr3(1));
            ind_pars2 =  find(Model_Pars(:, 1) == soil_cs_lyr3(2));
            ind_pars1 =  find(Model_Pars(:, 1) == soil_cs_lyr3(3));
            
            Pars = Model_Pars([ind_pars1; ind_pars2; ind_pars3; ind_pars4], 2:end);
            
            WriteInputSoilPar(uniq_CS2(j,:), ModelType, Pars, Model_Path );
            WriteInputSHPTable(uniq_CS2(j,:), ModelType, Pars, Model_Path, f, numel(tmp_soil_uniq));
        end
    end
    
    
    
    %%
elseif CS_Del_Type == 4
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_Soil_Type_CS\');
    
    FileName = [Output_Path,'data_ECS_SoilType_CS.mat'];
    if exist(FileName, 'file') == 0; error('Warning: file does not exist:\n%s', ['data_ECS_SoilType_CS.mat does not exist in ', Model_Path] );
    else load(FileName)
    end
    
    % Stores soil types for the catchment in a master parameter matrix
    soil_id = [data(:, 18), data(:, 36:38)] ;
    soil_idr   = reshape(soil_id,[],1);
    uniq_soil1 = unique(soil_idr);
    ind = find(uniq_soil1 ~= 0);
    uniq_soil = uniq_soil1(ind);
    clear ind soil_id soil_idr uniq_soil1
    
    % Construct Master Parameter File
    Model_Pars = zeros(size(uniq_soil,1), 7);
    
    for i = 1 : size(uniq_soil,1)
        
        index                = find(SoilPars(:,1) == uniq_soil(i));
        Model_Pars(i, 1)     = uniq_soil(i);
        Model_Pars(i, 2:end) = SoilPars(index, 4:end);
        
    end
    
    
    sub_basin_soil = [data(:,1), data(:,18)];
    [uniq_sub_CS idx1 idx2] = unique(sub_basin_soil, 'stable', 'rows');
    
    CS_id = (1: size(uniq_sub_CS,1))';
    CS_id = CS_id(idx2);
    CS_ID = [CS_id, data];
    clear idx1 idx2
    
    %     uniq_CS_id = unique(CS_ID(:,1));
    uniq_CS_id = unique(CS_ID(:,1:2),'stable', 'rows' );
    for j = 1 : size(uniq_CS_id,1)
        
        ind = find(CS_ID(:,1) == uniq_CS_id(j));
        tmp_data =  [CS_ID(ind,13), CS_ID(ind,19), CS_ID(ind,37), CS_ID(ind,38), CS_ID(ind,39)];
        
        %         tmp_data_sort = sort(tmp_data, 'descend');
        %         [tmp_soil_uniq id1 id2] = unique(tmp_data_sort(:,2), 'stable');
        
        [tmp_data_sort,d2] = sort(tmp_data, 1, 'descend');
        tmp_data = tmp_data(d2(:,1),:);
        [tmp_soil_uniq] = unique(tmp_data(:,2), 'stable');
        
        
        %         soil_cs_lyr3 = mode(tmp_data_sort(: ,3:5),1);
        soil_cs_lyr3 = mode(tmp_data(: ,3:5),1);
        
        ind_pars4 =  find(Model_Pars(:, 1) == tmp_soil_uniq);
        ind_pars3 =  find(Model_Pars(:, 1) == soil_cs_lyr3(1));
        ind_pars2 =  find(Model_Pars(:, 1) == soil_cs_lyr3(2));
        ind_pars1 =  find(Model_Pars(:, 1) == soil_cs_lyr3(3));
        
        Pars = Model_Pars([ind_pars1; ind_pars2; ind_pars3; ind_pars4], 2:end);
        
        WriteInputSoilPar(uniq_CS_id(j,:), ModelType,Pars,Model_Path );
        WriteInputSHPTable(uniq_CS_id(j,:), ModelType, Pars, Model_Path,1, 1);
        
    end
    %%
    
end












