clear all; close all; clc
%%   This Matlab script computes spatially distributed ET for all the sub-basins depending on the delineation approach.
%%
%%   INPUTS:
%%   1) User defines ones of the delineation types and the code reads respective .mat database file from  '...\Toolbox_Output\
%%     1 = DISTRIBUTED Pixel File delineation          (6a)
%%     2 = DISTRIBUTED LANDFORM Pixel File delineation (6b)
%%     3 = ECS Left bank/right bank/head water         (6c)
%%     4 = ECS Soil type                               (6d)
%%   2) Master tables about cross sectional properties from each delineation type
%%   3) Reads CS_coordinates.txt for delineation types 1 and 2.
%%   4) Select start and End date to process output
%%
%%   OUTPUTS:
%%   1) Map_Pixel_ET_Daily_Type*_catchment.mat                  (Type 1 & 2)
%%   2) Map_subbasin_ET_Daily_Type*_catchment.mat               (Type 1 to 4)
%%   3) Map_LF_ET_Type*_catchment.mat                           (Type 2 & 4)
%%   4) Map_Hillslopes_ET_Daily_Type*_catchment.mat             (Type 3)
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%   OutputPixelIndex.m
%%   SM_subbasin_average.m
%%   SM_LF_LB_RB_H_T2.m
%%   SM_LF_LB_RB_H.m
%%   SM_LF_Soil_ECS_Soil_CS.m
%%   SM_LF_Soil_ECS_Soil.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
RunInfo  = UserRunInfo;       % User Setup of the Run variables
usr_Path = RunInfo.UserPath;

addpath([usr_Path, '\Toolbox_Scripts'])
Output_Path = strcat(usr_Path, '\Toolbox_Output\');

CS_Del_Type = input('Select Cross Section Delineation Type (1 to 4):');

if CS_Del_Type == 1 ; disp('Delineation type is "DISTRIBUTED PIXEL" based ')
    
elseif CS_Del_Type == 2 ; disp('Delineation type is "DISTRIBUTED LANDFORM" based')
    
elseif CS_Del_Type == 3 ; disp('Delineation type is "ECS Left bank/right bank/headwater"')
    
elseif CS_Del_Type == 4 ; disp('Delineation type is "ECS SOIL TYPE" ')
    
    
else
    error('This delineation does not exist!!!');
end

SubBasinFileName  = strcat(Output_Path, '\SubBasinGrid.txt');
LandformFileName  = strcat(Output_Path, '\landform.txt');
SlpAreaFileName   = strcat(Output_Path, '\SlpAreaGrid.txt');
HillslopeFileName = strcat(Output_Path, 'Hillslopes_Final.mat');

% Check if sub-basin, slope, elevation and landform text files are avaliable
if   exist(SubBasinFileName, 'file'); load(SubBasinFileName);
else error('Error: file does not exist:\n%s', [SubBasinFileName, ' does not exist in ', Output_Path] );
end

if   exist(LandformFileName, 'file'); load(LandformFileName)
else error('Error: file does not exist:\n%s', [LandformFileName, ' does not exist in ', Output_Path] )
end

if exist(SlpAreaFileName, 'file'); load (SlpAreaFileName)
else error('Error: file does not exist:\n%s', [SlpAreaFileName, ' does not exist in ', Output_Path] );
end

SoilType1File = [Output_Path, 'soiltype_usda1.txt'];
if exist(SoilType1File, 'file') == 0;  error('Warning: file does not exist:\n%s', [SoilType1File, ' does not exist in ', Output_Path]  );
else   load(SoilType1File); SoilType1 = soiltype_usda1; %SoilType1 = soiltype_usda1;
end;

if   exist(HillslopeFileName, 'file'); load(HillslopeFileName)
else error('Error: Hillslope file does not exist:\n%s', [HillslopeFileName, ' does not exist in ', Output_Path] )
end

ind_NaN = find(isnan(landform));
SubBasinGrid(ind_NaN)= NaN;
SoilType1(ind_NaN)   = NaN;
SlpAreaGrid(ind_NaN) = NaN;

LF            =  reshape(landform, [],1);
subBasins     =  reshape(SubBasinGrid, [], 1);
SoilType1d    =  reshape(SoilType1, [], 1);
slpArea       =  reshape(SlpAreaGrid,  [],1);
Hillslopes    = reshape(Hill_Grid, [], 1);

clear SubBasinFileName LandformFileName ind_NaN SoilType1 SlpAreaGrid

% Find unique sub-basins in the catchment
uniq_basins = unique(subBasins);
uniq_basins(isnan(uniq_basins)) = [];

st_date = RunInfo.StartDate;
end_date = RunInfo.EndDate;

Start_Date = input('Write the start date to process results (dd/mm/yyyy) :','s');
if    datenum(Start_Date, 'dd/mm/yyyy')< datenum(st_date, 'dd/mm/yyyy'); error('Simulation does not exist for this date');
elseif datenum(Start_Date, 'dd/mm/yyyy') > datenum(end_date, 'dd/mm/yyyy'); error('Simulation does not exist for this date');
end;

End_Date = input('Write the End date to process results (dd/mm/yyyy) :','s');
if    datenum(End_Date, 'dd/mm/yyyy') < datenum(st_date, 'dd/mm/yyyy'); error('Simulation does not exist for this date');
elseif datenum(End_Date, 'dd/mm/yyyy') > datenum(end_date, 'dd/mm/yyyy'); error('Simulation does not exist for this date');
end;

Date_Num_user = (datenum(Start_Date, 'dd/mm/yyyy'):datenum(End_Date, 'dd/mm/yyyy'));
Date_Num_simulation = (datenum(st_date, 'dd/mm/yyyy'):datenum(end_date, 'dd/mm/yyyy'));

Date_Num_user = Date_Num_user';
Date_Num_simulation = Date_Num_simulation';

[~, ~,ib] = intersect(Date_Num_user, Date_Num_simulation);
start_process = ib(1);
end_process = ib(end);

Num_TS = numel(ib);
%%
if CS_Del_Type == 1
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Distributed\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Distributed\');
    
    load([Model_Out_Path,'Pixel_ET_Daily_Type1_catchment.mat'])
    load([Model_Out_Path,'Sub_Basin_Daily_Type1_catchment.mat'])
    
    P = mean(Output_sub_d.P_sub(:,start_process+1 : end_process+1));
    
    FileName = [Output_Path, 'CS_coordinates.txt' ];
    M = dlmread(FileName,'\t');
    M_grid = ones(size(SubBasinGrid)) .* -9999;
    ET_grid_sub_pixel = nan(size(SubBasinGrid,1),size(SubBasinGrid,2), Num_TS);
    
    unique_CS = unique(Output_Daily.To_Pixel(:,1));
    ET_Pixel = Output_Daily.To_Pixel + Output_Daily.Tu_Pixel + Output_Daily.Ev_Pixel;
    ET_Pixel(:, 1:2)= Output_Daily.To_Pixel(:,1:2);
    
    k=1;
    
%     for j = start_process+1 : end_process+1
  for j = start_process : end_process %  6/8/2017
        M_grid = ones(size(SubBasinGrid)) .* -9999;
        for i = 1 : numel(unique_CS)
            
            row_index = find(ET_Pixel(:,1) == unique_CS(i));
            index = M(unique_CS(i),:);
            ind = find(index ~= 0);
            index = index(ind);
            index = fliplr(index);
            M_grid(index) = ET_Pixel(row_index,j+2);
        end
        ET_grid_sub_pixel(:,:,k) = M_grid;
        k=k+1;
    end
    
    % Average sub-basin ET (1a)
    [ET_grid_sub] = SM_Subbasin_Average(CS_Del_Type,SubBasinGrid, ET_Pixel, start_process, Num_TS);
    
    save([Model_Out_Path,'Map_Pixel_ET_Daily_Type1_catchment.mat'], 'ET_grid_sub_pixel','-v7.3')
    save([Model_Out_Path,'Map_subbasin_ET_Daily_Type1_catchment.mat'], 'ET_grid_sub','-v7.3')
    
%         MakeMovies_Double_Frame(P,ET_grid_sub_pixel, Num_TS,[Model_Out_Path,'ET_Pixel_T1'], [0.01 12])
        MakeMovies_Double_Frame(P,ET_grid_sub, Num_TS,[Model_Out_Path,'ET_subbasin_T1'], [0.01 15])
    
    
    %%
elseif CS_Del_Type == 2
    
    Model_Path  = strcat(usr_Path, '\Model_Input\Pixel_Landform\');
    Model_Out_Path = strcat(usr_Path, '\Model_Output\Pixel_Landform\');
    
    load([Model_Out_Path,'Pixel_ET_Daily_Type2_catchment.mat'])
    load([Model_Out_Path,'Sub_Basin_Daily_Type2_catchment.mat'])
    
    P = mean(Output_sub_d.P_sub(:,start_process+1 : end_process+1));
    
    FileName = [Output_Path, 'CS_coordinates.txt' ];
    M = dlmread(FileName,'\t');
    
    M_grid = ones(size(SubBasinGrid)) .* -9999;
    ET_grid_sub_pixel = nan(size(SubBasinGrid,1),size(SubBasinGrid,2), Num_TS);
    
    unique_CS = unique(Output_Daily1.To_Pixel(:,1), 'stable');
    ET_Pixel = Output_Daily1.To_Pixel + Output_Daily1.Tu_Pixel + Output_Daily1.Ev_Pixel;
    ET_Pixel(:, 1:2)= Output_Daily1.To_Pixel(:,1:2);
    
    k=1;
%     for j = start_process+1 : end_process+1
  for j = start_process : end_process %  6/8/2017
        M_grid = ones(size(SubBasinGrid)) .* -9999;
        for i = 1 : numel(unique_CS)
            row_index = find(ET_Pixel(:,1) == unique_CS(i));
            index = M(unique_CS(i),:);
            ind = find(index ~= 0);
            index = index(ind);
            index = fliplr(index);
            M_grid(index) = ET_Pixel(row_index,j+2);
        end
        
        ET_grid_sub_pixel(:,:,k) = M_grid;
        k =k +1;
    end
    
    % Average sub-basin ET(1a)
    [ET_grid_sub] = SM_Subbasin_Average(CS_Del_Type,SubBasinGrid, ET_Pixel, start_process, Num_TS);
    
    save([Model_Out_Path,'Map_Pixel_ET_Daily_Type2_catchment.mat'], 'ET_grid_sub_pixel','-v7.3')
    save([Model_Out_Path,'Map_subbasin_ET_Daily_Type2_catchment.mat'], 'ET_grid_sub','-v7.3')
    
    % Map landform level data
    load([Model_Out_Path,'LF_ET_Daily_Type2_catchment.mat'])
    ET_LF_avg1 = Output_Daily.To_mean_LF + Output_Daily.Tu_mean_LF + Output_Daily.Ev_mean_LF;
    ET_LF_avg1(:, 1:3) = Output_Daily.To_mean_LF(:, 1:3);
    
    FileName = [Output_Path,'data_CS_Landform.mat'];
    load(FileName)
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    CS_ID_LF = [CS_ID_LF(:,1:2), CS_ID_LF(:,6),CS_ID_LF(:,13)];
    
    [uniq_Hill_basin, ix1 ,ix2] = unique([CS_ID_LF(:,2),CS_ID_LF(:,3)], 'rows', 'stable');
    CS_id = (1: size(uniq_Hill_basin,1))';
    CS_id = CS_id(ix2);
    CS_ID_LF = [CS_ID_LF, CS_id];
    ET_LF_avg1 = [CS_id, ET_LF_avg1];
    
    % Average landform LB RB H
    [ ET_grid_ST_LF ] = SM_LF_LB_RB_H_T2(SubBasinGrid, Hillslopes, LF, CS_ID_LF, ET_LF_avg1, start_process, Num_TS );
    
    save([Model_Out_Path,'Map_LF_ET_Daily_Type2_catchment.mat'], 'ET_grid_ST_LF','-v7.3')
    
    %     MakeMovies_Double_Frame(P,ET_grid_sub_pixel, Num_TS,[Model_Out_Path,'ET_Pixel_T2'], [0.01 15])
    %     MakeMovies_Double_Frame(P,ET_grid_sub, Num_TS,[Model_Out_Path,'ET_subbasin_T2'], [0.01 15])
        MakeMovies_Double_Frame(P,ET_grid_ST_LF, Num_TS,[Model_Out_Path,'ET_LF_T2'], [0.01 12])
    
    %%
elseif CS_Del_Type == 3
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_LB_RB_H_CS\');
    
    FileName = [Output_Path,'data_ECS_LB_RB_H_CS.mat'];
    load(FileName)
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    CS_ID = [CS_ID(:,1), CS_ID(:,2), CS_ID(:,5)];
    CS_ID_LF = [CS_ID_LF(:,1:4), CS_ID_LF(:,6)];
    
    load([Model_Out_Path,'LF_ET_Daily_Type3_catchment.mat'])
    load([Model_Out_Path,'Sub_Basin_Daily_Type3_catchment.mat'])
    ET_LF_avg1 = Output_Daily.To_mean_LF + Output_Daily.Tu_mean_LF + Output_Daily.Ev_mean_LF;
    ET_LF_avg1(:, 1:3) = Output_Daily.To_mean_LF(:, 1:3);
    
    P = mean(Output_sub_d.P_sub(:,start_process+1 : end_process+1));
    
    % Average sub-basin ET(1a)
    [ET_grid_sub] = SM_Subbasin_Average(CS_Del_Type,SubBasinGrid, ET_LF_avg1, start_process, Num_TS);
    
    save([Model_Out_Path,'Map_subbasin_ET_Daily_Type3_catchment.mat'], 'ET_grid_sub','-v7.3')
    
    % Average landform LB RB H (2a)
    [ ET_grid_ST_LF ] = SM_LF_LB_RB_H(SubBasinGrid, Hillslopes, LF, CS_ID_LF, ET_LF_avg1, start_process, Num_TS );
    
    
    save([Model_Out_Path,'Map_Hillslopes_ET_Daily_Type3_catchment.mat'], 'ET_grid_ST_LF','-v7.3')
    
    %     MakeMovies_Double_Frame(P,ET_grid_sub, Num_TS,[Model_Out_Path,'ET_subbasin_T3'], [0.01 15])
        MakeMovies_Double_Frame(P,ET_grid_ST_LF, Num_TS,[Model_Out_Path,'ET_LF_T3'], [0.01 12])
    
    
    %%
elseif CS_Del_Type == 4
    
    Model_Path  = strcat(usr_Path, '\Model_Input\ECS_Soil_Type_CS\');
    Model_Out_Path = strcat(usr_Path,'\Model_Output\ECS_Soil_Type_CS\');
    
    FileName = [Output_Path,'data_ECS_SoilType_CS.mat'];
    load(FileName)
    
    [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data);
    
    load([Model_Out_Path,'LF_ET_Daily_Type4_catchment.mat'])
    load([Model_Out_Path,'Sub_Basin_Daily_Type4_catchment.mat'])
    
    P = mean(Output_sub_d.P_sub(:,start_process+1 : end_process+1));
    
    ET_LF_avg1 = Output_Daily.To_mean_LF + Output_Daily.Tu_mean_LF + Output_Daily.Ev_mean_LF;
    ET_LF_avg1(:, 1:3) = Output_Daily.To_mean_LF(:, 1:3);
    
    % Average sub-basin ET (1a)
    [ET_grid_sub] = SM_Subbasin_Average(CS_Del_Type,SubBasinGrid, ET_LF_avg1, start_process, Num_TS);
    
    save([Model_Out_Path,'Map_subbasin_ET_Daily_Type4_catchment.mat'], 'ET_grid_sub','-v7.3')
    
    % Landform per soil type per sub-basin
    [ ET_grid_ST_LF] =  SM_LF_Soil_ECS_Soil_CS(SubBasinGrid, SoilType1d, LF, CS_ID_LF, ET_LF_avg1, start_process, Num_TS);
    
    save([Model_Out_Path,'Map_LF_ET_Daily_Type4_catchment.mat'], 'ET_grid_ST_LF','-v7.3')
    
    
    %     MakeMovies_Double_Frame(P,ET_grid_sub, Num_TS,[Model_Out_Path,'ET_subbasin_T4'], [0.01 15])
        MakeMovies_Double_Frame(P,ET_grid_ST_LF, Num_TS,[Model_Out_Path,'ET_LF_T4'], [0.01 12])
    %%
end


