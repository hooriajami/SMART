function Write_ECS_H_LB_RB_CS(data)
%% ========================================================================
%%   This Matlab function writes ECS pixel files for the headwater, right and left banks equivalent cross sections based on U3M-2D input format.
%%   Cross sectional properties are obtained on a landform basis and aggregated at a hillslope scale.
%%
%%   It calls the following functions:
%%   UserRunInfo.m
%%
%%   This function is called by:
%%   Step6c_Create_ECS_Left_Bank_Right_Bank_*_Scale.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
%   Detailed explanation goes here
%         data_f(k, 1) = sub_basin_id;
%         data_f(k, 2) =  type_hor;                                          % Stream orientation  vertical or horizontal
%         data_f(k, 3) =  str_direction ;                                    % Get stream direction from the headwater
%         data_f(k, 4) =  CS_Type;
%         data_f(k, 5) = j;% CS_id;
%         data_f(k, 6) = m_soil;
%         data_f(k, 7) = m_LF;
%         data_f(k, 8) = max_Elv;
%         data_f(k, 9) = mean_slp;
%         data_f(k, 10) = numel(ind3);                                       % Cross section length in pixels
%
%         data_f(k,11) = m_LC;
%         data_f(k,12) = m_LC;                                               %climate
%         data_f(k,13) = mean_soild1;
%         data_f(k,14) = mean_soild2;
%         data_f(k,15) = mean_soild3;
%         data_f(k,16) = mean_soild4;
%         data_f(k,17) = ind_riverR;
%         data_f(k,18) = col;
%         data_f(k,19) = areaH;
%         data_f(k,20) = areaL;
%         data_f(k,21) = areaR;

RunInfo  = UserRunInfo;
usr_Path = RunInfo.UserPath;
Model_Path  = strcat(usr_Path, '\Model_Input\ECS_LB_RB_H_CS\');

demRes = RunInfo.DEMRes ;
LyrTickness = RunInfo.LyrThickness;  %thickness of soil layers [m]
Nodata = -9999;

% Outputfile Header
line1 = 'Seq Elev Landuse Soils Md0   Md1    Md2     Md3   ML1 ML2 ML3 ML4 Salinity1 Salinity2 Salinity3 Salinity4 ClimateZone Recharge/Discharge/Stream D-infinity_angle GFS Neighbours0-7';
line2 = '(long)(M)(T/P/C/O)(int)(M)   (M)    (M)     (M)                    (dS/m)   (dS/m)    (dS/m)     (dS/m)    (A/B/C/D)       (R/D/S)               (degrees)      (int)  (long)';
line3 = '0         1         2         3         4         5         6         7         8         9         10        11        12        13        14        15';
line4 = '0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789';

% var = 1basin_ID, 2CS_Type,  areaH,     , AreaL,     ,5areaR,    ,6LF,        7Soil_ID,    8length,                9slope,     10(Land_ID),  11(climate),    Elev,       soil_d1,      soil_d2,    soil_d3,   soil_d4];
var1 = [data(:,1), data(:,5), data(:,9), data(:,11), data(:, 10), data(:,12), data(:, 18), data(:, 7).* demRes, data(:, 15), data(:, 17), data(:, 16), data(:, 14), data(:, 26), data(:, 27), data(:, 28), data(:, 29)];

uniq_basinID = unique(var1(:,1));

for i = 1 : numel(uniq_basinID)
    
    % Select rows for a given basin
    myBasin_Index = find(var1(:,1) == uniq_basinID(i));
    
    % Extract data based on basin_ID
    var_basin = var1( myBasin_Index,:);
    
    CS_Type_LF = unique([var_basin(:,2), var_basin(:,6)], 'rows');
    
    data_CS_basin =  zeros(size(CS_Type_LF,1), 13);
    for j = 1: size(CS_Type_LF, 1)
        %         disp(CS_Type_LF(j,:))
        ind = find(var_basin(:, 2) ==   CS_Type_LF(j,1) & var_basin(:, 6) ==   CS_Type_LF(j,2));
        
        
        data_CS_basin(j,1) = mode(var_basin(ind, 1));
        data_CS_basin(j,2) = CS_Type_LF(j,1);
        data_CS_basin(j,3) = CS_Type_LF(j,2);
        
        m_length             = (var_basin(ind, 8));
        data_CS_basin(j,4)   = mean(var_basin(ind, 8));                                 %length
        data_CS_basin(j,5)   = sum(var_basin(ind, 9)  .* m_length)./ sum(m_length);     %slope
        data_CS_basin(j,6)   = sum(var_basin(ind, 12) .* m_length)./ sum(m_length);    % elev need to check
        data_CS_basin(j,7)   = sum(var_basin(ind, 13) .* m_length)./ sum(m_length);     %soil depth 1
        data_CS_basin(j,8)   = sum(var_basin(ind, 14) .* m_length)./ sum(m_length);     %soil depth 2
        data_CS_basin(j,9)   = sum(var_basin(ind, 15) .* m_length)./ sum(m_length);     %soil depth 3
        data_CS_basin(j,10)  = sum(var_basin(ind, 16) .* m_length)./ sum(m_length);     %soil depth 4
        
        [x, ia, ib]= unique(var_basin(ind, 10), 'stable');
        count = accumarray(ib, m_length);
        q = x(count==max(count));
        data_CS_basin(j,11) = q(1);%x(count==max(count)); %m_lC
        
        [x, ia, ib]= unique(var_basin(ind, 11), 'stable');
        count = accumarray(ib, m_length);
        q = x(count==max(count));
        data_CS_basin(j,12) = q(1);%x(count==max(count)); %m_climate
        %          x(count==max(count))
        %           disp('soil')
        [x, ia, ib]= unique(var_basin(ind, 7), 'stable');
        count = accumarray(ib, m_length);
        q = x(count==max(count));
        data_CS_basin(j,13) = q(1);%x(count==max(count)); %m_climate
        %          x(count==max(count))
        %         data_CS_basin(j,11)  = mode(var_basin(ind, 10));  %m_lC
        %         data_CS_basin(j,12)  = mode(var_basin(ind, 11));  %m_climate
        %         data_CS_basin(j,13)  = mode(var_basin(ind, 7));   %soil type
        
        clear ind ia ib x
        
    end
    
    
    % Remove records from var based on landform length
    Index_keep = find(data_CS_basin(:,4) >= demRes./2);
    data_CS_basin = data_CS_basin(Index_keep,:);
    
    % Add records if landform length is greater than 25 m
    Pixel_num = round(data_CS_basin(:,4) ./ demRes);
    
    % Repeat elements based on Pixel_num
    h = [];
    h(cumsum(Pixel_num))=1;
    data_CS_basin=data_CS_basin(cumsum(h)-h+1,:);
    
    uniq_CS_basin = unique(data_CS_basin(:,2));
    
    % Now for each
    for m = 1 :numel(uniq_CS_basin)
        
        % Select records for a given CS
        ind1 = find(data_CS_basin(:,2) == uniq_CS_basin(m));
        
        data1 =  data_CS_basin(ind1,:);
        
        % Sort records for a given soil type based on landform (4 is the top landform)
        [d,Index] =  sort(data1, 'descend');
        row_size = size(data1,1);
        
        % Sort the rest based on landform index in number of records greater
        %than 1
        if row_size > 1
            for n = 1 : 13
                data1(:,n) = data1(Index(:,3),n);
                
            end
        end
        
        % Add additional dummy record for discharge cell
        var_basin_soil = [data1; data1(end,:)];
        clear d data Index
        
        % Derive input variables from CSV file
        Elev_SoilType = var_basin_soil(:,6);
        Slp_SoilType  = var_basin_soil(:,5);
        Seq = linspace (1, numel(Elev_SoilType),numel(Elev_SoilType));
        Seq = Seq';
        
        % Adjust elevation based on slope of landform
        for x = 2 : numel(Elev_SoilType)
            Elev_SoilType(x) = Elev_SoilType(x-1) - (Slp_SoilType(x-1) .* demRes);
        end
        
        clear  Slp_SoilType
        Soil_SoilType1 = var_basin_soil(:,13); %;ones(numel(Elev_SoilType),1) .* mySoil_Basin(j);
        
        Soil_SoilType = Soil_SoilType1;
        
        [uniq_m_soil, ia, ic] = unique(Soil_SoilType1, 'stable');
        for c = 1  : numel(uniq_m_soil);
            %             data_f(k, 21+c) = c;
            Soil_Pixel_ind = find(Soil_SoilType1 == uniq_m_soil(c));
            Soil_SoilType(Soil_Pixel_ind) = c;
            
        end
        
        % Compute Horizon elevation
        Md3 = Elev_SoilType - var_basin_soil(:,7);
        Md2 = Md3 - var_basin_soil(:,8);
        Md1 = Md2 - var_basin_soil(:,9);
        Md0 = Md1 - var_basin_soil(:,10);
        
        % Get MLs
        numLyr = [round(var_basin_soil(:,10) ./LyrTickness), round(var_basin_soil(:,9) ./LyrTickness), round(var_basin_soil(:,8) ./LyrTickness),round(var_basin_soil(:,7) ./LyrTickness)];
        cumNumLyr = cumsum(numLyr,2);
        
        Salinity = ones(numel(Seq),4).* 0.3;
        RDS = zeros(numel(Seq),1);     %zero recharge cell, D discharge cell = 1
        RDS(numel(RDS)) = 1;           %One discharge cell
        Dinf =  zeros(numel(Seq),1);
        GFS = 4;
        GFS = repmat(GFS, numel(Seq),1);
        dum = repmat(Nodata, numel(Seq), 3);
        Neighbor1 = [Seq(2:numel(Seq)); Nodata];
        Neighbor2 = [Nodata; Seq(1:(numel(Seq)-1))];
        
        
        % Map back the character field, landuse, climate, Recharge/Discharge
        %cells
        LandIDs = char(numel(Seq), 1);
        index1 = find(var_basin_soil(:,11) == 1);
        LandIDs(index1) = 'T';
        index2 = find(var_basin_soil(:,11) == 2);
        LandIDs(index2) = 'P';
        index3 = find(var_basin_soil(:,11) == 3);
        LandIDs(index3) = 'C';
        
        climateZones = char(numel(Seq), 1);
        index1 = find(var_basin_soil(:,12) == 1 );
        climateZones(index1) = 'A';
        index1 = find(var_basin_soil(:,12) == 2 );
        climateZones(index1) = 'A';
        index1 = find(var_basin_soil(:,12) == 3 );
        climateZones(index1) = 'A';
        index1 = find(var_basin_soil(:,12) == 4 );
        climateZones(index1) = 'A';
        
        RDSs = char(numel(Seq), 1);
        index1 = find(RDS == 1);
        RDSs(index1) = 'D';
        index2 = find(RDS == 0);
        RDSs(index2) = 'R';
        
        
        %         climateName = unique(var_basin_soil(:,7)); ???  HERE NEED TO
        %         CHANGE TO ACCOMADATE MULTIPLE ZONES PERFILE
        %         climateName = mode(var_basin_soil(:,12));
        climateName = mode(var_basin_soil(1:end-1,12));
        %         soilName = SoilIDu(mySoil_Basin(j));
        %
        OutputFileName = [Model_Path, 'SB_', num2str(uniq_basinID(i)),'_CS_',num2str(uniq_CS_basin(m)),'_Cl_',num2str(climateName), '_PixelFile.txt'];
        fid = fopen(OutputFileName,'w');
        fprintf (fid, '%s\n%s\n%s\n%s\n', line1, line2, line3, line4);
        
        for n = 1 : Seq(end)
            fprintf(fid,'%5d%8.2f%2s%2d%8.2f%8.2f%8.2f%8.2f%4d%4d%4d%4d%8.4f%8.4f%8.4f%8.4f%2s%2s%7.3f%2d%6d%6d%6d%6d%6d%6d%6d%6d\t\n',Seq(n,:), Elev_SoilType(n,:), LandIDs(n,:), Soil_SoilType(n,:), Md0(n,:),Md1(n,:), Md2(n,:),Md3(n,:), cumNumLyr(n,:), Salinity(n,:),climateZones(n,:), RDSs(n,:), Dinf(n,:), GFS(n,:) , dum(n,:), Neighbor1(n,:), dum(n,:), Neighbor2(n,:) );
        end
        fclose(fid) ;
        disp(OutputFileName)
        clear var_basin_soil
    end
end


end

