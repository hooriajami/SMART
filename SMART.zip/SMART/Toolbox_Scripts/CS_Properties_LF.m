function [ max_Elv,mean_slp,m_LF, m_LC,m_climate,m_soil1,m_soil2, m_soil3, m_soil4, mean_soild1,mean_soild2,mean_soild3,mean_soild4]  = CS_Properties_LF(ind3, Elev, slp, LF,LandCover1d,ClimateZone1d, SoilType1d,SoilType2d,SoilType3d, SoilType4d, SoilLyr1d,SoilLyr2d,SoilLyr3d,SoilLyr4d )
%% ========================================================================
%%   This Matlab script gets headwater cross section properties on a landform basis.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
% max_Elv     = (Elev(ind3));
% mean_slp    = (slp(ind3));
% m_LF        = (LF(ind3));
% m_LC        = (LandCover1d(ind3));
% m_climate   = mode(ClimateZone1d(ind3));
% m_soil1     = (SoilType1d(ind3));
% m_soil2     = mode(SoilType2d(ind3));
% m_soil3     = mode(SoilType3d(ind3));
% m_soil4     = mode(SoilType4d(ind3));
% mean_soild1 = (SoilLyr1d(ind3));
% mean_soild2 = (SoilLyr2d(ind3));
% mean_soild3 = (SoilLyr3d(ind3));
% mean_soild4 = (SoilLyr4d(ind3));


        max_Elv     =  max(Elev(ind3));
        mean_slp    =  mean(slp(ind3));
        m_LF        =  mode(LF(ind3));
        m_LC        =  mode(LandCover1d(ind3));
        m_climate   =  mode(ClimateZone1d(ind3));
        m_soil1     =  mode(SoilType1d(ind3));
        m_soil2     = mode(SoilType2d(ind3));
        m_soil3     = mode(SoilType3d(ind3));
        m_soil4     = mode(SoilType4d(ind3));
        mean_soild1 = nanmean(SoilLyr1d(ind3));
        mean_soild2 = nanmean(SoilLyr2d(ind3));
        mean_soild3 = nanmean(SoilLyr3d(ind3));
        mean_soild4 = nanmean(SoilLyr4d(ind3));

end
