function [ CS_ID, CS_ID_LF ] = OutputPixelIndex(CS_Del_Type, data_f)
%% ========================================================================
%%   This Matlab function creates cross section ID number for type 2, 3 and 4 cross section delineations using
%%   cross section database files.
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================
if CS_Del_Type == 2
    
    % Find unique cross sections in each subbasin based on
    %(basin_id, CS_type, CS_id)
    sub_basin_CS = [data_f(:,1), data_f(:,5), data_f(:,6)];
    [uniq_sub_CS idx1 idx2] = unique(sub_basin_CS, 'stable', 'rows');
    
    % construct unique ids for every cross section
    CS_id = (1: size(uniq_sub_CS,1))';
    CS_id = CS_id(idx2);
    CS_ID_LF = [CS_id, data_f];
    Num_pixels_sum = accumarray(idx2, CS_ID_LF(:,8));
    clear idx1 idx2 CS_id data sub_basin_CS uniq_sub_CS
    
    % Get dominant climate
    [uniq_CS_clim ia ib] = unique([CS_ID_LF(:,1), CS_ID_LF(:,17)], 'stable', 'rows');
    count_clim = accumarray(ib, CS_ID_LF(:,8));
    t_data = [uniq_CS_clim, count_clim];
    [uniq_CS_id ia2] = unique(CS_ID_LF(:,1), 'stable');
    
    for i = 1 : numel(uniq_CS_id)
        ind = find(t_data(:,1) == uniq_CS_id(i));
        temp_data = t_data(ind,:);
        [max_count, id ] = max(temp_data(:,3));
        data_CS(i,1) = uniq_CS_id(i);
        data_CS(i,2) = temp_data(id,2);
    end
    
    CS_IDm = CS_ID_LF(ia2, :);
    clear ia ib ia2
    
    % caclulate contributing area for each cross section
    %  sub-basin   cs_type        areaH     areaR      area L
    [uniq_sub, idx1, idx2] = unique([CS_IDm(:,2), CS_IDm(:,6), CS_IDm(:,10),CS_IDm(:,11),CS_IDm(:,12) ], 'stable', 'rows');
    
    % Equal distribution
    %     area_H = uniq_sub(idx2,3);
    %     count=hist(idx2,unique(idx2));
    %     count=count';
    %     area_L = uniq_sub(:,5)./count;
    %     area_R = uniq_sub(:,4)./count;
    %     area_L1 = area_L(idx2);
    %     area_R1 = area_R(idx2);
    % Equal distribution
    
    % length weighted contributing areas 9/8/15
    sum_CS_Length = accumarray(idx2, CS_IDm(:,8));
    sum_CS_Length1 = sum_CS_Length(idx2);
    area_H = (CS_IDm(:,8) ./ sum_CS_Length1) .* CS_IDm(:,10);
    area_R1 = (CS_IDm(:,8)./ sum_CS_Length1) .* CS_IDm(:,11);
    area_L1 = (CS_IDm(:,8)./ sum_CS_Length1) .* CS_IDm(:,12);
    
    CS_IDm2 = [CS_IDm(:,1), CS_IDm(:,2), CS_IDm(:,6), CS_IDm(:,9),area_H, area_H, area_R1, area_L1];
    
    i1 = find(CS_IDm2(:,3) == 0);
    CS_IDm2(i1,5) = CS_IDm2(i1, 6);
    i2 = find(CS_IDm2(:,3) == 1);
    CS_IDm2(i2,5) = CS_IDm2(i2, 7);
    i3 = find(CS_IDm2(:,3) == 2);
    CS_IDm2(i3,5) = CS_IDm2(i3, 8);
    clear area_L area_R area_R1 area_L1 i1 i2 i3
    % cs_id sub-basin   cs_type    cs_contributing pixel
    CS_ID = [CS_IDm(:, 1:2), CS_IDm(:, 4:7), CS_IDm2(:,5),  Num_pixels_sum, data_CS(:,2)];
    %%
elseif CS_Del_Type == 3;
    
    % Find unique landform subbasin and cross section combination
    sub_basin_CS_LF = [data_f(:,1), data_f(:,5), data_f(:,12)];
    [uniq_sub_CS, idx1 ,idx2] = unique(sub_basin_CS_LF, 'stable', 'rows');
    CS_id = (1: size(uniq_sub_CS,1))';
    CS_id = CS_id(idx2);
    CS_IDm = [CS_id, data_f];
    clear idx1 idx2 CS_id sub_basin_CS_LF
    
    % Find the dominent climate among landforms
    uniq_CS = unique(CS_IDm(:,1));
    new_data = zeros(numel(uniq_CS), 12);
    for j = 1 : numel(uniq_CS)
        
        ind = find(CS_IDm(:,1) == uniq_CS(j));
        % 1CS_id        2sub-basin      3CS_Type       4-7AREAs
        %                                                         8LF                  9length         10climate       11soil       12lc
        tmp_data =  [CS_IDm(ind,1),CS_IDm(ind,2),CS_IDm(ind,6),CS_IDm(ind,9:12),CS_IDm(ind,13), CS_IDm(ind,8), CS_IDm(ind,17),CS_IDm(ind,19),CS_IDm(ind,18)] ;
        %           new_data(j,:) = mode(tmp_data,1);
        new_data(j, 1:8) = mode(tmp_data(:,1:8),1);
        
        [x, ia, ib]= unique(tmp_data(:, 10), 'stable');
        count = accumarray(ib, tmp_data(:, 9));
        q = x(count==max(count));
        new_data(j,9) = q(1);%x(count==max(count)); %m_climate
        
        [x, ia, ib]= unique(tmp_data(:, 11), 'stable');
        count = accumarray(ib, tmp_data(:, 9));
        q = x(count==max(count));
        new_data(j,10) = q(1);%x(count==max(count)); %m_soil
        
        [x, ia, ib]= unique(tmp_data(:, 12), 'stable');
        count = accumarray(ib, tmp_data(:, 9));
        q = x(count==max(count));
        new_data(j,11) = q(1);%x(count==max(count)); %m_LC
        
        new_data(j,12)  = round(mean(tmp_data(:, 9)));
        
        %     %Add records if landform length is greater than 25 m
        %     Pixel_num = round(data_CS_basin(:,4) ./ demRes);
        clear tmp_data q x ia ib count
    end
    
    
    [uniq_CS ,i3 ,j4] = unique([new_data(:,2), new_data(:,3)],'stable', 'rows');
    CS_id = (1: size(uniq_CS,1))';
    CS_id = CS_id(j4);
    CS_ID_LF = [CS_id, new_data];
    
    i1 = find(CS_ID_LF(:,4) == 0);
    CS_ID_LF(i1,2) = CS_ID_LF(i1, 6);
    i2 = find(CS_ID_LF(:,4) == 1);
    CS_ID_LF(i2,2) = CS_ID_LF(i2, 7);
    i3 = find(CS_ID_LF(:,4) == 2);
    CS_ID_LF(i3,2) = CS_ID_LF(i3, 8);
    
    %cs_id      sub-basin            CStype        LF             Landcover       soil        cl       area          Num pixls
    CS_ID_LF = [CS_ID_LF(:,1), CS_ID_LF(:,3),CS_ID_LF(:,4), CS_ID_LF(:,9), CS_ID_LF(:,12), CS_ID_LF(:,11), CS_ID_LF(:,10), CS_ID_LF(:,2), CS_ID_LF(:,13) ];
    
    [uniq_CS2, idx1, idx2] = unique(CS_ID_LF(:,1), 'stable');
    Num_pixels_sum = accumarray(idx2, CS_ID_LF(:,9));
    
    h = [];
    h(cumsum(CS_ID_LF(:,9)))=1;
    CS_ID_LF2=CS_ID_LF(cumsum(h)-h+1,:);
    [~, ~, idx22] = unique(CS_ID_LF2(:,1), 'stable');
    climate_CS = accumarray(idx22, CS_ID_LF2(:,7),[],@mode);
    
    %cs_id      sub-basin            CStype            area          Num pixls     cl
    %     CS_ID=[uniq_CS2, CS_ID_LF(idx1,2), CS_ID_LF(idx1,3), CS_ID_LF(idx1,8),Num_pixels_sum, CS_ID_LF(idx1,7)];
    CS_ID=[uniq_CS2, CS_ID_LF(idx1,2), CS_ID_LF(idx1,3), CS_ID_LF(idx1,8),Num_pixels_sum, climate_CS];
    clear i3 j4 CS_id uniq_CS2
    %%
elseif   CS_Del_Type == 4;
    
    % Find unique subbasin, soil, landform combination
    sub_basin_soil_LF = [data_f(:,1), data_f(:,18), data_f(:,12)];
    [uniq_sub_CS, idx1 ,idx2] = unique(sub_basin_soil_LF, 'stable', 'rows');
    CS_id = (1: size(uniq_sub_CS,1))';
    CS_id = CS_id(idx2);
    CS_IDm = [CS_id, data_f];
    clear idx1 idx2 CS_id sub_basin_CS_LF
    
    % Find the dominent climate among landforms
    uniq_CS = unique(CS_IDm(:,1));
    new_data = zeros(numel(uniq_CS), 12);
    for j = 1 : numel(uniq_CS)
        
        ind = find(CS_IDm(:,1) == uniq_CS(j));
        % 1CS_id        2sub-basin      3CS_Type       4-7AREAs
        %                                                         8LF                  9length         10climate       11soil       12lc
        tmp_data =  [CS_IDm(ind,1),CS_IDm(ind,2),CS_IDm(ind,6),CS_IDm(ind,9:12),CS_IDm(ind,13), CS_IDm(ind,8), CS_IDm(ind,17),CS_IDm(ind,19),CS_IDm(ind,18)] ;
        new_data(j, 1:8) = mode(tmp_data(:,1:8),1);
        
        [x, ia, ib]= unique(tmp_data(:, 10), 'stable');
        count = accumarray(ib, tmp_data(:, 9));
        q = x(count==max(count));
        new_data(j,9) = q(1);%x(count==max(count)); %m_climate
        
        [x, ia, ib]= unique(tmp_data(:, 11), 'stable');
        count = accumarray(ib, tmp_data(:, 9));
        q = x(count==max(count));
        new_data(j,10) = q(1);%x(count==max(count)); %m_soil
        
        [x, ia, ib]= unique(tmp_data(:, 12), 'stable');
        count = accumarray(ib, tmp_data(:, 9));
        q = x(count==max(count));
        new_data(j,11) = q(1);%x(count==max(count)); %m_LC
        
        new_data(j,12)  = round(mean(tmp_data(:, 9)));
        
        %  Add records if landform length is greater than 25 m
        %     Pixel_num = round(data_CS_basin(:,4) ./ demRes);
        clear tmp_data q x ia ib count
    end
    
    [uniq_CS ,i3 ,j4] = unique([new_data(:,2), new_data(:,10)],'stable', 'rows');
    CS_id = (1: size(uniq_CS,1))';
    CS_id = CS_id(j4);
    CS_ID_LF = [CS_id, new_data];
    %
    %     i1 = find(CS_ID_LF(:,4) == 0);
    %     CS_ID_LF(i1,2) = CS_ID_LF(i1, 6);
    %     i2 = find(CS_ID_LF(:,4) == 1);
    %     CS_ID_LF(i2,2) = CS_ID_LF(i2, 7);
    %     i3 = find(CS_ID_LF(:,4) == 2);
    %     CS_ID_LF(i3,2) = CS_ID_LF(i3, 8);
    
    %               cs_id      sub-basin            LF             Landcover       soil        cl             area          Num pixls
    CS_ID_LF = [CS_ID_LF(:,1), CS_ID_LF(:,3), CS_ID_LF(:,9), CS_ID_LF(:,12), CS_ID_LF(:,11), CS_ID_LF(:,10), CS_ID_LF(:,5), CS_ID_LF(:,13) ];
    
    
    [uniq_CS2, idx1, idx2] = unique(CS_ID_LF(:,1), 'stable');
    Num_pixels_sum = accumarray(idx2, CS_ID_LF(:,8));
    
    h = [];
    h(cumsum(CS_ID_LF(:,8)))=1;
    CS_ID_LF2=CS_ID_LF(cumsum(h)-h+1,:);
    [~, ~, idx22] = unique(CS_ID_LF2(:,1), 'stable');
    climate_CS = accumarray(idx22, CS_ID_LF2(:,6),[],@mode);
    
    %       cs_id      sub-basin              area          Num pixls
    %                                                                     cl                  soil
    CS_ID=[uniq_CS2, CS_ID_LF(idx1,2), CS_ID_LF(idx1,7),Num_pixels_sum, climate_CS, CS_ID_LF(idx1,5)];
    clear i3 j4 CS_id uniq_CS2
    
    
    %%
    
end