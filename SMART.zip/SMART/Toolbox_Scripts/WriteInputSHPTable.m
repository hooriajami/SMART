function WriteInputSHPTable(uniq_CS_soil, ModelType1, soilPar,Model_Path, soil_Num, Num_soil_type)
%% ========================================================================
%%   This Matlab function writes the SHP table file for every soil type in a cross section.
%%   The file format is based on U3M-2D model code.
%%   The code is mainly based on the SHP code written by Narendra Tuteja in C#.
%%
%%   INPUTS:
%%   User defines : Cross section id, Soil hydraulic model, Soil hydraulic parameters and path to save files. 
%%
%%   OUTPUTS:
%%   1) Soil SHP Table file (InputSHPTable_S_*_SB_*.txt) for every cross section in (...\Model_Input\DEL TYPE)
%%
%%   This function calls the following functions:
%%   1) Calculate_h_Tab.m
%%   2) CalculateDiffusivity.m
%%   3) CalculateHydCapacity.m
%%   4) CalculateK.m
%%   5) CalculatePressure.m
%%   6) CalculateSe.m
%%   7) CalculateTheta.m
%%
%%   This function is called by:
%%   Step7-CreateSoilPar_Files_*.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

if ModelType1 == 0 %VG model
    soilPar(:,7)  = soilPar(:,2); %Qm = Qs
    soilPar(:,8)  = soilPar(:,1); %Qa = Qr
    soilPar(:,9)  = soilPar(:,2); %Qk = Qs
    soilPar(:,10) = soilPar(:,5);%Kk = Ksat
end

%soilPar[m,1] = Qr : residual soil moisture content (-)
%soilPar[m,2] = Qs : saturated soil moisture content (-)
%soilPar[m,3] = alfa : inverse of the air-entry value (1/m)
%soilPar[m,4] = n : pore distribution index (-)
%soilPar[m,5] = Ksat : saturated hyd conductivity (m/s)
%soilPar[m,6] = l : pore connectivity parameter represented by BPar(-)
%soilPar[m,7] = Qm : Vogel & Cislerova parameter > Qs (-)
%soilPar[m,8] = Qa : Vogel & Cislerova parameter < Qr (-)
%soilPar[m,9] = Qk : Vogel & Cislerova parameter <= Qs (-)
%soilPar[m,10] = Kk : Vogel & Cislerova parameter <= Ksat (m/s)
NumSoilMaterial = 4;
M = 4;
ModelType = repmat(ModelType1, 1, 4);
%% Get parameters for SHP Table, For now use the default
%maybe ask user to provide this as input?
NTab  = 100;          %no. of values in the SHP table (-)(from GUI to this program/pre-processsor/Manager)
hTab1 = -1.00E-08;    %first pressure head value in the SHP table (m) (from GUI to this program/pre-processsor/Manager)
hTabN = -100.0;       %last pressure head value in the SHP table  (m) (from GUI to this program/pre-processsor/Manager)

%       double dlh;   // incremental pressure head in the SHP table (m)(internal to this program)
% 		double Qr,Qs,alpha,nn,Ksat,BPar,Qm,Qa,Qk,Kk; //internal variable for this program
% 		double mm; //equal 1 - 1/n; internal variable for this program
% 		double mmInv, nnInv, alphaInv;//internal variables for this program
% 		string parameterHeader="", propertiesHeader="";//internal variables for storing headers

hTab            = zeros(NTab);       %[NTab+1];// pressure head in the table (m)(from this program to pre-processor/Manager)
h_thetaR        = zeros(M,1);        %[M+1];// pressure head corresponding to thetaR [soilMaterial](m)(to soils table/program Manager)
h_thetaS        = zeros(M,1);        %[M+1];// pressure head corresponding to thetaS [soilMaterial](m)(to soils table/program Manager)
K_Hs            = zeros(M,1);        %[M+1];// Ksat corresponding to saturated pressure head [soilMaterial](m/s)(to soils table/program Manager)
thetaR          = zeros(M,1);        %[M+1];// soil moisture corresponding to residual pressure head [soilMaterial](-)(to soils table/program Manager)
thetaS          = zeros(M,1);        %[M+1];// soil moisture corresponding to saturated pressure head [soilMaterial](-)(to soils table/program Manager)
KTab            = zeros(M, NTab);    %[5,101];//[M+1,NTab+1];// Ksat corresponding to pressure head hTab[](m/s)(from this program to soils table/program Manager)
HydCapacityTab  = zeros(M, NTab);    %[5,101];//[M+1,NTab+1];// hyd capacity corresponding to pressure head hTab[](1/m)(from this program to soils table/program Manager)
thetaTab        = zeros(M, NTab);    %[M+1,NTab+1];// soil moisture corresponding to pressure head hTab[](-)(from this program to soils table/program Manager)
SeTab           = zeros(M, NTab);    %[M+1,NTab+1];// specific saturation corresponding to pressure head hTab[](-)(from this program to soils table/program Manager)
Log10Pressure   = zeros(M, NTab);    %[M+1,NTab+1];// Log10 pressure head corresponding to pressure head hTab[](log m)(from this program to soils table/program Manager)
Log10Cond       = zeros(M, NTab);    %[M+1,NTab+1];// Log10 hyd conductivity corresponding to pressure head hTab[](log m/s)(from this program to soils table/program Manager)
DiffusivityTab  = zeros(M, NTab);    %[M+1,NTab+1];// Hydraulic diffusivity corresponding to pressure head hTab[](m2/s)(from this program to soils table/program Manager)
Log10DiffusivityTab = zeros(M, NTab); %based on U3M-2D

hTab = Calculate_hTab(NTab,hTabN,hTab1 );

%calculate soil material properties
for soilMaterial = 1 : M
    
    Qr    = soilPar(soilMaterial,1);
    Qs    = soilPar(soilMaterial,2);
    alpha = soilPar(soilMaterial,3);
    nn    = soilPar(soilMaterial,4);
    Ksat  = soilPar(soilMaterial,5);
    BPar  = soilPar(soilMaterial,6);
    Qm    = soilPar(soilMaterial,7);
    Qa    = soilPar(soilMaterial,8);
    Qk    = soilPar(soilMaterial,9);
    Kk    = soilPar(soilMaterial,10);
    mm    = 1.0 - 1.0/nn;
    
    Model = ModelType(soilMaterial);
    if Model == 0
        %Addional parameters in Vogel & Cislerova model are set such that it
        %collapses to VG model
        Model = 1;
    end
    
    mmInv    = 1.0/mm;
    nnInv    = 1.0/nn;
    alphaInv = 1.0/alpha;
    
    h_thetaR(soilMaterial) = CalculatePressure(0.0, Model, alpha, alphaInv, mm, mmInv, nn, nnInv, Qs, Qa, Qm);
    h_thetaS(soilMaterial) = CalculatePressure(1.0, Model, alpha, alphaInv, mm, mmInv, nn, nnInv, Qs, Qa, Qm);
    K_Hs(soilMaterial)     = CalculateK(0.0, Model, alpha, alphaInv,nn, nnInv, mm, mmInv, Qs, Qa, Qm, Qk, Ksat, Kk);
    thetaR(soilMaterial)   = CalculateTheta(0.0, Model, alpha, alphaInv, Qs, Qa, Qm, Qr, mm, mmInv, nn, nnInv );
    thetaS(soilMaterial)   = CalculateTheta(1.0, Model, alpha, alphaInv, Qs, Qa, Qm, Qr, mm, mmInv, nn, nnInv );
    
    for  count = 1 : NTab
        
        KTab(soilMaterial,count)           = CalculateK(hTab(count), Model, alpha, alphaInv, nn, nnInv, mm, mmInv, Qs, Qa, Qm, Qk, Ksat, Kk);
        HydCapacityTab(soilMaterial,count) = CalculateHydCapacity(hTab(count), Model, alpha , alphaInv, nn, nnInv, mm, mmInv, Qs, Qa, Qm);
        thetaTab(soilMaterial,count)       = CalculateTheta(hTab(count), Model, alpha, alphaInv, Qs, Qa, Qm, Qr, mm, mmInv, nn, nnInv );
        SeTab(soilMaterial,count)          = CalculateSe(hTab(count), Model, Qs, Qa, Qm, mm, mmInv, nn, nnInv, alpha, alphaInv);
        Log10Pressure(soilMaterial,count)  = log10(max(-hTab(count), 1e-30));
        Log10Cond(soilMaterial,count)      = log10(KTab(soilMaterial, count));
        DiffusivityTab(soilMaterial,count) = CalculateDiffusivity(hTab(count), KTab(soilMaterial,count), HydCapacityTab(soilMaterial,count), Model, Qs, Qa,Qm, mm, mmInv, nn, nnInv, alpha, alphaInv, Qk, Ksat, Kk);
        Log10DiffusivityTab(soilMaterial,count)  = log10(DiffusivityTab(soilMaterial, count));
    end
end

%% Write output File
header1 = 'NTab';
OutFileName = strcat(Model_Path,'InputSHPTable_S_',num2str(uniq_CS_soil(:,1)),'_SB_',num2str(uniq_CS_soil(:,2)),'.txt'); 
% fid = fopen('InputSHPTable.txt','w');
fid = fopen(OutFileName,'a+');
fprintf (fid, '%s\n', header1);
fprintf (fid, '%10d\n', NTab);


for i = 1 : NumSoilMaterial
    header2 = ['Soil hydraulic properties Table	 soil material : ', num2str(i), '				', 'Soil hydraulic model : ', num2str(ModelType(i))];
    header3 = '(m)			(-)			(-)			(m/s)		(1/m)		(Log m)			(Log m/s)		(m2/s)		(Log m2/s)';
    header4 = 'hTab	 thetaTab	 SeTab			KTab		HydCapTab	Log10Pressure	 Log10Cond	 DiffusivityTab	Log10DiffusivityTab';
    
    fprintf (fid, '%s\n', header2);
    fprintf (fid, '%s\n', header3);
    fprintf (fid, '%s\n', header4);
    
    for j = 1 : NTab
        
        fprintf(fid, '%8.2E%s', hTab(j), ',');
        fprintf(fid, '%8.2E%s', thetaTab(i,j), ',');
        fprintf(fid, '%8.2E%s', SeTab(i,j), ',');
        fprintf(fid, '%8.2E%s', KTab(i,j), ',');
        fprintf(fid, '%8.2E%s', HydCapacityTab(i,j), ',');
        fprintf(fid, '%8.2E%s', Log10Pressure(i,j), ',');
        fprintf(fid, '%8.2E%s', Log10Cond(i,j), ',');
        fprintf(fid, '%8.2E%s', DiffusivityTab(i,j), ',');
        fprintf(fid, '%8.2E\n', Log10DiffusivityTab(i,j));     
        
    end
        
end

if soil_Num == Num_soil_type 
lastLine1 = '0         1         2         3         4         5         6         7         8         9         10        11';
lastLine2 = '012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789';
fprintf (fid, '%s\n', lastLine1);
fprintf (fid, '%s\n', lastLine2);
end
fclose(fid) ;

end