function [ Output_Daily, Output_Monthly,Output_Yearly ] = Pixel_ET(  CS_Del_Type,Model_Out_Path, CS_ID)
%% ========================================================================
%%   This Matlab function is part of the post processing tools of SMART.
%%   It maps pixel level ET values per time step using user defined dates. 
%%   This option is only available to process output files of type 1 and 2 cross section delineations (distributed approaches).
%%   
%%   OUTPUTS:
%%   Daily, monthly and annual pixel level ET.  
%%
%%   This function is called by the post-processing scripts:
%%    Step13b_Spatial_Distribution_ET_*_Scale.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

RunInfo  = UserRunInfo;
st_date = RunInfo.StartDate;
end_date = RunInfo.EndDate;
Date_Num = (datenum(st_date, 'dd/mm/yyyy'):datenum(end_date, 'dd/mm/yyyy'));
[year, month, day] = datevec(datestr(Date_Num,'dd/mm/yyyy'),'dd/mm/yyyy' );
SimPeriod = size(year,1);

To_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);
Tu_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);
Ev_Pixel = zeros(sum(CS_ID(:,3),1), SimPeriod + 2);

step =1;

if CS_Del_Type == 1
    for i = 1 :  size(CS_ID, 1)  %for every CS
        
        record = CS_ID(i,:);
        
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        To_mean = zeros(record(3),  SimPeriod+2);
        Tu_mean = zeros(record(3),  SimPeriod+2);
        Ev_mean = zeros(record(3),  SimPeriod+2);
        
        for j = 1  :   record(3)  %read all pixels
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            To_mean(j, 1) =  record(1);
            To_mean(j, 2) =  record(2);
            To_mean(j, 3:end) = (Tb.Var6)';
            
            Tu_mean(j, 1) =  record(1);
            Tu_mean(j, 2) =  record(2);
            Tu_mean(j, 3:end) = (Tb.Var7)';
            
            Ev_mean(j, 1) =  record(1);
            Ev_mean(j, 2) =  record(2);
            Ev_mean(j, 3:end) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        To_Pixel(step: size(To_mean,1)+step-1 , :) = To_mean;
        Tu_Pixel(step: size(Tu_mean,1)+step-1 , :) = Tu_mean;
        Ev_Pixel(step: size(Ev_mean,1)+step-1 , :) = Ev_mean;
        
        step = step + size(To_mean,1);
        clear To_mean Tu_mean Ev_mean
    end
    
    To_Pixel_d  = [To_Pixel(:, (1:2)), To_Pixel(:,3).*1000, (diff(To_Pixel(:, 3:end), [],2).*1000)];
    Tu_Pixel_d  = [Tu_Pixel(:, (1:2)), Tu_Pixel(:,3).*1000, (diff(Tu_Pixel(:, 3:end), [],2).*1000)];
    Ev_Pixel_d  = [Ev_Pixel(:, (1:2)), Ev_Pixel(:,3).*1000, (diff(Ev_Pixel(:, 3:end), [],2).*1000)];
    
    
elseif CS_Del_Type == 2
    
    for i = 1 :  size(CS_ID, 1) %for every CS
        record = CS_ID(i,:);
        Output_Files_Path = [Model_Out_Path,'CS_', num2str(record(1)),'_SB_', num2str(record(2)), '\'];
        
        To_mean = zeros(record(3),  SimPeriod+2);
        Tu_mean = zeros(record(3),  SimPeriod+2);
        Ev_mean = zeros(record(3),  SimPeriod+2);
        
        for j = 1  :   record(3)  %read all pixels
            
            Qb_FileName = [Output_Files_Path,'OutputFlux_', num2str(j),'.txt'];
            Tb = readtable(Qb_FileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 3);%,'Format', format_Pixel  );
            
            To_mean(j, 1) =  record(1);
            To_mean(j, 2) =  record(2);
            To_mean(j, 3:end) = (Tb.Var6)';
            
            Tu_mean(j, 1) =  record(1);
            Tu_mean(j, 2) =  record(2);
            Tu_mean(j, 3:end) = (Tb.Var7)';
            
            Ev_mean(j, 1) =  record(1);
            Ev_mean(j, 2) =  record(2);
            Ev_mean(j, 3:end) = (Tb.Var8)';
            
            clear Tb Qb_FileName
            
        end
        
        To_Pixel(step: size(To_mean,1)+step-1 , :) = To_mean;
        Tu_Pixel(step: size(Tu_mean,1)+step-1 , :) = Tu_mean;
        Ev_Pixel(step: size(Ev_mean,1)+step-1 , :) = Ev_mean;
        
        step = step + size(To_mean,1);
        
        clear To_mean Tu_mean Ev_mean
    end
    
    To_Pixel_d  = [To_Pixel(:, (1:2)), To_Pixel(:,3).*1000, (diff(To_Pixel(:, 3:end), [],2).*1000)];
    Tu_Pixel_d  = [Tu_Pixel(:, (1:2)), Tu_Pixel(:,3).*1000, (diff(Tu_Pixel(:, 3:end), [],2).*1000)];
    Ev_Pixel_d  = [Ev_Pixel(:, (1:2)), Ev_Pixel(:,3).*1000, (diff(Ev_Pixel(:, 3:end), [],2).*1000)];
end

Output_Daily = struct('To_Pixel',To_Pixel_d, 'Tu_Pixel', Tu_Pixel_d, 'Ev_Pixel', Ev_Pixel_d);

%% Monthly and Annual


day_d = ones(size(day,1),1);
date_num_ind = datenum(year, month, day_d);
[~, ~, idx2] = unique(date_num_ind);

c_days  = accumarray(idx2, day_d);
end_days_ind = cumsum(c_days);
start_days_ind = end_days_ind - c_days+1;

clear date_num_ind idx2 c_days

% Save Monthly
Num_years = unique(year);
To_Pixel_Month  = zeros(size(To_Pixel_d, 1), numel(Num_years).*12);
Tu_Pixel_Month  = zeros(size(Tu_Pixel_d, 1), numel(Num_years).*12);
Ev_Pixel_Month  = zeros(size(Ev_Pixel_d, 1), numel(Num_years).*12);

To_Pixel_Month(:, 1:2) = To_Pixel_d(:, (1:2));
Tu_Pixel_Month(:, 1:2) = Tu_Pixel_d(:, (1:2));
Ev_Pixel_Month(:, 1:2) = Ev_Pixel_d(:, (1:2));

for i = 1 : numel(Num_years)*12
    
    To_Pixel_Month(:,i+2)   = sum(To_Pixel_d(:,start_days_ind(i)+2 :end_days_ind(i)+2  ), 2);
    Tu_Pixel_Month(:,i+2)   = sum(Tu_Pixel_d(:,start_days_ind(i)+2 :end_days_ind(i)+2  ), 2);
    Ev_Pixel_Month(:,i+2)   = sum(Ev_Pixel_d(:,start_days_ind(i)+2 :end_days_ind(i)+2  ), 2);
    
end

Output_Monthly = struct('To_Pixel_Month',To_Pixel_Month, 'Tu_Pixel_Month',Tu_Pixel_Month,'Ev_Pixel_Month', Ev_Pixel_Month);

clear To_Pixel_Month Tu_Pixel_Month Ev_Pixel_Month

date_num_ind2 = datenum(year, ones(size(day,1),1), day_d);
[~, ~, idx_yr] = unique(date_num_ind2);
%
Num_years = unique(year);
To_Pixel_y      = zeros(size(To_Pixel_d,1), numel(Num_years)+2);
Tu_Pixel_y      = zeros(size(To_Pixel_d,1), numel(Num_years)+2);
Ev_Pixel_y      = zeros(size(To_Pixel_d,1), numel(Num_years)+2);


To_Pixel_y(:, 1:2) = To_Pixel_d(:, (1:2));
Tu_Pixel_y(:, 1:2) = Tu_Pixel_d(:, (1:2));
Ev_Pixel_y(:, 1:2) = Ev_Pixel_d(:, (1:2));

for i = 1 : size(To_Pixel_d,1);
    
    To_Pixel_y(i,3:end)     = accumarray(idx_yr,To_Pixel_d(i,3:end)');
    Tu_Pixel_y(i,3:end)     = accumarray(idx_yr,To_Pixel_d(i,3:end)');
    Ev_Pixel_y(i,3:end)     = accumarray(idx_yr,To_Pixel_d(i,3:end)');
end

Output_Yearly = struct('To_Pixel_y',To_Pixel_y, 'Tu_Pixel_y',Tu_Pixel_y,'Ev_Pixel_y', Ev_Pixel_y);

end %function



