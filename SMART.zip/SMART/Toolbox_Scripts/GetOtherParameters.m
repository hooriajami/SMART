function [NumPixels, numberOfSoils, numberOfClimateZones, numberOfPixelFiles, outputPixelSequence, simPeriod, numberOfLayersMax, K_GFS, NumSoilMaterial] = GetOtherParameters( PixelFileName, ClimateFileName, ShpFileName, SoilParName)
%% ========================================================================
%%   This Matlab script obtains U3M-2D parameters for the OtherInputFile.txt file for every cross from the Pixel File, Climate File, Input SHP table and InputSoilPar.txt files.
%%
%%   INPUTS:
%%   1) PixelFile
%%   2) ClimateFileName
%%   3) InputSHPTable
%%   4) SoilParName
%%
%%   OUTPUTS:
%%   Parameters For every cross section for the InputOtherData_S_*_SB_*.txt' file (...\Model_Input\DEL TYPE)
%%
%%    This function is called by:
%%    Step9_Write_OtherInputFile_*_Scale.m
%%
%%   Copyright 2016 Hoori Ajami, University of California Riverside
%%   Version 1.0
%% ========================================================================

format_Pixel   = '%5d%8.2f%2s%2d%8.2f%8.2f%8.2f%8.2f%4d%4d%4d%4d%8.4f%8.4f%8.4f%8.4f%2s%2s%7.3f%2d%6d%6d%6d%6d%6d%6d%6d%6d';
format_climate =  '%s%s%s%s%4.2f%s%4.2f%s%4.2f%s%4.2f%s%4.2f%s%10.8f%s%10.8f%s%10.8f%s%10.8f%s%10.8f%s%10.8f%s%10.8f';

T = readtable(PixelFileName,  'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 4,'Format', format_Pixel  );

% From Pixel File
NumPixels            =  size(T.Var1,1);
numberOfSoils        =  numel(unique(T.Var4));
numberOfClimateZones =  1;%numel(unique(T.Var11))
numberOfPixelFiles   =  size(T.Var1,1);
outputPixelSequence  =  T.Var1;
clear T PixelFileName

% From climate File
T = readtable(ClimateFileName , 'ReadVariableNames',false,'ReadRowNames', false, 'HeaderLines', 2,'Format', format_climate );

simPeriod  = size(T.Var1,1);
clear T ClimateFileName

% From InputSHPTable
fid   = fopen(ShpFileName);
line2 = textscan(fid, '%d\n %*[^\n]','HeaderLines',1);
fclose(fid);

numberOfLayersMax = cell2mat(line2);
clear fid line2 ShpFileName

% From soil parameter
fid   = fopen(SoilParName);
line1 = textscan(fid, '%s%s%s%d\n %*[^\n]',1);
fclose(fid);
K_GFS = dlmread(SoilParName,',',[4 4 4 4]); %conductivity of bottom layer
NumSoilMaterial  = line1{1,4};
clear line1 fid SoilParName


end

